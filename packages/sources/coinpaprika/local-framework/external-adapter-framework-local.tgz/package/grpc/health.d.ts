import type { sendUnaryData, ServerUnaryCall, ServiceDefinition } from '@grpc/grpc-js';
/** Fully qualified name of the service in `health.proto`. */
export declare const HEALTH_SERVICE_NAME = "grpc.health.v1.Health";
/** `grpc.health.v1.HealthCheckRequest`. */
export interface HealthCheckRequest {
    service?: string;
}
/** `grpc.health.v1.HealthCheckResponse`, decoded with the same `enums: String` proto-loader
 * option `loadHealthServiceDefinition` uses, so `status` is the string name, not a numeric enum. */
export interface HealthCheckResponse {
    status: 'UNKNOWN' | 'SERVING' | 'NOT_SERVING' | 'SERVICE_UNKNOWN';
}
/**
 * Loads the standard `grpc.health.v1.Health` service definition from `health.proto`
 * (https://github.com/grpc/grpc/blob/master/doc/health-checking.md). Cached, since a process
 * only ever serves one.
 *
 * @returns the grpc-js service definition
 */
export declare const loadHealthServiceDefinition: () => ServiceDefinition;
/**
 * Implements `grpc.health.v1.Health/Check` unconditionally as `SERVING` — this framework has no
 * notion of a degraded-but-alive state, so "the process is up and this handler runs" is the
 * whole check, regardless of the requested `service` name. `Watch` is deliberately left
 * unregistered: `Server.addService` falls back to a default handler that returns `UNIMPLEMENTED`
 * for it, which is correct here rather than a half-built streaming implementation, since nothing
 * in this framework needs the watch (push-on-change) form — callers that only need point-in-time
 * checks (e.g. AWS ALB's `backend-protocol-version: GRPC` target group health check, which only
 * ever calls `Check`) are unaffected.
 */
export declare class HealthService {
    check: (_call: ServerUnaryCall<HealthCheckRequest, HealthCheckResponse>, callback: sendUnaryData<HealthCheckResponse>) => void;
}
