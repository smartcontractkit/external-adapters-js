"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HealthService = exports.loadHealthServiceDefinition = exports.HEALTH_SERVICE_NAME = void 0;
const proto_loader_1 = require("@grpc/proto-loader");
const fs_1 = require("fs");
const path_1 = require("path");
/** Fully qualified name of the service in `health.proto`. */
exports.HEALTH_SERVICE_NAME = 'grpc.health.v1.Health';
const PROTO_FILENAME = 'health.proto';
/**
 * Locates `health.proto` at runtime. Mirrors `resolveProtoPath` in `./index.ts` — see that
 * function's doc for why both candidates are needed.
 *
 * @returns an absolute path to the proto file
 */
const resolveProtoPath = () => {
    const candidates = [
        (0, path_1.join)(__dirname, PROTO_FILENAME),
        (0, path_1.join)(__dirname, '..', '..', '..', 'src', 'grpc', PROTO_FILENAME),
    ];
    const found = candidates.find((candidate) => (0, fs_1.existsSync)(candidate));
    if (!found) {
        throw new Error(`Could not find ${PROTO_FILENAME}. Looked in: ${candidates.join(', ')}`);
    }
    return found;
};
let cachedServiceDefinition;
/**
 * Loads the standard `grpc.health.v1.Health` service definition from `health.proto`
 * (https://github.com/grpc/grpc/blob/master/doc/health-checking.md). Cached, since a process
 * only ever serves one.
 *
 * @returns the grpc-js service definition
 */
const loadHealthServiceDefinition = () => {
    if (!cachedServiceDefinition) {
        const packageDefinition = (0, proto_loader_1.loadSync)(resolveProtoPath(), {
            keepCase: true,
            longs: String,
            enums: String,
            defaults: true,
            arrays: true,
            objects: true,
        });
        cachedServiceDefinition = packageDefinition[exports.HEALTH_SERVICE_NAME];
    }
    return cachedServiceDefinition;
};
exports.loadHealthServiceDefinition = loadHealthServiceDefinition;
/**
 * Implements `grpc.health.v1.Health/Check` unconditionally as `SERVING` — this framework has no
 * notion of a degraded-but-alive state, so "the process is up and this handler runs" is the
 * whole check, regardless of the requested `service` name. `Watch` is deliberately left
 * unregistered: `Server.addService` falls back to a default handler that returns `UNIMPLEMENTED`
 * for it, which is correct here rather than a half-built streaming implementation, since nothing
 * in this framework needs the watch (push-on-change) form — callers that only need point-in-time
 * checks (e.g. AWS ALB's `backend-protocol-version: GRPC` target group health check, which only
 * ever calls `Check`) are unaffected.
 */
class HealthService {
    check = (_call, callback) => {
        callback(null, { status: 'SERVING' });
    };
}
exports.HealthService = HealthService;
//# sourceMappingURL=health.js.map