"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GrpcStreamServer = exports.loadStreamServiceDefinition = exports.STREAM_SERVICE_NAME = void 0;
const grpc_js_1 = require("@grpc/grpc-js");
const proto_loader_1 = require("@grpc/proto-loader");
const fs_1 = require("fs");
const path_1 = require("path");
const util_1 = require("../util");
const health_1 = require("./health");
const service_1 = require("./service");
__exportStar(require("./bus"), exports);
__exportStar(require("./health"), exports);
__exportStar(require("./payload-hash"), exports);
__exportStar(require("./port-mux"), exports);
__exportStar(require("./service"), exports);
__exportStar(require("./subscriber"), exports);
const logger = (0, util_1.makeLogger)('GrpcServer');
/** Fully qualified name of the service in `streams.proto`. */
exports.STREAM_SERVICE_NAME = 'streams.v1.StreamService';
const PROTO_FILENAME = 'streams.proto';
/** How long {@link GrpcStreamServer.shutdown} waits for a graceful drain before forcing it. */
const GRACEFUL_SHUTDOWN_TIMEOUT_MS = 5000;
/**
 * Locates `streams.proto` at runtime.
 *
 * `__dirname` is `dist/src/grpc` for the compiled framework — which is also the published package
 * layout, since `dist/src` is the package root — and `src/grpc` when running from source.
 * The build script copies the proto next to the compiled js, but a plain `tsc` (what the tests run)
 * does not, so we fall back to the source tree.
 *
 * @returns an absolute path to the proto file
 */
const resolveProtoPath = () => {
    const candidates = [
        (0, path_1.join)(__dirname, PROTO_FILENAME),
        (0, path_1.join)(__dirname, '..', '..', '..', 'src', 'grpc', PROTO_FILENAME),
    ];
    const found = candidates.find((candidate) => (0, fs_1.existsSync)(candidate));
    if (!found) {
        throw new Error(`Could not find ${PROTO_FILENAME}. Looked in: ${candidates.join(', ')}`);
    }
    return found;
};
let cachedServiceDefinition;
/**
 * Loads the `StreamService` definition from `streams.proto`. Cached, since a process only ever
 * serves one.
 *
 * @returns the grpc-js service definition
 */
const loadStreamServiceDefinition = () => {
    if (!cachedServiceDefinition) {
        const packageDefinition = (0, proto_loader_1.loadSync)(resolveProtoPath(), {
            // The wire field names must be preserved verbatim (`observation_json`, `payload_hash`)
            keepCase: true,
            longs: String,
            enums: String,
            defaults: false,
            arrays: true,
            objects: true,
            // So a google.protobuf.Value carries the `kind` discriminator
            oneofs: true,
        });
        cachedServiceDefinition = packageDefinition[exports.STREAM_SERVICE_NAME];
    }
    return cachedServiceDefinition;
};
exports.loadStreamServiceDefinition = loadStreamServiceDefinition;
/**
 * Serves `streams.v1.StreamService`.
 *
 * By default this binds its own listener, separate from `EA_PORT`, because `@grpc/grpc-js` builds
 * and owns its own `http2` server and cannot be handed an already-accepted socket, and fastify serves
 * HTTP/1.1 — so there is nothing to demultiplex into directly. When `GRPC_PORT` is configured equal
 * to `EA_PORT` (see `grpcPortSharingEnabled`), `expose()` instead binds this server to an internal,
 * loopback-only port (via the `listen` override) and puts `port-mux`'s plaintext demultiplexer in
 * front of both it and fastify, the same way the retired Go streams adapter used `cmux` to share
 * `HTTP_PORT`.
 */
class GrpcStreamServer {
    service;
    server;
    host;
    configuredPort;
    cleanups = [];
    boundPort;
    constructor(adapter, bus) {
        const settings = adapter.config.settings;
        this.host = settings.GRPC_HOST;
        this.configuredPort = settings.GRPC_PORT;
        this.service = new service_1.StreamService(adapter, bus);
        this.server = new grpc_js_1.Server({
            'grpc.max_concurrent_streams': settings.GRPC_MAX_CONCURRENT_STREAMS,
        });
        this.server.addService((0, exports.loadStreamServiceDefinition)(), {
            Subscribe: this.service.subscribe,
        });
        // Registered on this same Server/listener so it is reachable through port-sharing mode too
        // (see the class doc), not just the separate-port default.
        const health = new health_1.HealthService();
        this.server.addService((0, health_1.loadHealthServiceDefinition)(), {
            Check: health.check,
        });
    }
    /** The port the server is listening on, or undefined before it is bound. */
    get port() {
        return this.boundPort;
    }
    /**
     * Binds the server to `GRPC_HOST`:`GRPC_PORT`, or to `override` when given one.
     *
     * @param credentials - server credentials, built from the adapter's TLS settings
     * @param override - host/port to bind instead of the configured ones, used to bind to an internal,
     *   loopback-only port when `expose()` is sharing `EA_PORT` via the port multiplexer
     * @returns the bound port, which differs from the configured/override port when that is 0
     */
    async listen(credentials, override) {
        const host = override?.host ?? this.host;
        const port = override?.port ?? this.configuredPort;
        // An IPv6 host (e.g. the '::' default) has to be bracketed before the port is appended
        const address = host.includes(':') ? `[${host}]:${port}` : `${host}:${port}`;
        this.boundPort = await new Promise((resolve, reject) => {
            this.server.bindAsync(address, credentials, (err, resolvedPort) => {
                if (err) {
                    reject(err);
                    return;
                }
                resolve(resolvedPort);
            });
        });
        return this.boundPort;
    }
    /**
     * Registers a callback to run at the start of {@link shutdown}, before the listener is closed.
     * Used to detach process-level listeners that would otherwise keep this server — and through it
     * the whole adapter — reachable for the lifetime of the process.
     *
     * @param cleanup - callback to run when shutting down
     */
    onShutdown(cleanup) {
        this.cleanups.push(cleanup);
    }
    /**
     * Closes every open stream, then shuts the listener down.
     *
     * @param gracefulTimeoutMs - how long to wait for a graceful drain before forcing it
     */
    async shutdown(gracefulTimeoutMs = GRACEFUL_SHUTDOWN_TIMEOUT_MS) {
        for (const cleanup of this.cleanups.splice(0)) {
            cleanup();
        }
        this.service.closeAll('the adapter is shutting down');
        await new Promise((resolve) => {
            // The grpc-js server never invokes this callback with an error, so a graceful shutdown that
            // cannot complete would hang forever: `tryShutdown` waits on every open http2 session, and a
            // client whose flow-control window is exhausted keeps its session open indefinitely. Bound the
            // wait and force it, rather than stalling the adapter's own shutdown behind a slow client.
            const forceTimer = setTimeout(() => {
                logger.warn(`gRPC server did not shut down gracefully within ${gracefulTimeoutMs}ms, forcing it`);
                this.server.forceShutdown();
                resolve();
            }, gracefulTimeoutMs);
            // Never let the fallback itself hold the event loop open
            forceTimer.unref();
            this.server.tryShutdown(() => {
                clearTimeout(forceTimer);
                resolve();
            });
        });
    }
}
exports.GrpcStreamServer = GrpcStreamServer;
//# sourceMappingURL=index.js.map