"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.expose = exports.start = exports.getGrpcCredentials = exports.getTLSOptions = exports.ServerInstance = void 0;
const grpc_js_1 = require("@grpc/grpc-js");
const path_1 = require("path");
const redlock_1 = require("redlock");
const adapter_1 = require("./adapter");
const background_executor_1 = require("./background-executor");
const config_1 = require("./config");
const router_1 = __importDefault(require("./debug/router"));
const grpc_1 = require("./grpc");
const metrics_1 = require("./metrics");
const server_1 = require("./server");
Object.defineProperty(exports, "ServerInstance", { enumerable: true, get: function () { return server_1.App; } });
const util_1 = require("./util");
const validation_1 = require("./validation");
const router_2 = __importDefault(require("./status/router"));
const logger = (0, util_1.makeLogger)('Main');
const VERSION = process.env['npm_package_version'];
/** Exit code node itself uses for an unhandled SIGTERM, i.e. 128 + 15. */
const SIGTERM_EXIT_CODE = 143;
const getTLSOptions = (adapterSettings) => {
    if (!adapterSettings.TLS_ENABLED && !adapterSettings.MTLS_ENABLED) {
        return {};
    }
    if (adapterSettings.TLS_ENABLED && adapterSettings.MTLS_ENABLED) {
        throw new Error('TLS_ENABLED and MTLS_ENABLED cannot both be set to true.');
    }
    if (!adapterSettings.TLS_PRIVATE_KEY ||
        !adapterSettings.TLS_PUBLIC_KEY ||
        !adapterSettings.TLS_CA) {
        const TLSOption = adapterSettings.TLS_ENABLED ? 'TLS_ENABLED' : 'MTLS_ENABLED';
        throw new Error(`TLS_PRIVATE_KEY, TLS_PUBLIC_KEY, and TLS_CA environment variables are required when ${TLSOption} is set to true.`);
    }
    const httpsOptions = {
        key: adapterSettings.TLS_PRIVATE_KEY,
        cert: adapterSettings.TLS_PUBLIC_KEY,
        ca: adapterSettings.TLS_CA,
        passphrase: adapterSettings.TLS_PASSPHRASE,
        requestCert: adapterSettings.MTLS_ENABLED,
    };
    return { https: httpsOptions };
};
exports.getTLSOptions = getTLSOptions;
/**
 * Builds the gRPC server credentials out of the same TLS settings the REST API uses, so there is
 * only one set of certificates to configure.
 *
 * @param adapterSettings - the adapter settings holding the TLS configuration
 * @returns insecure credentials, or SSL ones when TLS_ENABLED / MTLS_ENABLED is set
 */
const getGrpcCredentials = (adapterSettings) => {
    const { https } = (0, exports.getTLSOptions)(adapterSettings);
    if (!https) {
        return grpc_js_1.ServerCredentials.createInsecure();
    }
    if (adapterSettings.TLS_PASSPHRASE) {
        logger.warn('TLS_PASSPHRASE is ignored by the gRPC server; @grpc/grpc-js cannot decrypt an encrypted private key.');
    }
    // The TLS_* settings are validated as base64, so they have to be decoded to get the PEM bytes
    return grpc_js_1.ServerCredentials.createSsl(Buffer.from(https.ca, 'base64'), [
        {
            private_key: Buffer.from(https.key, 'base64'),
            cert_chain: Buffer.from(https.cert, 'base64'),
        },
    ], https.requestCert);
};
exports.getGrpcCredentials = getGrpcCredentials;
/**
 * Main function for the framework.
 * Initializes config and dependencies, uses those to initialize Transports, and starts listening for requests.
 *
 * @param adapter - an object describing an External Adapter
 * @param dependencies - an optional object with adapter dependencies to inject
 * @returns a Promise that resolves to the http.Server listening for connections
 */
const start = async (adapter, dependencies) => {
    if (!(adapter instanceof adapter_1.Adapter)) {
        throw new Error('The adapter has not been initialized as an instance of the Adapter class, exiting.');
    }
    // Only the modes that write the response cache can push observations, so the bus (and with it the
    // cache write hook) only exists for them. GRPC_ENABLED with EA_MODE=reader is a config error, and
    // is rejected by adapter.initialize below. See plan §6.1.
    const grpcEnabled = (0, config_1.grpcServingEnabled)(adapter.config.settings);
    const observationBus = grpcEnabled ? new grpc_1.ObservationBus() : undefined;
    // Initialize adapter (create dependencies, inject them, build endpoint map, etc.)
    await adapter.initialize(observationBus ? { ...dependencies, observationBus } : dependencies);
    let api = undefined;
    let metricsApi = undefined;
    let grpcServer = undefined;
    if (adapter.config.settings.METRICS_ENABLED &&
        adapter.config.settings.EXPERIMENTAL_METRICS_ENABLED) {
        metricsApi = (0, metrics_1.setupMetricsServer)(adapter.name, adapter.config.settings);
    }
    // Optional Promise to indicate that the API is shutting down (for us to close background executors)
    let apiShutdownPromise;
    if (adapter.config.settings.EA_MODE === 'reader' ||
        adapter.config.settings.EA_MODE === 'reader-writer') {
        // Main REST API server to handle incoming requests
        api = await buildRestApi(adapter);
        // Add a hook on close to use on the background execution loop to stop it
        apiShutdownPromise = new Promise((resolve) => {
            api?.addHook('onClose', async () => {
                // Used in the RedisCache lock method for testing purposes
                adapter.shutdownNotifier.emit('onClose');
                resolve();
            });
        });
    }
    else {
        logger.info('REST API is disabled; this instance will not process incoming requests.');
    }
    // Listener for unhandled promise rejections that are bubbling up to the top
    // The tests will add many listeners since multiple adapters are started in the same process
    if (process.env['NODE_ENV'] === 'test') {
        process.setMaxListeners(0);
    }
    process.on('unhandledRejection', (err) => {
        // Throw redlock execution error for testing purposes
        if (err instanceof redlock_1.ExecutionError) {
            throw err;
        }
        (0, util_1.censorLogs)(() => logger.error({
            name: err.name,
            stack: err.stack,
            message: err.message,
        }));
    });
    if (adapter.config.settings.EA_MODE === 'writer' ||
        adapter.config.settings.EA_MODE === 'reader-writer') {
        // Start background loop that will take care of calling any async Transports
        logger.info('Starting background execution loop');
        (0, background_executor_1.callBackgroundExecutes)(adapter, apiShutdownPromise);
    }
    else {
        logger.info('Background executor is disabled; this instance will not perform async background executes.');
    }
    if (observationBus) {
        grpcServer = new grpc_1.GrpcStreamServer(adapter, observationBus);
        const server = grpcServer;
        // In reader-writer mode the api owns the lifecycle, but a writer has no fastify instance to hang
        // the shutdown off of, so it listens for the signal itself
        api?.addHook('onClose', async () => {
            await server.shutdown();
        });
        if (adapter.config.settings.EA_MODE === 'writer') {
            const onSigterm = () => {
                // Registering any SIGTERM listener replaces node's default terminate action, so this handler
                // has to exit the process itself. Without that the pod would ignore SIGTERM entirely and sit
                // there running background executes and writing to the shared cache until it is SIGKILLed at
                // the end of the termination grace period.
                void server.shutdown().finally(() => process.exit(SIGTERM_EXIT_CODE));
            };
            process.once('SIGTERM', onSigterm);
            // The listener closes over the server, and through it the entire adapter object graph, so it
            // must not outlive the server it is shutting down
            server.onShutdown(() => process.removeListener('SIGTERM', onSigterm));
        }
    }
    return { api, metricsApi, grpcServer };
};
exports.start = start;
const expose = async (adapter, dependencies) => {
    const { api, metricsApi, grpcServer } = await (0, exports.start)(adapter, dependencies);
    const settings = adapter.config.settings;
    const exposeApp = async (app, port, host = settings.EA_HOST) => {
        if (app) {
            try {
                await app.listen({ port, host });
            }
            catch (err) {
                (0, util_1.censorLogs)(() => logger.fatal(`There was an error when starting the server: ${err}`));
                process.exit();
            }
            const address = app.serverInstance.address();
            logger.info(`Listening on port ${typeof address === 'object' ? address?.port : address}`);
        }
    };
    if (api && grpcServer && (0, config_1.grpcPortSharingEnabled)(settings)) {
        // GRPC_PORT equals EA_PORT: share one real, plaintext listener between fastify and the gRPC
        // server via the port multiplexer, instead of binding each its own port. Both still bind a real
        // server of their own, just to an internal, loopback-only port the multiplexer forwards into. See
        // src/grpc/port-mux.ts.
        // Registered before api.listen(), since fastify rejects addHook once a listener already exists.
        // muxServer is assigned below, well before this can actually be invoked.
        let muxServer;
        let muxClosed = false;
        const closeMux = () => {
            if (!muxClosed) {
                muxClosed = true;
                muxServer?.close();
            }
        };
        api.addHook('onClose', async () => closeMux());
        try {
            await api.listen({ port: 0, host: '127.0.0.1' });
        }
        catch (err) {
            (0, util_1.censorLogs)(() => logger.fatal(`There was an error when starting the server: ${err}`));
            process.exit();
        }
        const httpPort = api.serverInstance.address().port;
        let grpcInternalPort;
        try {
            grpcInternalPort = await grpcServer.listen((0, exports.getGrpcCredentials)(settings), {
                host: '127.0.0.1',
                port: 0,
            });
        }
        catch (err) {
            (0, util_1.censorLogs)(() => logger.fatal(`There was an error when starting the gRPC server: ${err}`));
            process.exit();
        }
        grpcServer.onShutdown(closeMux);
        try {
            muxServer = await (0, grpc_1.listenPortMultiplexer)({
                host: settings.EA_HOST,
                port: settings.EA_PORT,
                httpTarget: { host: '127.0.0.1', port: httpPort },
                grpcTarget: { host: '127.0.0.1', port: grpcInternalPort },
            });
        }
        catch (err) {
            (0, util_1.censorLogs)(() => logger.fatal(`There was an error when starting the shared REST/gRPC listener: ${err}`));
            process.exit();
        }
        // Not settings.EA_PORT verbatim: that is 0 when the OS is left to pick, in which case it is the
        // multiplexer's actual bound port (read off its own listening socket) that is correct.
        const sharedPort = muxServer.address().port;
        logger.info(`Listening on port ${sharedPort} (REST and gRPC streaming share this listener)`);
    }
    else {
        // Start listening for incoming requests
        await exposeApp(api, settings.EA_PORT);
        if (grpcServer) {
            try {
                const port = await grpcServer.listen((0, exports.getGrpcCredentials)(settings));
                logger.info(`gRPC streaming server listening on port ${port}`);
            }
            catch (err) {
                (0, util_1.censorLogs)(() => logger.fatal(`There was an error when starting the gRPC server: ${err}`));
                process.exit();
            }
        }
    }
    await exposeApp(metricsApi, settings.METRICS_PORT);
    // Make sure the cache lock has been acquired before returning
    if (adapter.lockAcquiredPromise) {
        try {
            await adapter.lockAcquiredPromise;
        }
        catch (error) {
            await api?.close();
            await metricsApi?.close();
            await grpcServer?.shutdown();
            throw error;
        }
    }
    // We return only the main API to maintain backwards compatibility
    return api;
};
exports.expose = expose;
async function buildRestApi(adapter) {
    const TLSOptions = (0, exports.getTLSOptions)(adapter.config.settings);
    const app = new server_1.App({
        ...TLSOptions,
        bodyLimit: adapter.config.settings.MAX_PAYLOAD_SIZE_LIMIT,
    });
    // Add healthcheck endpoint before middlewares to bypass them
    app.get((0, path_1.join)(adapter.config.settings.BASE_URL, 'health'), (_req, res) => {
        res.status(200).send({ message: 'OK', version: VERSION });
    });
    // If specified, serve debug endpoints to assist in issue triaging
    if (adapter.config.settings.DEBUG_ENDPOINTS === true) {
        (0, router_1.default)(app, adapter);
        logger.info('Serving debug endpoints');
    }
    // Register status endpoint
    (0, router_2.default)(app, adapter);
    // Use global error handling
    app.setErrorHandler(validation_1.errorCatchingMiddleware);
    // Always reply with json content
    app.addHook('preHandler', (_, reply, done) => {
        reply.headers({ 'content-type': 'application/json; charset=utf-8' });
        done();
    });
    app.register((router) => {
        // Set up "middlewares" (hooks)
        router.addHook('preHandler', (0, validation_1.validatorMiddleware)(adapter));
        if (adapter.config.settings.CORRELATION_ID_ENABLED) {
            router.addHook('onRequest', util_1.loggingContextMiddleware);
        }
        router.route({
            url: adapter.config.settings.BASE_URL,
            method: 'POST',
            handler: async (req, reply) => {
                const response = await adapter.handleRequestWithValidation(req, reply);
                return reply.code(response.statusCode || 200).send(response);
            },
        });
        if (adapter.config.settings.METRICS_ENABLED &&
            adapter.config.settings.EXPERIMENTAL_METRICS_ENABLED) {
            router.addHook('onResponse', metrics_1.buildMetricsMiddleware);
        }
    });
    return app;
}
//# sourceMappingURL=index.js.map