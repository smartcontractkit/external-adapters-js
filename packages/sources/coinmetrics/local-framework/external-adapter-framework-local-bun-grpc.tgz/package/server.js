"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.App = exports.ServerReply = exports.ServerRequest = exports.HttpError = void 0;
/**
 * Minimal HTTP server layer built on Bun.serve, replacing the framework's
 * previous fastify dependency. It implements only the subset of the fastify
 * API surface that the framework (and adapters built on it) use:
 *
 *  - `get` / `route` route registration (exact paths only)
 *  - `addHook` with `onRequest` / `preHandler` / `onResponse` / `onClose`
 *  - `register` encapsulated scopes (routes inherit ancestor hooks)
 *  - `setErrorHandler`
 *  - `listen` / `close` / `server.address()`
 *  - `inject` for in-process testing (light-my-request equivalent)
 */
const node_tls_1 = require("node:tls");
const logger_1 = require("./util/logger");
const logger = (0, logger_1.makeLogger)('HttpServer');
/**
 * Error type for HTTP-layer failures (body parsing, payload limits, unknown routes).
 * Replaces the FastifyError checks previously done in the error handling middleware.
 */
class HttpError extends Error {
    statusCode;
    constructor(message, statusCode) {
        super(message);
        this.statusCode = statusCode;
        this.name = 'HttpError';
    }
}
exports.HttpError = HttpError;
class ServerRequest {
    raw;
    headers = {};
    method;
    url;
    body;
    // Filled in by the validation middleware; loosely typed here to avoid a
    // circular dependency with util/types (AdapterRequest narrows it properly)
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    requestContext;
    constructor(raw, bodyText, bodyLimit) {
        this.raw = raw;
        this.method = raw.method.toUpperCase();
        this.url = new URL(raw.url).pathname;
        raw.headers.forEach((value, key) => {
            this.headers[key.toLowerCase()] = value;
        });
        if (bodyText === undefined || this.method === 'GET' || this.method === 'HEAD') {
            return;
        }
        if (bodyLimit && bodyText.length > bodyLimit) {
            throw new HttpError('Request body is too large', 413);
        }
        // Only JSON bodies are parsed; anything else is left raw so that the
        // validation middleware can reject it with a 400 (framework behavior spec)
        const contentType = this.headers['content-type'];
        if (contentType !== 'application/json') {
            this.body = bodyText;
            return;
        }
        if (!bodyText.length) {
            throw new HttpError('Body cannot be empty when content-type is set to application/json', 400);
        }
        try {
            this.body = JSON.parse(bodyText);
        }
        catch {
            throw new HttpError('Body is not valid JSON', 400);
        }
    }
}
exports.ServerRequest = ServerRequest;
class ServerReply {
    requestStart;
    statusCode = 200;
    sent = false;
    elapsedTime = 0;
    responseHeaders = {};
    payload;
    sentResolve;
    // Thenable so it can be awaited where the "reply sent" signal is needed
    sentPromise;
    constructor(requestStart) {
        this.requestStart = requestStart;
        this.sentPromise = new Promise((resolve) => {
            this.sentResolve = resolve;
        });
    }
    then(onfulfilled, onrejected) {
        return this.sentPromise.then(onfulfilled, onrejected);
    }
    code(statusCode) {
        this.statusCode = statusCode;
        return this;
    }
    status(statusCode) {
        return this.code(statusCode);
    }
    headers(headers) {
        Object.assign(this.responseHeaders, headers);
        return this;
    }
    type(contentType) {
        this.responseHeaders['content-type'] = contentType;
        return this;
    }
    getHeader(name) {
        return this.responseHeaders[name.toLowerCase()];
    }
    send(payload) {
        if (this.sent) {
            throw new Error('Reply was already sent');
        }
        this.sent = true;
        this.elapsedTime = Date.now() - this.requestStart;
        this.payload = payload;
        if (payload !== undefined && typeof payload === 'object') {
            this.responseHeaders['content-type'] ??= 'application/json; charset=utf-8';
        }
        this.sentResolve();
        return this;
    }
    toResponse() {
        if (!this.sent) {
            this.send(undefined);
        }
        let body;
        if (this.payload === undefined) {
            body = undefined;
        }
        else if (typeof this.payload === 'object') {
            body = JSON.stringify(this.payload);
        }
        else {
            body = String(this.payload);
        }
        return new Response(body ?? null, {
            status: this.statusCode,
            headers: this.responseHeaders,
        });
    }
}
exports.ServerReply = ServerReply;
const defaultErrorHandler = (err, _req, reply) => {
    logger.error(err);
    reply.status(500).send(err.message || 'There was an unexpected error in the adapter.');
};
class App {
    options;
    routes = [];
    rootHooks = {};
    errorHandler = defaultErrorHandler;
    pendingRegistrations = [];
    server;
    // Transitional: the legacy ava test runner executes under Node.js, which has no
    // Bun global. A node:http fallback keeps `listen()` working there until the
    // test suite migrates to bun:test (Phase 3), after which this can be removed.
    nodeServer;
    constructor(options = {}) {
        this.options = options;
        if (options.https) {
            // Validate TLS material eagerly so misconfiguration fails at startup,
            // matching the behavior of the previous fastify-based server
            (0, node_tls_1.createSecureContext)({
                key: options.https.key,
                cert: options.https.cert,
                ca: options.https.ca,
                passphrase: options.https.passphrase,
            });
        }
    }
    get(path, handler) {
        this.route({ method: 'GET', url: path, handler });
    }
    route(opts, scopes = []) {
        this.routes.push({
            method: opts.method.toUpperCase(),
            path: normalizePath(opts.url),
            handler: opts.handler,
            scopes,
        });
    }
    addHook(name, hook, scope) {
        const target = scope ?? this.rootHooks;
        if (!target[name]) {
            target[name] = [];
        }
        target[name].push(hook);
    }
    register(fn) {
        const scope = {};
        this.pendingRegistrations.push(Promise.resolve(fn(new ScopedApp(this, scope))));
    }
    setErrorHandler(fn) {
        this.errorHandler = fn;
    }
    async listen(listenOptions) {
        await Promise.all(this.pendingRegistrations);
        const hostname = listenOptions.hostname ?? listenOptions.host ?? '0.0.0.0';
        const protocol = this.options.https ? 'https' : 'http';
        if (typeof Bun !== 'undefined') {
            this.server = Bun.serve({
                port: listenOptions.port,
                hostname,
                tls: this.options.https
                    ? {
                        key: this.options.https.key,
                        cert: this.options.https.cert,
                        ca: this.options.https.ca,
                        passphrase: this.options.https.passphrase,
                        requestCert: this.options.https.requestCert,
                    }
                    : undefined,
                fetch: async (rawRequest) => {
                    const bodyText = await rawRequest.text().catch(() => undefined);
                    return this.handle(rawRequest, bodyText);
                },
            });
            return `${protocol}://${hostname}:${this.server.port}`;
        }
        // Transitional Node.js fallback (see note on the nodeServer field)
        const requestListener = async (nodeReq, nodeRes) => {
            const chunks = [];
            for await (const chunk of nodeReq) {
                chunks.push(chunk);
            }
            const bodyText = chunks.length ? Buffer.concat(chunks).toString('utf-8') : undefined;
            const headers = {};
            for (const [key, value] of Object.entries(nodeReq.headers)) {
                if (typeof value === 'string') {
                    headers[key] = value;
                }
            }
            const rawRequest = new Request(`http://${hostname}${nodeReq.url}`, {
                method: nodeReq.method,
                headers,
            });
            const response = await this.handle(rawRequest, bodyText);
            nodeRes.writeHead(response.status, Object.fromEntries(response.headers.entries()));
            nodeRes.end(await response.text());
        };
        if (this.options.https) {
            const { createServer } = await Promise.resolve().then(() => __importStar(require('node:https')));
            this.nodeServer = createServer({
                key: this.options.https.key,
                cert: this.options.https.cert,
                ca: this.options.https.ca,
                passphrase: this.options.https.passphrase,
                requestCert: this.options.https.requestCert,
                rejectUnauthorized: this.options.https.requestCert,
            }, requestListener);
        }
        else {
            const { createServer } = await Promise.resolve().then(() => __importStar(require('node:http')));
            this.nodeServer = createServer(requestListener);
        }
        await new Promise((resolve, reject) => {
            this.nodeServer.once('error', reject);
            this.nodeServer.listen(listenOptions.port, hostname, () => resolve());
        });
        const address = this.nodeServer.address();
        const port = typeof address === 'object' && address ? address.port : listenOptions.port;
        return `${protocol}://${hostname}:${port}`;
    }
    /** Shim over the underlying server to keep the fastify `app.server.address()` API */
    get serverInstance() {
        return {
            address: () => {
                if (this.nodeServer) {
                    return this.nodeServer.address();
                }
                return { address: this.server?.hostname, family: 'IPv4', port: this.server?.port };
            },
        };
    }
    async close() {
        for (const hook of this.rootHooks['onClose'] ?? []) {
            await hook({}, {}, () => undefined);
        }
        if (this.nodeServer) {
            const server = this.nodeServer;
            await new Promise((resolve) => {
                server.close(() => resolve());
            });
        }
        await this.server?.stop(true);
    }
    async inject(opts) {
        await Promise.all(this.pendingRegistrations);
        // Yield to the event loop once. light-my-request (fastify's inject) dispatched
        // through macrotasks, and test helpers that spin fake timers rely on there
        // being an immediate pending task instead of jumping to the next real timer.
        await new Promise((resolve) => {
            setImmediate(resolve);
        });
        const options = typeof opts === 'string' ? { url: opts } : opts;
        const url = options.url ?? options.path ?? '/';
        const method = (options.method ?? 'GET').toUpperCase();
        const payload = options.payload;
        let body;
        if (typeof payload === 'string') {
            body = payload;
        }
        else if (payload !== undefined) {
            body = JSON.stringify(payload);
        }
        const rawRequest = new Request(`http://localhost${url}`, {
            method,
            headers: options.headers,
            body,
        });
        const response = await this.handle(rawRequest, body);
        const responseBody = await response.text();
        const headers = {};
        response.headers.forEach((value, key) => {
            headers[key.toLowerCase()] = value;
        });
        return {
            statusCode: response.status,
            headers,
            body: responseBody,
            payload: responseBody,
            json: () => JSON.parse(responseBody),
        };
    }
    async handle(rawRequest, bodyText) {
        const requestStart = Date.now();
        const reply = new ServerReply(requestStart);
        let req;
        try {
            req = new ServerRequest(rawRequest, bodyText, this.options.bodyLimit ?? 0);
        }
        catch (err) {
            req = { headers: {}, requestContext: undefined, body: undefined };
            await this.errorHandler(err, req, reply);
            return reply.toResponse();
        }
        const route = this.routes.find((r) => r.method === req.method && r.path === normalizePath(req.url));
        if (!route) {
            reply.status(404).send({
                message: `Route ${req.method} ${req.url} not found`,
                error: 'Not Found',
                statusCode: 404,
            });
            return reply.toResponse();
        }
        // The lifecycle is intentionally continuation-based: hooks receive a `done`
        // callback and the rest of the pipeline executes inside it. This preserves
        // AsyncLocalStorage contexts set up by hooks (e.g. the correlation-id
        // middleware), which would be lost across plain `await` boundaries.
        try {
            await this.runHooks(route, req, reply, 'onRequest', () => this.runHooks(route, req, reply, 'preHandler', async () => {
                if (!reply.sent) {
                    const result = await route.handler(req, reply);
                    if (!reply.sent && result !== undefined) {
                        reply.send(result);
                    }
                }
            }));
        }
        catch (err) {
            await this.errorHandler(err, req, reply);
        }
        // OnResponse hooks run for error responses too (metrics middleware relies on this)
        await this.runHooks(route, req, reply, 'onResponse', async () => undefined).catch((err) => {
            logger.error(`Error in onResponse hook: ${err}`);
        });
        return reply.toResponse();
    }
    // eslint-disable-next-line max-params
    async runHooks(route, req, reply, name, continuation) {
        const hooks = [this.rootHooks, ...route.scopes].flatMap((scope) => scope[name] ?? []);
        let index = 0;
        const runNext = () => new Promise((resolve, reject) => {
            const hook = hooks[index++];
            if (!hook) {
                continuation().then(resolve, reject);
                return;
            }
            const done = (err) => {
                if (err) {
                    reject(err);
                }
                else {
                    runNext().then(resolve, reject);
                }
            };
            try {
                const result = hook(req, reply, done);
                if (result instanceof Promise) {
                    result.catch(reject);
                }
            }
            catch (err) {
                reject(err);
            }
        });
        return runNext();
    }
}
exports.App = App;
/** Scoped view of an App handed to `register` callbacks (fastify encapsulation) */
class ScopedApp {
    app;
    scope;
    constructor(app, scope) {
        this.app = app;
        this.scope = scope;
    }
    addHook(name, hook) {
        this.app.addHook(name, hook, this.scope);
    }
    route(opts) {
        const methods = Array.isArray(opts.method) ? opts.method : [opts.method];
        for (const method of methods) {
            this.app.route({ ...opts, method }, [this.scope]);
        }
    }
    get(path, handler) {
        this.route({ method: 'GET', url: path, handler });
    }
}
const normalizePath = (path) => {
    const normalized = path.replace(/\/+/g, '/');
    return normalized.length > 1 && normalized.endsWith('/') ? normalized.slice(0, -1) : normalized;
};
//# sourceMappingURL=server.js.map