export type HookHandlerDoneFunction = (err?: unknown) => void;
export type ServerHook = (req: ServerRequest, reply: ServerReply, done: HookHandlerDoneFunction) => unknown;
export type RouteHandler = (req: ServerRequest, reply: ServerReply) => unknown;
export type ServerErrorHandler = (err: Error, req: ServerRequest, reply: ServerReply) => void | Promise<unknown>;
type HookName = 'onRequest' | 'preHandler' | 'onResponse' | 'onClose';
/**
 * Error type for HTTP-layer failures (body parsing, payload limits, unknown routes).
 * Replaces the FastifyError checks previously done in the error handling middleware.
 */
export declare class HttpError extends Error {
    statusCode: number;
    constructor(message: string, statusCode: number);
}
interface TlsOptions {
    key: string;
    cert: string;
    ca: string;
    passphrase?: string;
    requestCert: boolean;
}
export interface ServerOptions {
    bodyLimit?: number;
    https?: TlsOptions;
}
type ScopeHooks = Partial<Record<HookName, ServerHook[]>>;
export declare class ServerRequest {
    readonly raw: Request;
    readonly headers: Record<string, string | undefined>;
    readonly method: string;
    readonly url: string;
    body: unknown;
    requestContext?: any;
    constructor(raw: Request, bodyText: string | undefined, bodyLimit: number);
}
export declare class ServerReply {
    private readonly requestStart;
    statusCode: number;
    sent: boolean;
    elapsedTime: number;
    private responseHeaders;
    private payload;
    private sentResolve;
    private sentPromise;
    constructor(requestStart: number);
    then<TResult1 = void, TResult2 = never>(onfulfilled?: ((value: void) => TResult1 | PromiseLike<TResult1>) | null, onrejected?: ((reason: unknown) => TResult2 | PromiseLike<TResult2>) | null): Promise<TResult1 | TResult2>;
    code(statusCode: number): this;
    status(statusCode: number): this;
    headers(headers: Record<string, string>): this;
    type(contentType: string): this;
    getHeader(name: string): string | undefined;
    send(payload?: unknown): this;
    toResponse(): Response;
}
export interface InjectOptions {
    method?: string;
    url?: string;
    path?: string;
    headers?: Record<string, string>;
    payload?: unknown;
}
export interface InjectResponse {
    statusCode: number;
    headers: Record<string, string>;
    body: string;
    payload: string;
    json: () => any;
}
export declare class App {
    private readonly options;
    private routes;
    private rootHooks;
    private errorHandler;
    private pendingRegistrations;
    private server?;
    private nodeServer?;
    constructor(options?: ServerOptions);
    get(path: string, handler: RouteHandler): void;
    route(opts: {
        method: string;
        url: string;
        handler: RouteHandler;
    }, scopes?: ScopeHooks[]): void;
    addHook(name: HookName, hook: ServerHook, scope?: ScopeHooks): void;
    register(fn: (router: ScopedApp) => unknown): void;
    setErrorHandler(fn: ServerErrorHandler): void;
    listen(listenOptions: {
        port: number;
        host?: string;
        hostname?: string;
    }): Promise<string>;
    /** Shim over the underlying server to keep the fastify `app.server.address()` API */
    get serverInstance(): {
        address: () => string | {
            address: string | undefined;
            family: string;
            port: number | undefined;
        } | null;
    };
    close(): Promise<void>;
    inject(opts: string | InjectOptions): Promise<InjectResponse>;
    private handle;
    private runHooks;
}
/** Scoped view of an App handed to `register` callbacks (fastify encapsulation) */
declare class ScopedApp {
    private readonly app;
    private readonly scope;
    constructor(app: App, scope: ScopeHooks);
    addHook(name: HookName, hook: ServerHook): void;
    route(opts: {
        method: string | string[];
        url: string;
        handler: RouteHandler;
    }): void;
    get(path: string, handler: RouteHandler): void;
}
export {};
