/**
 * Minimal HTTP client over the runtime's native `fetch`, replacing axios.
 *
 * The config/response types intentionally keep the field names of the axios
 * API surface that adapters use (`url`, `method`, `headers`, `params`,
 * `data`, `timeout`, `baseURL`, `responseType`, `paramsSerializer`, `auth`),
 * so adapter request builders need little to no changes. Semantics that fetch
 * does not provide natively are replicated here:
 *  - non-2xx statuses reject with an HttpRequestError carrying `response`
 *  - `timeout` is enforced via AbortSignal
 *  - `params` are serialized into the query string
 *  - object `data` payloads are JSON-serialized with the proper content-type
 */
export interface RequestAuth {
    username: string;
    password: string;
}
export interface RequestConfig<T = unknown> {
    /** Request URL (absolute, or relative if baseURL is set) */
    url?: string;
    /** Base URL prepended to `url` when `url` is relative */
    baseURL?: string;
    /** HTTP method (default 'GET') */
    method?: string;
    /** Request headers */
    headers?: Record<string, string>;
    /** Query parameters to serialize into the URL */
    params?: Record<string, unknown>;
    /** Custom serializer for `params` */
    paramsSerializer?: (params: Record<string, unknown>) => string;
    /** Request body; objects are JSON-serialized */
    data?: T;
    /** Request timeout in ms (0 = no timeout) */
    timeout?: number;
    /** Response parsing mode; only 'json' and 'text' are supported */
    responseType?: 'json' | 'text';
    /** HTTP basic auth credentials */
    auth?: RequestAuth;
}
export interface HttpResponse<T = any> {
    status: number;
    statusText: string;
    data: T;
    headers: Record<string, string>;
}
/**
 * Error thrown for failed requests, translating fetch semantics into the
 * axios-shaped error handling the framework relied on:
 *  - HTTP error statuses (4xx/5xx) reject with `response` populated
 *  - Network/connection failures reject with `response` undefined
 *  - Timeouts reject with `code === 'ECONNABORTED'`
 */
export declare class HttpRequestError extends Error {
    /** Populated when the server responded with an error status */
    response?: HttpResponse;
    /** Axios-compatible error code ('ECONNABORTED' for timeouts) */
    code?: string;
    constructor(message: string, options?: {
        response?: HttpResponse;
        code?: string;
        cause?: unknown;
    });
    /** Axios compatibility: the HTTP status of the failed request, if any */
    get status(): number | undefined;
}
export declare const defaultParamsSerializer: (params: Record<string, unknown>) => string;
export declare const buildRequestUrl: (config: RequestConfig) => string;
/**
 * Symbol used to attach the original RequestConfig to the fetch init object,
 * so that test mocks can inspect the full request (timeout, params, etc.)
 * which is not recoverable from the fetch arguments themselves.
 */
export declare const REQUEST_CONFIG_SYMBOL: unique symbol;
/**
 * Executes an HTTP request using the runtime's native fetch, with
 * axios-compatible semantics (see {@link HttpRequestError}).
 */
export declare const executeHttpRequest: <T = unknown>(config: RequestConfig) => Promise<HttpResponse<T>>;
