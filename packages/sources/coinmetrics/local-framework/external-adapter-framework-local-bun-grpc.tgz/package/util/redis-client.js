"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FrameworkRedisClient = exports.RedisCommandError = void 0;
/**
 * Lua script that skips overwriting a successful cached response with an
 * error response. Previously registered via ioredis' defineCommand.
 */
const SET_EA_RESPONSE_LUA = `local key = KEYS[1]
  local value = ARGV[1]
  local ttl = tonumber(ARGV[2])
  local json_value = cjson.decode(value)
  local key_exists = redis.call('EXISTS', key)
  if json_value.errorMessage and key_exists == 1 then
    local existing_json_value = cjson.decode(redis.call('GET', key))
      if existing_json_value.errorMessage then
        return redis.call('SET', key, value, 'PX', ttl)
      else
        return nil
      end
  else
    return redis.call('SET', key, value, 'PX', ttl)
  end`;
/**
 * Error wrapper that tags Redis command failures with the command name,
 * replacing ioredis' ReplyError (which carried `command.name`).
 */
class RedisCommandError extends Error {
    command;
    constructor(message, command) {
        super(message);
        this.command = command;
        this.name = 'RedisCommandError';
    }
}
exports.RedisCommandError = RedisCommandError;
const getRedisClientCtor = () => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const ctor = globalThis.Bun?.RedisClient;
    if (!ctor) {
        throw new Error('The native Redis client requires the Bun runtime. If you are seeing this outside of Bun, inject a compatible client via dependencies instead.');
    }
    return ctor;
};
class FrameworkRedisClient {
    clientOptions;
    // Created lazily on first command so that constructing the client (e.g. in
    // test setups running under Node.js) does not require the Bun runtime
    client;
    connectListeners = [];
    /** Resolved connection options (exposed for parity with ioredis' client.options) */
    options;
    url;
    constructor(clientOptions = {}) {
        this.clientOptions = clientOptions;
        this.url =
            clientOptions.url ??
                `redis://${clientOptions.password ? `:${clientOptions.password}@` : ''}${clientOptions.host ?? 'localhost'}:${clientOptions.port ?? 6379}`;
        const parsed = new URL(this.url.replace(/^redis(s|)\+unix:/, 'redis:').replace(/^rediss:/, 'redis:'));
        this.options = {
            host: parsed.hostname || 'localhost',
            port: parsed.port ? Number(parsed.port) : 6379,
        };
    }
    getClient() {
        if (!this.client) {
            const options = {
                connectionTimeout: this.clientOptions.connectTimeout,
                maxRetries: this.clientOptions.maxRetries,
                enableAutoPipelining: this.clientOptions.enableAutoPipelining,
            };
            if (this.clientOptions.tls !== undefined) {
                options.tls = this.clientOptions.tls;
            }
            const client = new (getRedisClientCtor())(this.url, options);
            client.onconnect = () => {
                for (const listener of this.connectListeners) {
                    listener();
                }
            };
            if (this.clientOptions.onClose) {
                client.onclose = this.clientOptions.onClose;
            }
            this.client = client;
        }
        return this.client;
    }
    on(event, listener) {
        if (event === 'connect') {
            this.connectListeners.push(listener);
        }
        return this;
    }
    /** Sends a raw command, tagging failures with the command name */
    async send(command, ...args) {
        try {
            return (await this.getClient().send(command, args.map(String)));
        }
        catch (e) {
            const err = e;
            // Preserve NOSCRIPT errors verbatim so redlock's EVAL fallback triggers
            if (err.message.startsWith('NOSCRIPT')) {
                throw err;
            }
            throw new RedisCommandError(err.message, command.toLowerCase());
        }
    }
    async get(key) {
        return this.send('GET', key);
    }
    async del(key) {
        return this.send('DEL', key);
    }
    async pexpire(key, ttl) {
        return this.send('PEXPIRE', key, ttl);
    }
    async set(key, value, px, ttl) {
        return this.send('SET', key, value, px, ttl);
    }
    /**
     * Sets a key only if it wouldn't overwrite a successful cached response
     * with an error response (see the Lua script above).
     */
    async setExternalAdapterResponse(key, value, ttl) {
        return this.send('EVAL', SET_EA_RESPONSE_LUA, 1, key, value, ttl);
    }
    /** Batched command execution (MULTI/EXEC) for the cache's setMany */
    multi() {
        const commands = [];
        const chain = {
            setExternalAdapterResponse: (key, value, ttl) => {
                commands.push(['EVAL', [SET_EA_RESPONSE_LUA, 1, key, value, ttl]]);
                return chain;
            },
            exec: async () => {
                await this.send('MULTI');
                try {
                    for (const [command, args] of commands) {
                        // Commands sent between MULTI and EXEC return QUEUED
                        await this.getClient().send(command, args.map(String));
                    }
                    return (await this.send('EXEC')) ?? [];
                }
                catch (e) {
                    await this.send('DISCARD').catch(() => undefined);
                    throw e;
                }
            },
        };
        return chain;
    }
    async zadd(key, score, member) {
        return this.send('ZADD', key, score, member);
    }
    async zrange(key, start, stop) {
        return this.send('ZRANGE', key, start, stop);
    }
    async zremrangebyscore(key, min, max) {
        return this.send('ZREMRANGEBYSCORE', key, min, max);
    }
    /** Redlock-compatible evalsha (note the array-wrapped keys and args) */
    async evalsha(sha, numKeys, keysAndArgs) {
        return this.send('EVALSHA', sha, numKeys, ...keysAndArgs);
    }
    /** Redlock-compatible eval fallback for NOSCRIPT errors */
    async eval(script, numKeys, keysAndArgs) {
        return this.send('EVAL', script, numKeys, ...keysAndArgs);
    }
    quit() {
        this.client?.close();
    }
    /** Alias kept for familiarity with other redis clients */
    disconnect() {
        this.client?.close();
    }
}
exports.FrameworkRedisClient = FrameworkRedisClient;
//# sourceMappingURL=redis-client.js.map