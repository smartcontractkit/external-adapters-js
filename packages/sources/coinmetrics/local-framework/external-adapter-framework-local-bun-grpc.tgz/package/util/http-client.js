"use strict";
/**
 * Minimal HTTP client over the runtime's native `fetch`, replacing axios.
 *
 * The config/response types intentionally keep the field names of the axios
 * API surface that adapters use (`url`, `method`, `headers`, `params`,
 * `data`, `timeout`, `baseURL`, `responseType`, `paramsSerializer`, `auth`),
 * so adapter request builders need little to no changes. Semantics that fetch
 * does not provide natively are replicated here:
 *  - non-2xx statuses reject with an HttpRequestError carrying `response`
 *  - `timeout` is enforced via AbortSignal
 *  - `params` are serialized into the query string
 *  - object `data` payloads are JSON-serialized with the proper content-type
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.executeHttpRequest = exports.REQUEST_CONFIG_SYMBOL = exports.buildRequestUrl = exports.defaultParamsSerializer = exports.HttpRequestError = void 0;
/**
 * Error thrown for failed requests, translating fetch semantics into the
 * axios-shaped error handling the framework relied on:
 *  - HTTP error statuses (4xx/5xx) reject with `response` populated
 *  - Network/connection failures reject with `response` undefined
 *  - Timeouts reject with `code === 'ECONNABORTED'`
 */
class HttpRequestError extends Error {
    /** Populated when the server responded with an error status */
    response;
    /** Axios-compatible error code ('ECONNABORTED' for timeouts) */
    code;
    constructor(message, options = {}) {
        super(message, { cause: options.cause });
        this.name = 'HttpRequestError';
        this.response = options.response;
        this.code = options.code;
    }
    /** Axios compatibility: the HTTP status of the failed request, if any */
    get status() {
        return this.response?.status;
    }
}
exports.HttpRequestError = HttpRequestError;
const defaultParamsSerializer = (params) => {
    const searchParams = new URLSearchParams();
    for (const [key, value] of Object.entries(params)) {
        if (value === undefined || value === null) {
            continue;
        }
        if (Array.isArray(value)) {
            for (const item of value) {
                searchParams.append(key, String(item));
            }
        }
        else {
            searchParams.append(key, String(value));
        }
    }
    return searchParams.toString();
};
exports.defaultParamsSerializer = defaultParamsSerializer;
const buildRequestUrl = (config) => {
    let url = config.url ?? '';
    if (config.baseURL && !/^https?:\/\//i.test(url)) {
        url = `${config.baseURL.replace(/\/$/, '')}/${url.replace(/^\//, '')}`;
    }
    if (config.params && Object.keys(config.params).length) {
        const serialize = config.paramsSerializer ?? exports.defaultParamsSerializer;
        const serialized = serialize(config.params);
        if (serialized) {
            url += `${url.includes('?') ? '&' : '?'}${serialized}`;
        }
    }
    return url;
};
exports.buildRequestUrl = buildRequestUrl;
/**
 * Symbol used to attach the original RequestConfig to the fetch init object,
 * so that test mocks can inspect the full request (timeout, params, etc.)
 * which is not recoverable from the fetch arguments themselves.
 */
exports.REQUEST_CONFIG_SYMBOL = Symbol.for('ea.framework.requestConfig');
/**
 * Executes an HTTP request using the runtime's native fetch, with
 * axios-compatible semantics (see {@link HttpRequestError}).
 */
const executeHttpRequest = async (config) => {
    const url = (0, exports.buildRequestUrl)(config);
    const method = (config.method ?? 'GET').toUpperCase();
    const headers = { ...(config.headers ?? {}) };
    let body;
    if (config.data !== undefined) {
        if (typeof config.data === 'string') {
            body = config.data;
        }
        else {
            body = JSON.stringify(config.data);
            if (!Object.keys(headers).some((h) => h.toLowerCase() === 'content-type')) {
                headers['content-type'] = 'application/json';
            }
        }
    }
    if (config.auth) {
        const credentials = Buffer.from(`${config.auth.username}:${config.auth.password}`).toString('base64');
        headers['authorization'] = `Basic ${credentials}`;
    }
    const timeout = config.timeout ?? 0;
    const signal = timeout > 0 ? AbortSignal.timeout(timeout) : undefined;
    let response;
    try {
        response = await fetch(url, {
            method,
            headers,
            body,
            signal,
            [exports.REQUEST_CONFIG_SYMBOL]: config,
        });
    }
    catch (e) {
        const err = e;
        if (err.name === 'TimeoutError' || err.name === 'AbortError') {
            throw new HttpRequestError(`timeout of ${timeout}ms exceeded`, {
                code: 'ECONNABORTED',
                cause: e,
            });
        }
        throw new HttpRequestError(err.message, { cause: e });
    }
    const responseHeaders = {};
    response.headers.forEach((value, key) => {
        responseHeaders[key.toLowerCase()] = value;
    });
    const rawBody = await response.text();
    let data = rawBody;
    if (config.responseType !== 'text') {
        try {
            data = rawBody ? JSON.parse(rawBody) : null;
        }
        catch {
            // Non-JSON response bodies are returned as raw text, like axios with
            // a failed transitional parse
            data = rawBody;
        }
    }
    const result = {
        status: response.status,
        statusText: response.statusText,
        data: data,
        headers: responseHeaders,
    };
    if (response.status >= 400) {
        throw new HttpRequestError(`Request failed with status code ${response.status}`, {
            response: result,
        });
    }
    return result;
};
exports.executeHttpRequest = executeHttpRequest;
//# sourceMappingURL=http-client.js.map