export interface FrameworkRedisClientOptions {
    /** Full redis:// or rediss:// URL; takes precedence over host/port/password */
    url?: string;
    host?: string;
    port?: number;
    password?: string;
    /** Connection timeout in ms */
    connectTimeout?: number;
    /** Max reconnection attempts (Bun default: 10) */
    maxRetries?: number;
    enableAutoPipelining?: boolean;
    /** TLS options for rediss:// connections */
    tls?: boolean | Record<string, unknown>;
    /** Called when the connection is (re)established */
    onConnect?: () => void;
    /** Called when the connection is lost; receives the error */
    onClose?: (error: Error) => void;
}
/**
 * Error wrapper that tags Redis command failures with the command name,
 * replacing ioredis' ReplyError (which carried `command.name`).
 */
export declare class RedisCommandError extends Error {
    readonly command: string;
    constructor(message: string, command: string);
}
type CommandArg = string | number;
export declare class FrameworkRedisClient {
    private readonly clientOptions;
    private client?;
    private connectListeners;
    /** Resolved connection options (exposed for parity with ioredis' client.options) */
    readonly options: {
        host: string;
        port: number;
    };
    private readonly url;
    constructor(clientOptions?: FrameworkRedisClientOptions);
    private getClient;
    on(event: 'connect', listener: () => void): this;
    /** Sends a raw command, tagging failures with the command name */
    private send;
    get(key: string): Promise<string | null>;
    del(key: string): Promise<number>;
    pexpire(key: string, ttl: number): Promise<number>;
    set(key: string, value: string, px: 'PX', ttl: number): Promise<unknown>;
    /**
     * Sets a key only if it wouldn't overwrite a successful cached response
     * with an error response (see the Lua script above).
     */
    setExternalAdapterResponse(key: string, value: string, ttl: number): Promise<unknown>;
    /** Batched command execution (MULTI/EXEC) for the cache's setMany */
    multi(): {
        setExternalAdapterResponse: (key: string, value: string, ttl: number) => /*elided*/ any;
        exec: () => Promise<unknown[]>;
    };
    zadd(key: string, score: number, member: string): Promise<number>;
    zrange(key: string, start: number, stop: number): Promise<string[]>;
    zremrangebyscore(key: string, min: number | '-inf', max: number | '+inf'): Promise<number>;
    /** Redlock-compatible evalsha (note the array-wrapped keys and args) */
    evalsha(sha: string, numKeys: number, keysAndArgs: CommandArg[]): Promise<unknown>;
    /** Redlock-compatible eval fallback for NOSCRIPT errors */
    eval(script: string, numKeys: number, keysAndArgs: CommandArg[]): Promise<unknown>;
    quit(): void;
    /** Alias kept for familiarity with other redis clients */
    disconnect(): void;
}
export {};
