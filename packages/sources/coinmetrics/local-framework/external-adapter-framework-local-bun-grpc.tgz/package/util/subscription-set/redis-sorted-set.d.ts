import { FrameworkRedisClient } from '../redis-client';
import { SubscriptionSet } from './subscription-set';
export declare class RedisSubscriptionSet<T> implements SubscriptionSet<T> {
    private redisClient;
    private subscriptionSetKey;
    constructor(redisClient: FrameworkRedisClient, subscriptionSetKey: string);
    add(value: T, ttl: number): Promise<undefined>;
    getAll(): Promise<T[]>;
    get(): T | undefined;
}
