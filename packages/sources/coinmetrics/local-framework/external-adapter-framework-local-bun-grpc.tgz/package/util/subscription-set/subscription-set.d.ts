import { FrameworkRedisClient } from '../redis-client';
import { PromiseOrValue } from '..';
import { AdapterSettings } from '../../config';
/**
 * Set to hold items to subscribe to from a provider (regardless of protocol)
 */
export interface SubscriptionSet<T> {
    /** Add a new subscription to the set */
    add(value: T, ttl: number, key?: string): PromiseOrValue<void>;
    /** Get all subscriptions from the set as a list */
    getAll(): PromiseOrValue<T[]>;
    get: (key: string) => T | undefined;
}
export declare class SubscriptionSetFactory {
    private cacheType;
    private redisClient?;
    private adapterName?;
    private capacity;
    private cachePrefix;
    constructor(adapterSettings: AdapterSettings, adapterName: string, redisClient?: FrameworkRedisClient);
    buildSet<T>(endpointName: string, transportName: string): SubscriptionSet<T>;
}
