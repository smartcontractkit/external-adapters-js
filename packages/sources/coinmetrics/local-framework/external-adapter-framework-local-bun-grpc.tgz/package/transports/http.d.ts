import { HttpResponse, RequestConfig } from '../util/http-client';
import { TransportDependencies, TransportGenerics } from '.';
import { EndpointContext } from '../adapter';
import { Requester } from '../util/requester';
import { ProviderResult } from '../util/types';
import { TypeFromDefinition } from '../validation/input-params';
import { SubscriptionTransport } from './abstract/subscription';
/**
 * Helper struct type that will be used to pass types to the generic parameters of a Transport.
 * Extends the common TransportGenerics, adding Provider specific types for this Batch endpoint.
 */
export type HttpTransportGenerics = TransportGenerics & {
    /**
     * Type details for any provider specific interfaces.
     */
    Provider: {
        /**
         * Structure of the body of the request that will be sent to the data provider.
         */
        RequestBody: unknown;
        /**
         * Structure for the body of the response coming from the data provider.
         */
        ResponseBody: unknown;
    };
};
/**
 * Structure containing the association between EA params and a provider request.
 */
export type ProviderRequestConfig<T extends HttpTransportGenerics> = {
    /** The input parameters for requests that will get responses from the request in this struct */
    params: TypeFromDefinition<T['Parameters']>[];
    /** The request that will be sent to the data provider to fetch values for the params in this struct */
    request: RequestConfig<T['Provider']['RequestBody']>;
    /** An endpoint name override for the requester key to allow the coalescing of requests across endpoints */
    endpointNameOverride?: string;
    /** The API credit cost of the request sent to the data provider.
     * Applies only for burst rate limit strategy and is ignored if another strategy is used. */
    cost?: number;
};
/**
 * Config object that is provided to the HttpTransport constructor.
 */
export interface HttpTransportConfig<T extends HttpTransportGenerics> {
    /**
     * This method should take the list of currently valid input parameters in the subscription set,
     * and build however many requests to the data provider are necessary to fullfill all the information.
     * Some constranints:
     *   - Each request should be tied to at least one input parameter
     *   - Input parameters should be tied to only one request. You can technically avoid this, but there will be no way
     *     to consolidate many of them since the parseResponse method is called independently for each of them.
     *
     * @param params - the list of non-expired input parameters sent to this Adapter
     * @param adapterSettings - the config for this Adapter
     * @returns one or multiple request configs
     */
    prepareRequests: (params: TypeFromDefinition<T['Parameters']>[], adapterSettings: T['Settings']) => ProviderRequestConfig<T> | ProviderRequestConfig<T>[];
    /**
     * This method should take the incoming response from the data provider, and using that and the params, build a
     * list of ProviderResults that will be stored in the response cache for this endpoint.
     * Some notes:
     *   - The results don't technically need to be related to the requested params; you could use the response
     *     and store more items in the cache than what was requested from the EA (be mindful and do this conservatively if at all)
     *   - If no useful information was received, you can return an empty list
     *   - Alternatively, do make use of the fact that a ProviderResult is not necessarily a successful one, and you can store errors too
     *
     * @param params - the list of input parameters that should be fulfilled by this incoming provider response
     * @param res - the response from the data provider
     * @param adapterSettings - the config for this Adapter
     * @returns a list of ProviderResults
     */
    parseResponse: (params: TypeFromDefinition<T['Parameters']>[], res: HttpResponse<T['Provider']['ResponseBody']>, adapterSettings: T['Settings']) => ProviderResult<T>[];
}
/**
 * Transport implementation that takes incoming batches of requests and keeps a warm cache of values.
 * Within the setup function, adapter params are added to a set that also keeps track and expires values.
 * In the background execute, the list of non-expired items in the set is fetched.
 * Then, the list is passed through the `prepareRequest` function, that returns an RequestConfig.
 * The Data Provider response is then passed through the `parseResponse` function to create a [[CacheEntry]] list.
 * Finally, the items in that [[CacheEntry]] list are set in the Cache so the Adapter can fetch values from there.
 *
 * @typeParam T - all types related to the [[Transport]]
 */
export declare class HttpTransport<T extends HttpTransportGenerics> extends SubscriptionTransport<T> {
    private config;
    WARMER_ACTIVE: boolean;
    requester: Requester;
    constructor(config: HttpTransportConfig<T>);
    initialize(dependencies: TransportDependencies<T>, adapterSettings: T['Settings'], endpointName: string, transportName: string): Promise<void>;
    getSubscriptionTtlFromConfig(adapterSettings: T['Settings']): number;
    backgroundHandler(context: EndpointContext<T>, entries: TypeFromDefinition<T['Parameters']>[]): Promise<void>;
    private handleRequest;
    private makeRequest;
}
