import { EndpointContext } from '../adapter';
import { ProviderResult } from '../util/types';
import { TypeFromDefinition } from '../validation/input-params';
import { TransportGenerics } from './';
import { StreamingTransport, SubscriptionDeltas } from './abstract/streaming';
/** Data that can be received through a WebSocket message event */
export type WebSocketRawData = string | ArrayBuffer | Buffer;
declare const NativeWebSocket: {
    new (url: string | URL, protocols?: string | string[]): globalThis.WebSocket;
    prototype: globalThis.WebSocket;
    readonly CONNECTING: 0;
    readonly OPEN: 1;
    readonly CLOSING: 2;
    readonly CLOSED: 3;
};
/**
 * WebSocket client based on the runtime's native implementation.
 *
 * It preserves the small subset of the `ws` package API surface that the
 * framework (and adapters built on it) rely on:
 *  - a `(url, protocols, options)` constructor signature
 *  - `removeAllListeners()`
 *  - the ws-style `.on()` EventEmitter API for protocol-level events.
 *
 * Note: the native client does not expose protocol-level `pong` frames, so
 * listeners registered with `.on('pong', ...)` will never be invoked. Use the
 * `heartbeat` handler (application-level ping) for liveness detection instead.
 */
export declare class WebSocket extends NativeWebSocket {
    private readonly trackedListeners;
    private readonly emitterListeners;
    constructor(url: string, protocols?: string | string[], options?: WebSocket.ClientOptions);
    addEventListener(type: string, listener: (event: any) => unknown, options?: boolean | AddEventListenerOptions): void;
    removeEventListener(type: string, listener: (event: any) => unknown, options?: boolean | EventListenerOptions): void;
    removeAllListeners(): this;
    on(event: string, listener: (...args: unknown[]) => void): this;
    emit(event: string, ...args: unknown[]): boolean;
}
export declare namespace WebSocket {
    /**
     * Options that can be passed when establishing a WebSocket connection.
     * This intentionally mirrors the subset of the former `ws` ClientOptions
     * that the runtime's native WebSocket client supports.
     */
    interface ClientOptions {
        /** Headers to send in the connection handshake (e.g. for authentication) */
        headers?: Record<string, string>;
        /** Subprotocols to request from the server */
        protocols?: string | string[];
        /** TLS configuration (custom CAs, client certificates, etc.) */
        tls?: Record<string, unknown>;
        /** HTTP proxy URL to connect through */
        proxy?: string;
    }
    type Event = globalThis.Event;
    type MessageEvent = globalThis.MessageEvent;
    type CloseEvent = globalThis.CloseEvent;
    interface ErrorEvent extends globalThis.Event {
        error: Error;
        message: string;
    }
    type Data = WebSocketRawData;
}
type WebSocketClass = new (url: string, protocols?: string | string[] | undefined, options?: WebSocket.ClientOptions) => WebSocket;
export declare class WebSocketClassProvider {
    static ctor: WebSocketClass;
    static set(ctor: WebSocketClass): void;
    static get(): WebSocketClass;
}
/**
 * Object used to pass partial websocket transport state into url config function.
 */
export interface WebSocketUrlConfigFunctionParameters {
    /** Number of times streamHandler was called without a responsive connection */
    streamHandlerInvocationsWithNoConnection: number;
}
type WebSocketIndividualBuilders<T extends WebsocketTransportGenerics> = {
    /**
     * Builds a WS message that will be sent to subscribe to a specific feed
     *
     * @param params - the body of the adapter request
     * @param context - the background context for the Adapter
     * @returns the WS message (can be any type as long as the [[WebSocket]] doesn't complain)
     */
    subscribeMessage?: (params: TypeFromDefinition<T['Parameters']>, context: EndpointContext<T>) => unknown;
    /**
     * Builds a WS message that will be sent to unsubscribe to a specific feed
     *
     * @param params - the body of the adapter request
     * @param context - the background context for the Adapter
     * @returns the WS message (can be any type as long as the [[WebSocket]] doesn't complain)
     */
    unsubscribeMessage?: (params: TypeFromDefinition<T['Parameters']>, context: EndpointContext<T>) => unknown;
};
type WebSocketCustomBuilders<T extends WebsocketTransportGenerics> = {
    /**
     * Builds WS messages to subscribe and/or unsubscribe from feeds.
     * Use this instead of per-subscription builders when an EA needs custom
     * subscription handling (e.g. batching multiple feeds into one message).
     *
     * @param context - the background context for the Adapter
     * @param subscriptions - new, stale, and desired subscription deltas for this cycle
     * @returns WS messages to send; an empty array means nothing to send
     */
    customSubscriptionMessages: (context: EndpointContext<T>, subscriptions: SubscriptionDeltas<TypeFromDefinition<T['Parameters']>>) => unknown[];
};
/**
 * Config object that is provided to the WebSocketTransport constructor.
 */
export type WebSocketTransportConfig<T extends WebsocketTransportGenerics> = {
    /** Endpoint to which to open the WS connection*/
    url: (context: EndpointContext<T>, desiredSubs: TypeFromDefinition<T['Parameters']>[], urlConfigFunctionParameters: WebSocketUrlConfigFunctionParameters) => Promise<string> | string;
    /** Optional parameters used when establishing the WebSocket connection */
    options?: (context: EndpointContext<T>, desiredSubs: TypeFromDefinition<T['Parameters']>[]) => Promise<WebSocket.ClientOptions> | WebSocket.ClientOptions;
    /** Map of handlers for different WS lifecycle events */
    handlers: {
        /**
         * Handles when the WS is successfully opened.
         * Optional since logic is not always needed on connection.
         * Note: any listeners set in this method will be cleared after its execution.
         *
         * @param wsConnection - the WebSocket with an established connection
         * @param context - the background context for the Adapter
         * @returns an empty Promise, or void
         */
        open?: (wsConnection: WebSocket, context: EndpointContext<T>) => Promise<void> | void;
        /**
         * Handles when client is ready to send a heartbeat to server
         *
         * @param wsConnection - the WebSocket with an established connection
         * @param context - the background context for the Adapter
         * @returns an empty Promise, or void
         */
        heartbeat?: (wsConnection: WebSocket, context: EndpointContext<T>) => Promise<void> | void;
        /**
         * Handles when the WS receives a pong
         *
         * @param wsConnection - the WebSocket with an established connection
         * @param data - the data received by the WS
         * @returns void
         */
        pong?: (wsConnection: WebSocket, data: Buffer) => void;
        /**
         * Handles when the websocket connection dispatches an error event
         * Optional to let the adapter handle the event in its own way if it decides to
         *
         * @param errorEvent - the WebSocket error event
         * @param context - the background context for the Adapter
         * @returns void
         */
        error?: (errorEvent: WebSocket.ErrorEvent, context: EndpointContext<T>) => void;
        /**
         * Handles when the websocket connection dispatches a close event
         * Optional to let the adapter handle the event in its own way if it decides to
         *
         * @param closeEvent - the WebSocket close event
         * @param context - the background context for the Adapter
         * @returns void
         */
        close?: (closeEvent: WebSocket.CloseEvent, context: EndpointContext<T>) => void;
        /**
         * Handles when the WS receives a message
         *
         * @param message - the message received by the WS
         * @param context - the background context for the Adapter
         * @returns a list of cache entries of adapter responses to set in the cache
         */
        message: (message: T['Provider']['WsMessage'], context: EndpointContext<T>) => ProviderResult<T>[] | undefined;
    };
    /**
     * Map of "builders", functions that will be used to prepare specific WS messages.
     * Provide either per-subscription builders (`subscribeMessage` / `unsubscribeMessage`)
     * or a custom builder (`customSubscriptionMessages`), not both.
     */
    builders?: WebSocketIndividualBuilders<T> | WebSocketCustomBuilders<T>;
};
/**
 * Helper struct type that will be used to pass types to the generic parameters of a Transport.
 * Extends the common TransportGenerics, adding Provider specific types for this WS endpoint.
 */
export type WebsocketTransportGenerics = TransportGenerics & {
    /**
     * Type details for any provider specific interfaces.
     */
    Provider: {
        /**
         * Structure of any message that will come through the websocket connection.
         */
        WsMessage: unknown;
    };
};
/**
 * Transport implementation that takes incoming requests, adds them to an [[subscriptionSet]] and,
 * through a WebSocket connection, subscribes to the relevant feeds to populate the cache.
 *
 * @typeParam T - Helper struct type that will be used to pass types to the generic parameters (check [[WebsocketTransportGenerics]])
 */
export declare class WebSocketTransport<T extends WebsocketTransportGenerics> extends StreamingTransport<T> {
    private config;
    wsConnection?: WebSocket;
    currentUrl: string;
    lastMessageReceivedAt: number;
    connectionOpenedAt: number;
    streamHandlerInvocationsWithNoConnection: number;
    heartbeatInterval?: NodeJS.Timeout;
    subscriptionMessageBuilder?: (context: EndpointContext<T>, subscriptions: SubscriptionDeltas<TypeFromDefinition<T['Parameters']>>) => unknown[];
    constructor(config: WebSocketTransportConfig<T>);
    getSubscriptionTtlFromConfig(adapterSettings: T['Settings']): number;
    connectionClosed(): boolean;
    /**
     * Increments the failover counter and updates the wsConnectionFailoverCount metric.
     * Both operations must always happen together, so they are encapsulated here.
     */
    private incrementFailoverCounter;
    serializeMessage(payload: unknown): string;
    deserializeMessage(data: WebSocket.Data): T['Provider']['WsMessage'];
    startHeartbeat(context: EndpointContext<T>): void;
    stopHeartbeat(): void;
    buildConnectionHandlers(context: EndpointContext<T>, connection: WebSocket, connectionReadyResolve: (value: WebSocket) => void): {
        open: (event: WebSocket.Event) => Promise<void>;
        message: (event: WebSocket.MessageEvent) => Promise<void>;
        error: (event: WebSocket.ErrorEvent) => Promise<void>;
        close: (event: WebSocket.CloseEvent) => void;
    };
    establishWsConnection(context: EndpointContext<T>, url: string, options?: WebSocket.ClientOptions | undefined): Promise<WebSocket>;
    sendMessages(context: EndpointContext<T>, messages: unknown[]): Promise<void>;
    streamHandler(context: EndpointContext<T>, subscriptions: SubscriptionDeltas<TypeFromDefinition<T['Parameters']>>): Promise<void>;
    private rejectionHandler;
}
/**
 * Transport that wraps the WebSocketTransport in order to provide helper methods for a reverse mapping. This is useful
 * when the Data Provider uses pair IDs that cannot be programmatically translated into request params.
 *
 * Example with `{from: "STETH", to: "USD"} -> "STETHUSD"`:
 * Instead of trying to split the Data Provider ID string based on length, we can use
 * `setReverseMapping("STETHUSD", {from: "STETH", to: "USD"})` to map the Data Provider ID to the request payload, then
 * use `getReverseMapping("STETHUSD")` to get the right input parameters.
 *
 * @typeParam T - Helper struct type that will be used to pass types to the generic parameters (check [[WebsocketTransportGenerics]])
 * @typeParam K - The type for the Data Provider's IDs
 */
export declare class WebsocketReverseMappingTransport<T extends WebsocketTransportGenerics, K> extends WebSocketTransport<T> {
    private requestMapping;
    /**
     * Sets the request params mapping for the given value
     *
     * @param value - the Data Provider lookup value to map to `params`
     * @param params - the body of the adapter request
     * @returns the WS message (can be any type as long as the [[WebSocket]] doesn't complain)
     */
    setReverseMapping(value: K, params: TypeFromDefinition<T['Parameters']>): void;
    /**
     * Gets the request params mapping for the given value
     *
     * @param value - the Data Provider lookup value
     * @returns the request parameters for the Data Provider lookup value, if one has been set
     */
    getReverseMapping(value: K): TypeFromDefinition<T['Parameters']> | undefined;
}
export {};
