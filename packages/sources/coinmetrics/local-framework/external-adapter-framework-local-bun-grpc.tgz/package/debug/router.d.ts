import { App } from '../server';
import { Adapter } from '../adapter';
/**
 * This function registers the debug endpoints for the adapter.
 * These endpoints are intended to be used for debugging purposes only, and should not be publicly accessible.
 *
 * @param app - the fastify instance that has been created
 * @param adapter - the adapter for which to create the debug endpoints
 */
export default function registerDebugEndpoints(app: App, adapter: Adapter): void;
