import { FrameworkRedisClient } from '../util/redis-client';
import { LocalCache } from './local';
import { RedisCache } from './redis';
export declare class CacheFactory {
    static buildCache({ cacheType, maxSizeForLocalCache }: {
        cacheType: string;
        maxSizeForLocalCache: number;
    }, redisClient?: FrameworkRedisClient): LocalCache<unknown> | RedisCache<unknown> | undefined;
}
