"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = registerDebugEndpoints;
const path_1 = require("path");
const settings_page_1 = __importDefault(require("./settings-page"));
const settings_1 = require("../util/settings");
/**
 * This function registers the debug endpoints for the adapter.
 * These endpoints are intended to be used for debugging purposes only, and should not be publicly accessible.
 *
 * @param app - the fastify instance that has been created
 * @param adapter - the adapter for which to create the debug endpoints
 */
function registerDebugEndpoints(app, adapter) {
    // Debug endpoint to return the current settings in raw JSON (censoring sensitive values)
    app.get((0, path_1.join)(adapter.config.settings.BASE_URL, '/debug/settings/raw'), async () => {
        const censoredSettings = (0, settings_1.buildSettingsList)(adapter);
        return JSON.stringify(censoredSettings.sort((a, b) => a.name.localeCompare(b.name)), null, 2);
    });
    // Helpful UI to visualize current settings
    app.get((0, path_1.join)(adapter.config.settings.BASE_URL, '/debug/settings'), (req, reply) => {
        const censoredSettings = (0, settings_1.buildSettingsList)(adapter);
        const censoredSettingsPage = (0, settings_page_1.default)(censoredSettings);
        reply.headers({ 'content-type': 'text/html' }).send(censoredSettingsPage);
    });
}
//# sourceMappingURL=router.js.map