import { DebugPageSetting } from '../util/settings';
declare const settingsPage: (settings: DebugPageSetting[]) => string;
export default settingsPage;
