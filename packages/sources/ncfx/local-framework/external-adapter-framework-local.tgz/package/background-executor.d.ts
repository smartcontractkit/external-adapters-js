import { Adapter } from './adapter';
/**
 * Very simple background loop that will call the [[Transport.backgroundExecute]] functions in all Transports.
 * It gets the time in ms to wait as the return value from those functions, and sleeps until next execution.
 *
 * @param adapter - an initialized External Adapter
 * @param server - the http server to attach an on close listener to
 */
export declare function callBackgroundExecutes(adapter: Adapter, apiShutdownPromise?: Promise<void>): Promise<void>;
