import { AdapterEndpoint, EndpointGenerics } from '../adapter';
import { AdapterSettings } from '../config';
export * from './burst';
export interface AdapterRateLimitTier {
    rateLimit1s?: number;
    rateLimit1m?: number;
    rateLimit1h?: number;
    note?: string;
}
/**
 * Common interface for all RateLimiter classes to implement
 */
export interface RateLimiter {
    /**
     * Method to ensure all RateLimiters can be initialized in the same manner.
     *
     * @param limits - settings for how much throughput to allow for the Adapter
     * @param endpoints - list of adapter endpoints
     */
    initialize<T extends EndpointGenerics>(endpoints: AdapterEndpoint<T>[], limits?: AdapterRateLimitTier): this;
    /**
     * This method will block (if necessary) until the rate limiter can make sure the
     * next outbound request will be within the specified limits.
     *
     * @param cost - credit cost of an API request sent to Data Provider. Used for burst rate limiter
     */
    waitForRateLimit(cost?: number): Promise<void>;
    /**
     * Returns the time in milliseconds until the next request would be able to be fired
     */
    msUntilNextExecution(): number;
}
/**
 * This method will convert all possible settings for a rate limit tier and
 * convert them all to requests per second
 *
 * @param limits - the rate limit tier set for the adapter
 * @returns all rate limits values in seconds
 */
export declare const consolidateTierLimits: (limits?: AdapterRateLimitTier) => number[];
/**
 * This method will convert all possible settings for a rate limit tier and
 * convert them all to requests per second, returning the highest one
 *
 * @param limits - the rate limit tier set for the adapter
 * @returns the most permissive of the set options, in requests per second
 */
export declare const highestTierLimit: (limits?: AdapterRateLimitTier) => number;
/**
 * This method will convert all possible settings for a rate limit tier and
 * convert them all to requests per second, returning the lowest one
 *
 * @param limits - the rate limit tier set for the adapter
 * @returns the most restrictive of the set options, in requests per second
 */
export declare const lowestTierLimit: (limits?: AdapterRateLimitTier) => number;
/**
 * Validates rate limiting tiers specified for the adapter, and returns the one to use.
 *
 * @param adapterSettings - the adapter config containing the env vars
 * @param tiers - the adapter config listing the different available API tiers
 * @returns the specified API tier, or a default one if none are specified
 */
export declare const getRateLimitingTier: (adapterSettings: AdapterSettings, tiers?: Record<string, AdapterRateLimitTier>, requireTierSelection?: boolean) => AdapterRateLimitTier | undefined;
export declare const buildRateLimitTiersFromConfig: (adapterSettings: AdapterSettings) => AdapterRateLimitTier | undefined;
export declare const highestRateLimitTiers: (tiers?: Record<string, AdapterRateLimitTier>) => number;
