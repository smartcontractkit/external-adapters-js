import { AdapterRateLimitTier, RateLimiter } from '.';
import { AdapterEndpoint, EndpointGenerics } from '../adapter';
/**
 * The simplest version of a rate limit. This will not take any bursts into accoung,
 * and always rely on a fixed request per second rate. The only "complex" mechanism it has
 * is checking when the last request was made to this rate limiter, to account for a period
 * of time with no requests and avoiding the wait of the initial request.
 */
export declare class FixedIntervalRateLimiter implements RateLimiter {
    period: number;
    lastRequestAt: number | null;
    initialize<T extends EndpointGenerics>(endpoints: AdapterEndpoint<T>[], limits?: AdapterRateLimitTier): this;
    msUntilNextExecution(): number;
    waitForRateLimit(): Promise<void>;
}
