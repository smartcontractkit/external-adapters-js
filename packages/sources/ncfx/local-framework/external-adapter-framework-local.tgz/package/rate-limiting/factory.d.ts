import { RateLimiter } from '.';
export declare enum RateLimitingStrategy {
    BURST = "burst",
    FIXED_INTERVAL = "fixed-interval"
}
export declare class RateLimiterFactory {
    static buildRateLimiter(strategy: RateLimitingStrategy): RateLimiter;
}
