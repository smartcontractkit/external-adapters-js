import { AdapterRateLimitTier, RateLimiter } from '.';
import { AdapterEndpoint, EndpointGenerics } from '../adapter';
/**
 * This rate limiter is the simplest stateful option.
 * It will keep track of used API credits (by default, one request equals one credit) and
 * upon reaching the limits in a fixed time window, will block the requests until API credits are available again.
 * On startup, it'll compare the different thresholds for each tier, calculate them all
 * in the finest window we'll use (seconds), and use the most restrictive one.
 * This is so if the EA were to restart, we don't need to worry about persisting state
 * for things like daily quotas. The downside is that this does not work well for bursty
 * loads or spikes, in cases where e.g. the per second limit is high but daily quotas low.
 */
export declare class BurstRateLimiter implements RateLimiter {
    latestSecondInterval: number;
    creditsThisSecond: number;
    latestMinuteInterval: number;
    creditsThisMinute: number;
    perSecondLimit: number;
    perMinuteLimit: number;
    initialize<T extends EndpointGenerics>(endpoints: AdapterEndpoint<T>[], limits?: AdapterRateLimitTier): this;
    private updateIntervals;
    msUntilNextExecution(): number;
    waitForRateLimit(creditCost?: number): Promise<void>;
}
