"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RateLimiterFactory = exports.RateLimitingStrategy = void 0;
const _1 = require(".");
const fixed_interval_1 = require("./fixed-interval");
var RateLimitingStrategy;
(function (RateLimitingStrategy) {
    RateLimitingStrategy["BURST"] = "burst";
    RateLimitingStrategy["FIXED_INTERVAL"] = "fixed-interval";
})(RateLimitingStrategy || (exports.RateLimitingStrategy = RateLimitingStrategy = {}));
class RateLimiterFactory {
    static buildRateLimiter(strategy) {
        switch (strategy) {
            case RateLimitingStrategy.BURST:
                return new _1.BurstRateLimiter();
            case RateLimitingStrategy.FIXED_INTERVAL:
                return new fixed_interval_1.FixedIntervalRateLimiter();
        }
    }
}
exports.RateLimiterFactory = RateLimiterFactory;
//# sourceMappingURL=factory.js.map