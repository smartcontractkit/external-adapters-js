import { FastifyInstance } from 'fastify';
import { Adapter } from '../adapter';
export interface StatusResponse {
    adapter: {
        name: string;
        version: string;
        uptimeSeconds: number;
    };
    endpoints: {
        name: string;
        aliases: string[];
        transports: string[];
    }[];
    defaultEndpoint: string;
    configuration: {
        name: string;
        value: unknown;
        type: string;
        description: string;
        required: boolean;
        default: unknown;
        customSetting: boolean;
        envDefaultOverride: unknown;
    }[];
    runtime: {
        nodeVersion: string;
        platform: string;
        architecture: string;
        hostname: string;
    };
    metrics: {
        enabled: boolean;
        port?: number;
        endpoint?: string;
    };
}
/**
 * This function registers the status endpoint for the adapter.
 * This endpoint provides comprehensive information about the adapter including:
 * - Adapter metadata (name, version, commit)
 * - Configuration (obfuscated sensitive values)
 * - Runtime information
 * - Dependencies status
 * - Endpoints and transports
 *
 * @param app - the fastify instance that has been created
 * @param adapter - the adapter for which to create the status endpoint
 */
export default function registerStatusEndpoint(app: FastifyInstance, adapter: Adapter): void;
