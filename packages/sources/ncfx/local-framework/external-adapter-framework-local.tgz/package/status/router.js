"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = registerStatusEndpoint;
const path_1 = require("path");
const os_1 = require("os");
const settings_1 = require("../util/settings");
/**
 * This function registers the status endpoint for the adapter.
 * This endpoint provides comprehensive information about the adapter including:
 * - Adapter metadata (name, version, commit)
 * - Configuration (obfuscated sensitive values)
 * - Runtime information
 * - Dependencies status
 * - Endpoints and transports
 *
 * @param app - the fastify instance that has been created
 * @param adapter - the adapter for which to create the status endpoint
 */
function registerStatusEndpoint(app, adapter) {
    // Status endpoint that returns comprehensive adapter information
    app.get((0, path_1.join)(adapter.config.settings.BASE_URL, '/status'), async () => {
        const metricsEndpoint = adapter.config.settings.METRICS_USE_BASE_URL
            ? (0, path_1.join)(adapter.config.settings.BASE_URL, 'metrics')
            : '/metrics';
        const statusResponse = {
            adapter: {
                name: adapter.name,
                version: process.env['npm_package_version'] || 'unknown',
                uptimeSeconds: process.uptime(),
            },
            endpoints: adapter.endpoints.map((endpoint) => ({
                name: endpoint.name,
                aliases: endpoint.aliases || [],
                transports: endpoint.transportRoutes.routeNames(),
            })),
            defaultEndpoint: adapter.defaultEndpoint || '',
            configuration: (0, settings_1.buildSettingsList)(adapter),
            runtime: {
                nodeVersion: process.version,
                platform: process.platform,
                architecture: process.arch,
                hostname: (0, os_1.hostname)(),
            },
            metrics: {
                enabled: adapter.config.settings.METRICS_ENABLED,
                port: adapter.config.settings.METRICS_ENABLED
                    ? adapter.config.settings.METRICS_PORT
                    : undefined,
                endpoint: adapter.config.settings.METRICS_ENABLED ? metricsEndpoint : undefined,
            },
        };
        return statusResponse;
    });
}
//# sourceMappingURL=router.js.map