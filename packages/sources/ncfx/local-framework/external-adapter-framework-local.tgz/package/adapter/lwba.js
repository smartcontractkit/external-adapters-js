"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LwbaEndpoint = exports.validateLwbaResponse = exports.DEFAULT_LWBA_ALIASES = exports.lwbaEndpointInputParametersDefinition = void 0;
const error_1 = require("../validation/error");
const endpoint_1 = require("./endpoint");
/**
 * Base input parameter config that any [[LwbaEndpoint]] must extend
 */
exports.lwbaEndpointInputParametersDefinition = {
    base: {
        aliases: ['from', 'coin'],
        type: 'string',
        description: 'The symbol of symbols of the currency to query',
        required: true,
    },
    quote: {
        aliases: ['to', 'market'],
        type: 'string',
        description: 'The symbol of the currency to convert to',
        required: true,
    },
};
exports.DEFAULT_LWBA_ALIASES = ['crypto-lwba', 'crypto_lwba', 'cryptolwba'];
const validateLwbaResponse = (bid, mid, ask) => {
    if (!mid || !bid || !ask) {
        return `Invariant violation. LWBA response must contain mid, bid and ask prices. Got: (bid: ${bid}, mid: ${mid}, ask: ${ask})`;
    }
    if (mid < bid || mid > ask) {
        return `Invariant violation. Mid price must be between bid and ask prices. Got: (bid: ${bid}, mid: ${mid}, ask: ${ask})`;
    }
    return '';
};
exports.validateLwbaResponse = validateLwbaResponse;
/**
 * An LwbaEndpoint is a specific type of AdapterEndpoint. Meant to comply with standard practices for
 * LWBA (lightweight bid/ask) Data Feeds, its InputParameters must extend the basic ones (base/quote).
 */
class LwbaEndpoint extends endpoint_1.AdapterEndpoint {
    constructor(params) {
        if (!params.aliases) {
            params.aliases = [];
        }
        for (const alias of exports.DEFAULT_LWBA_ALIASES) {
            if (params.name !== alias && !params.aliases.includes(alias)) {
                params.aliases.push(alias);
            }
        }
        // All LWBA requests must have a mid, bid, and ask
        // Response validation ensures that we meet the invariant: bid <= mid <= ask
        params.customOutputValidation = (output) => {
            const data = output.data;
            const error = (0, exports.validateLwbaResponse)(data.bid, data.mid, data.ask);
            if (error) {
                throw new error_1.AdapterLWBAError({ statusCode: 500, message: error });
            }
            return undefined;
        };
        super(params);
    }
}
exports.LwbaEndpoint = LwbaEndpoint;
//# sourceMappingURL=lwba.js.map