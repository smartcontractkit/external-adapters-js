"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PoRAdapter = exports.PoRProviderEndpoint = exports.PoRTotalBalanceEndpoint = exports.PoRBalanceEndpoint = exports.porBalanceEndpointInputParametersDefinition = exports.PoRTokenAddressEndpoint = exports.PoRAddressEndpoint = void 0;
const endpoint_1 = require("./endpoint");
const config_1 = require("../config");
const basic_1 = require("./basic");
const metrics_1 = require("../metrics");
/**
 * A PoRAddressEndpoint is a specific type of AdapterEndpoint. Meant to comply with standard practices for
 * Data Feeds, its response type must be `PoRAddressResponse`
 */
class PoRAddressEndpoint extends endpoint_1.AdapterEndpoint {
}
exports.PoRAddressEndpoint = PoRAddressEndpoint;
class PoRTokenAddressEndpoint extends endpoint_1.AdapterEndpoint {
}
exports.PoRTokenAddressEndpoint = PoRTokenAddressEndpoint;
/**
 * Base input parameter config that any [[PoRBalanceEndpoint]] must extend
 */
exports.porBalanceEndpointInputParametersDefinition = {
    addresses: {
        aliases: ['result'],
        array: true,
        type: {
            address: {
                type: 'string',
                description: 'an address to get the balance of',
                required: true,
            },
        },
        description: 'An array of addresses to get the balances of (as an object with string `address` as an attribute)',
        required: true,
    },
};
/**
 * A PoRBalanceEndpoint is a specific type of AdapterEndpoint. Meant to comply with standard practices for
 * Data Feeds, its InputParameters must extend the basic ones (addresses) and the response type must be `PoRBalanceResponse`.
 */
class PoRBalanceEndpoint extends endpoint_1.AdapterEndpoint {
}
exports.PoRBalanceEndpoint = PoRBalanceEndpoint;
/**
 * A PoRTotalBalanceEndpoint is a specific type of AdapterEndpoint. Meant to comply with standard practices for
 * Data Feeds, its InputParameters must extend the basic ones (addresses) and the response type must be numeric string.
 */
class PoRTotalBalanceEndpoint extends endpoint_1.AdapterEndpoint {
}
exports.PoRTotalBalanceEndpoint = PoRTotalBalanceEndpoint;
/**
 * A PoRProviderEndpoint is a specific type of AdapterEndpoint. Meant to comply with standard practices for
 * Data Feeds, the response type must be `PoRProviderResponse`.
 */
class PoRProviderEndpoint extends endpoint_1.AdapterEndpoint {
}
exports.PoRProviderEndpoint = PoRProviderEndpoint;
/**
 * A PoRAdapter is a specific kind of Adapter that includes at least one PoRTotalBalanceEndpoint,
 * PoRBalanceEndpoint, PoRAddressEndpoint, PoRTokenAddressEndpoint or PoRProviderEndpoint.
 */
class PoRAdapter extends basic_1.Adapter {
    constructor(params) {
        // PoR requests take longer to process than normal feeds, that's why by default we set
        // BACKGROUND_EXECUTE_TIMEOUT to the highest value
        if (!params.config) {
            params.config = new config_1.AdapterConfig({}, {
                envDefaultOverrides: {
                    BACKGROUND_EXECUTE_TIMEOUT: 180_000,
                    API_TIMEOUT: 60_000,
                    CACHE_MAX_AGE: 360_000,
                },
            });
        }
        else {
            params.config.options = {
                ...(params.config.options || {}),
                envDefaultOverrides: {
                    ...(params.config.options?.envDefaultOverrides || {}),
                    BACKGROUND_EXECUTE_TIMEOUT: params.config.options?.envDefaultOverrides?.BACKGROUND_EXECUTE_TIMEOUT ?? 180_000,
                    API_TIMEOUT: params.config.options?.envDefaultOverrides?.API_TIMEOUT ?? 60_000,
                    CACHE_MAX_AGE: params.config.options?.envDefaultOverrides?.CACHE_MAX_AGE ?? 360_000,
                },
            };
        }
        const porEndpoints = params.endpoints.filter((e) => e instanceof PoRBalanceEndpoint ||
            e instanceof PoRTotalBalanceEndpoint ||
            e instanceof PoRAddressEndpoint ||
            e instanceof PoRTokenAddressEndpoint ||
            e instanceof PoRProviderEndpoint);
        if (!porEndpoints.length) {
            throw new Error(`This PoRAdapter's list of endpoints does not contain a valid PoR endpoint`);
        }
        super(params);
    }
    async handleRequest(req, replySent) {
        const endpoint = this.endpoints.find((e) => e.name === req.requestContext.endpointName);
        if (endpoint instanceof PoRBalanceEndpoint || endpoint instanceof PoRTotalBalanceEndpoint) {
            const data = req.requestContext.data;
            if (data && data.addresses && Array.isArray(data.addresses)) {
                const feedId = req.requestContext?.meta?.metrics?.feedId || 'N/A';
                metrics_1.metrics
                    .get('porBalanceAddressLength')
                    .labels({ feed_id: feedId })
                    .set(data.addresses.length);
            }
        }
        return super.handleRequest(req, replySent);
    }
}
exports.PoRAdapter = PoRAdapter;
//# sourceMappingURL=por.js.map