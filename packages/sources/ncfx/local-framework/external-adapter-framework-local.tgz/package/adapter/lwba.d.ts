import { TransportGenerics } from '../transports';
import { AdapterEndpoint } from './endpoint';
import { AdapterEndpointParams, PriceEndpointInputParametersDefinition } from './index';
/**
 * Type for the base input parameter config that any [[LwbaEndpoint]] must extend
 */
export type LwbaEndpointInputParametersDefinition = PriceEndpointInputParametersDefinition;
/**
 * Base input parameter config that any [[LwbaEndpoint]] must extend
 */
export declare const lwbaEndpointInputParametersDefinition: {
    readonly base: {
        readonly aliases: readonly ["from", "coin"];
        readonly type: "string";
        readonly description: "The symbol of symbols of the currency to query";
        readonly required: true;
    };
    readonly quote: {
        readonly aliases: readonly ["to", "market"];
        readonly type: "string";
        readonly description: "The symbol of the currency to convert to";
        readonly required: true;
    };
};
export type LwbaResponseDataFields = {
    Result: null;
    Data: {
        mid: number;
        bid: number;
        ask: number;
    };
};
/**
 * Helper type structure that contains the different types passed to the generic parameters of a PriceEndpoint
 */
export type LwbaEndpointGenerics = TransportGenerics & {
    Parameters: LwbaEndpointInputParametersDefinition;
    Response: LwbaResponseDataFields;
};
export declare const DEFAULT_LWBA_ALIASES: string[];
export declare const validateLwbaResponse: (bid?: number, mid?: number, ask?: number) => string;
/**
 * An LwbaEndpoint is a specific type of AdapterEndpoint. Meant to comply with standard practices for
 * LWBA (lightweight bid/ask) Data Feeds, its InputParameters must extend the basic ones (base/quote).
 */
export declare class LwbaEndpoint<T extends LwbaEndpointGenerics> extends AdapterEndpoint<T> {
    constructor(params: AdapterEndpointParams<T>);
}
