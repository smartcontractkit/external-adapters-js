import { TransportGenerics } from '../transports';
import { AdapterEndpoint } from './endpoint';
import { AdapterEndpointParams } from './types';
/**
 * Base input parameter config that any [[MarketStatusEndpoint]] must extend
 */
export declare const marketStatusEndpointInputParametersDefinition: {
    readonly market: {
        readonly aliases: readonly [];
        readonly type: "string";
        readonly description: "The name of the market";
        readonly required: true;
    };
    readonly type: {
        readonly type: "string";
        readonly description: "Type of the market status";
        readonly options: readonly ["regular", "24/5"];
        readonly default: "regular";
    };
    readonly weekend: {
        readonly type: "string";
        readonly description: "DHH-DHH:TZ, 520-020:America/New_York means Fri 20:00 to Sun 20:00 Eastern Time Zone";
    };
    readonly force245MarketStatus: {
        readonly type: "boolean";
        readonly description: "Return response in 24/5 market status";
        readonly default: false;
    };
};
export declare enum MarketStatus {
    UNKNOWN = 0,
    CLOSED = 1,
    OPEN = 2
}
export declare enum TwentyfourFiveMarketStatus {
    UNKNOWN = 0,
    PRE_MARKET = 1,
    REGULAR = 2,
    POST_MARKET = 3,
    OVERNIGHT = 4,
    WEEKEND = 5
}
type AggregatedMarketStatus = MarketStatus | TwentyfourFiveMarketStatus;
export type MarketStatusResultResponse = {
    Result: AggregatedMarketStatus;
    Data: {
        result: AggregatedMarketStatus;
        statusString: string;
    };
};
/**
 * Helper type structure that contains the different types passed to the generic parameters of a PriceEndpoint
 */
export type MarketStatusEndpointGenerics = TransportGenerics & {
    Parameters: typeof marketStatusEndpointInputParametersDefinition;
    Response: MarketStatusResultResponse;
};
/**
 * A MarketStatusEndpoint is a specific type of AdapterEndpoint. Meant to comply with standard practices for
 * Data Feeds, its InputParameters must extend the basic ones (base).
 */
export declare class MarketStatusEndpoint<T extends MarketStatusEndpointGenerics> extends AdapterEndpoint<T> {
    constructor(params: AdapterEndpointParams<T>);
}
export {};
