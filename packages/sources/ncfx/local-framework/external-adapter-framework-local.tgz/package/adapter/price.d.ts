import { SettingsDefinitionMap } from '../config';
import { TransportGenerics } from '../transports';
import { AdapterRequest, AdapterResponse, SingleNumberResultResponse } from '../util';
import { EmptyInputParameters, InputParametersDefinition } from '../validation/input-params';
import { AdapterEndpoint } from './endpoint';
import { Adapter, AdapterEndpointParams, AdapterParams } from './index';
/**
 * Type for the base input parameter config that any [[PriceEndpoint]] must extend
 */
export type PriceEndpointInputParametersDefinition = InputParametersDefinition & {
    base: {
        aliases: readonly ['from', 'coin', ...string[]];
        type: 'string';
        description: 'The symbol of symbols of the currency to query';
        required?: boolean;
    };
    quote: {
        aliases: readonly ['to', 'market', ...string[]];
        type: 'string';
        description: 'The symbol of the currency to convert to';
        required?: boolean;
    };
};
/**
 * Base input parameter config that any [[PriceEndpoint]] must extend
 */
export declare const priceEndpointInputParametersDefinition: {
    readonly base: {
        readonly aliases: readonly ["from", "coin"];
        readonly type: "string";
        readonly description: "The symbol of symbols of the currency to query";
        readonly required: true;
    };
    readonly quote: {
        readonly aliases: readonly ["to", "market"];
        readonly type: "string";
        readonly description: "The symbol of the currency to convert to";
        readonly required: true;
    };
};
/**
 * Structure of an "includes" file.
 * Include pairs describe an incoming price feed request, and the details specify
 */
export type IncludesFile = IncludePair[];
type IncludeDetails = {
    from: string;
    to: string;
    inverse: boolean;
    endpoints?: string[];
};
type IncludePair = {
    from: string;
    to: string;
    includes: IncludeDetails[];
};
type IncludesMap = Record<string, Record<string, IncludeDetails>>;
/**
 * Helper type structure that contains the different types passed to the generic parameters of a PriceEndpoint
 */
export type PriceEndpointGenerics = TransportGenerics & {
    Parameters: PriceEndpointInputParametersDefinition;
    Response: SingleNumberResultResponse;
};
/**
 * A PriceEndpoint is a specific type of AdapterEndpoint. Meant to comply with standard practices for
 * Data Feeds, its InputParameters must extend the basic ones (base/quote).
 */
export declare class PriceEndpoint<T extends PriceEndpointGenerics> extends AdapterEndpoint<T> {
}
/**
 * A PriceAdapter is a specific kind of Adapter that includes at least one PriceEnpoint.
 */
export declare class PriceAdapter<CustomSettingsDefinition extends SettingsDefinitionMap> extends Adapter<CustomSettingsDefinition> {
    includesMap?: IncludesMap;
    constructor(params: AdapterParams<CustomSettingsDefinition> & {
        includes?: IncludesFile;
    });
    finalizeResponse(req: AdapterRequest<EmptyInputParameters>, response: Readonly<AdapterResponse>): Readonly<AdapterResponse>;
}
/**
 * A CryptoPriceEndpoint expands on the existing [[PriceEndpoint]], with the addition of adding
 * a set of common aliases that are used across EAs to specify endpoints that provide crypto prices.
 */
export declare class CryptoPriceEndpoint<T extends PriceEndpointGenerics> extends PriceEndpoint<T> {
    constructor(params: AdapterEndpointParams<T>);
}
/**
 * A ForexPriceEndpoint expands on the existing [[PriceEndpoint]] and provides more descriptive name for
 *  endpoints that provide forex prices.
 */
export declare class ForexPriceEndpoint<T extends PriceEndpointGenerics> extends PriceEndpoint<T> {
}
export {};
