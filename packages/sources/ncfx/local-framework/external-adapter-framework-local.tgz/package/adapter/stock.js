"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StockEndpoint = exports.stockEndpointInputParametersDefinition = void 0;
const endpoint_1 = require("./endpoint");
/**
 * Base input parameter config that any [[StockEndpoint]] must extend
 */
exports.stockEndpointInputParametersDefinition = {
    base: {
        aliases: ['from', 'symbol', 'asset', 'coin', 'ticker'],
        type: 'string',
        description: 'The stock ticker to query',
        required: true,
    },
};
/**
 * A StockEndpoint is a specific type of AdapterEndpoint. Meant to comply with standard practices for
 * Data Feeds, its InputParameters must extend the basic ones (base).
 */
class StockEndpoint extends endpoint_1.AdapterEndpoint {
}
exports.StockEndpoint = StockEndpoint;
//# sourceMappingURL=stock.js.map