import { TransportRoutes } from '../transports';
import { AdapterRequest, Overrides } from '../util';
import { InputParameters } from '../validation';
import { TypeFromDefinition } from '../validation/input-params';
import { AdapterDependencies, AdapterEndpointInterface, AdapterEndpointParams, CustomInputValidator, CustomOutputValidator, EndpointGenerics, EndpointRateLimitingConfig, RequestTransform } from './types';
export declare const DEFAULT_TRANSPORT_NAME = "default_single_transport";
/**
 * Main class to represent an endpoint within an External Adapter
 */
export declare class AdapterEndpoint<T extends EndpointGenerics> implements AdapterEndpointInterface<T> {
    name: string;
    adapterName: string;
    aliases?: string[] | undefined;
    transportRoutes: TransportRoutes<T>;
    inputParameters: InputParameters<T['Parameters']>;
    rateLimiting?: EndpointRateLimitingConfig | undefined;
    cacheKeyGenerator?: (data: TypeFromDefinition<T['Parameters']>) => string;
    customInputValidation?: CustomInputValidator<T>;
    customOutputValidation?: CustomOutputValidator | undefined;
    requestTransforms: RequestTransform<T>[];
    overrides?: Record<string, string> | undefined;
    customRouter?: (req: AdapterRequest<TypeFromDefinition<T['Parameters']>>, settings: T['Settings']) => string;
    defaultTransport?: string;
    enableCompositeTransport?: boolean;
    constructor(params: AdapterEndpointParams<T>);
    /**
     * Performs all necessary initialization processes that are async or need async initialized dependencies
     *
     * @param dependencies - all dependencies initialized at the adapter level
     * @param adapterSettings - configuration for the adapter
     */
    initialize(adapterName: string, dependencies: AdapterDependencies, adapterSettings: T['Settings']): Promise<void>;
    /**
     * Takes the incoming request and applies all request transforms in the adapter
     *
     * @param req - the current adapter request
     * @returns the request after passing through all request transforms
     */
    runRequestTransforms(req: AdapterRequest<TypeFromDefinition<T['Parameters']>>, settings: T['Settings']): void;
    getRequestOverrides(data: Record<string, string>, overrides?: Overrides): {
        [symbol: string]: string;
        transport: string;
    } | undefined;
    /**
     * Default request transform that takes requests and manipulates base params
     *
     * @param adapter - the current adapter
     * @param req - the current adapter request
     * @returns the modified (or new) request
     */
    symbolOverrider(req: AdapterRequest<TypeFromDefinition<T['Parameters']>>): AdapterRequest<TypeFromDefinition<T["Parameters"]>>;
    getTransportNameForRequest(req: AdapterRequest<TypeFromDefinition<T['Parameters']>>, settings: T['Settings']): string;
    /**
     * Default routing strategy. Will try and use the transport override if present
     * or transport input parameter in the request body.
     *
     * @param req - The current adapter request
     * @returns the transport param or override if present
     */
    private defaultRouter;
}
