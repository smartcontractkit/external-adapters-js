import { TransportGenerics } from '../transports';
import { AdapterEndpoint } from './endpoint';
import { SettingsDefinitionMap } from '../config';
import { Adapter } from './basic';
import { AdapterParams } from './types';
import { EmptyInputParameters, InputParametersDefinition } from '../validation/input-params';
import { AdapterRequest, AdapterResponse } from '../util';
export type PoRProviderResponse = {
    Result: number;
    Data: {
        result: number;
        ripcord: boolean;
    };
};
export type PoRAddress = Record<string, unknown> & {
    network: string;
    chainId: string;
    address: string;
};
export type PoRTokenAddress = Record<string, unknown> & {
    network?: string;
    chainId?: string;
    contractAddress: string;
    wallets: string[];
    balanceOfSignature?: string;
    decimalsSignature?: string;
};
export type PoRAddressResponse = {
    Result: null;
    Data: {
        result: PoRAddress[];
    };
};
export type PoRTokenAddressResponse = {
    Result: null;
    Data: {
        result: PoRTokenAddress[];
    };
};
/**
 * Helper type structure that contains the Response type passed to the generic parameters of an AddressEndpoint
 */
export type PoRAddressEndpointGenerics = TransportGenerics & {
    Response: PoRAddressResponse;
};
export type PoRTokenAddressEndpointGenerics = TransportGenerics & {
    Response: PoRTokenAddressResponse;
};
/**
 * A PoRAddressEndpoint is a specific type of AdapterEndpoint. Meant to comply with standard practices for
 * Data Feeds, its response type must be `PoRAddressResponse`
 */
export declare class PoRAddressEndpoint<T extends PoRAddressEndpointGenerics> extends AdapterEndpoint<T> {
}
export declare class PoRTokenAddressEndpoint<T extends PoRTokenAddressEndpointGenerics> extends AdapterEndpoint<T> {
}
export type PoRBalance = Record<string, unknown> & {
    balance: string;
};
export type PoRBalanceResponse = {
    Result: null;
    Data: {
        result: PoRBalance[];
    };
};
/**
 * Type for the base input parameter config that any [[PoRBalanceEndpoint]] must extend
 */
export type PoRBalanceEndpointInputParametersDefinition = InputParametersDefinition & {
    addresses: {
        aliases: readonly ['result', ...string[]];
        required: boolean;
        array: boolean;
        description: 'An array of addresses to get the balances of (as an object with string `address` as an attribute)';
        type: {
            address: {
                type: 'string';
                description: 'an address to get the balance of';
                required: true;
            };
        };
    };
};
/**
 * Base input parameter config that any [[PoRBalanceEndpoint]] must extend
 */
export declare const porBalanceEndpointInputParametersDefinition: {
    readonly addresses: {
        readonly aliases: readonly ["result"];
        readonly array: true;
        readonly type: {
            readonly address: {
                readonly type: "string";
                readonly description: "an address to get the balance of";
                readonly required: true;
            };
        };
        readonly description: "An array of addresses to get the balances of (as an object with string `address` as an attribute)";
        readonly required: true;
    };
};
/**
 * Helper type structure that contains the different types passed to the generic parameters of a BalanceEndpoint
 */
export type PoRBalanceEndpointGenerics = TransportGenerics & {
    Parameters: PoRBalanceEndpointInputParametersDefinition;
    Response: PoRBalanceResponse;
};
/**
 * A PoRBalanceEndpoint is a specific type of AdapterEndpoint. Meant to comply with standard practices for
 * Data Feeds, its InputParameters must extend the basic ones (addresses) and the response type must be `PoRBalanceResponse`.
 */
export declare class PoRBalanceEndpoint<T extends PoRBalanceEndpointGenerics> extends AdapterEndpoint<T> {
}
/**
 * Helper type structure that contains the different types passed to the generic parameters of TotalBalanceEndpoint
 */
export type PoRTotalBalanceEndpointGenerics = TransportGenerics & {
    Parameters: PoRBalanceEndpointInputParametersDefinition;
    Response: {
        Result: string;
        Data: {
            result: string;
        };
    };
};
/**
 * A PoRTotalBalanceEndpoint is a specific type of AdapterEndpoint. Meant to comply with standard practices for
 * Data Feeds, its InputParameters must extend the basic ones (addresses) and the response type must be numeric string.
 */
export declare class PoRTotalBalanceEndpoint<T extends PoRTotalBalanceEndpointGenerics> extends AdapterEndpoint<T> {
}
export type PoRProviderEndpointGenerics = TransportGenerics & {
    Response: PoRProviderResponse;
};
/**
 * A PoRProviderEndpoint is a specific type of AdapterEndpoint. Meant to comply with standard practices for
 * Data Feeds, the response type must be `PoRProviderResponse`.
 */
export declare class PoRProviderEndpoint<T extends PoRProviderEndpointGenerics> extends AdapterEndpoint<T> {
}
/**
 * A PoRAdapter is a specific kind of Adapter that includes at least one PoRTotalBalanceEndpoint,
 * PoRBalanceEndpoint, PoRAddressEndpoint, PoRTokenAddressEndpoint or PoRProviderEndpoint.
 */
export declare class PoRAdapter<T extends SettingsDefinitionMap> extends Adapter<T> {
    constructor(params: AdapterParams<T>);
    handleRequest(req: AdapterRequest<EmptyInputParameters>, replySent: Promise<unknown>): Promise<Readonly<AdapterResponse>>;
}
