"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MarketStatusEndpoint = exports.TwentyfourFiveMarketStatus = exports.MarketStatus = exports.marketStatusEndpointInputParametersDefinition = void 0;
const endpoint_1 = require("./endpoint");
const market_status_1 = require("../validation/market-status");
const error_1 = require("../validation/error");
/**
 * Base input parameter config that any [[MarketStatusEndpoint]] must extend
 */
exports.marketStatusEndpointInputParametersDefinition = {
    market: {
        aliases: [],
        type: 'string',
        description: 'The name of the market',
        required: true,
    },
    type: {
        type: 'string',
        description: 'Type of the market status',
        options: ['regular', '24/5'],
        default: 'regular',
    },
    weekend: {
        type: 'string',
        description: 'DHH-DHH:TZ, 520-020:America/New_York means Fri 20:00 to Sun 20:00 Eastern Time Zone',
    },
    force245MarketStatus: {
        type: 'boolean',
        description: 'Return response in 24/5 market status',
        default: false,
    },
};
var MarketStatus;
(function (MarketStatus) {
    MarketStatus[MarketStatus["UNKNOWN"] = 0] = "UNKNOWN";
    MarketStatus[MarketStatus["CLOSED"] = 1] = "CLOSED";
    MarketStatus[MarketStatus["OPEN"] = 2] = "OPEN";
})(MarketStatus || (exports.MarketStatus = MarketStatus = {}));
var TwentyfourFiveMarketStatus;
(function (TwentyfourFiveMarketStatus) {
    TwentyfourFiveMarketStatus[TwentyfourFiveMarketStatus["UNKNOWN"] = 0] = "UNKNOWN";
    TwentyfourFiveMarketStatus[TwentyfourFiveMarketStatus["PRE_MARKET"] = 1] = "PRE_MARKET";
    TwentyfourFiveMarketStatus[TwentyfourFiveMarketStatus["REGULAR"] = 2] = "REGULAR";
    TwentyfourFiveMarketStatus[TwentyfourFiveMarketStatus["POST_MARKET"] = 3] = "POST_MARKET";
    TwentyfourFiveMarketStatus[TwentyfourFiveMarketStatus["OVERNIGHT"] = 4] = "OVERNIGHT";
    TwentyfourFiveMarketStatus[TwentyfourFiveMarketStatus["WEEKEND"] = 5] = "WEEKEND";
})(TwentyfourFiveMarketStatus || (exports.TwentyfourFiveMarketStatus = TwentyfourFiveMarketStatus = {}));
/**
 * A MarketStatusEndpoint is a specific type of AdapterEndpoint. Meant to comply with standard practices for
 * Data Feeds, its InputParameters must extend the basic ones (base).
 */
class MarketStatusEndpoint extends endpoint_1.AdapterEndpoint {
    constructor(params) {
        params.customInputValidation = (req, _adapterSettings) => {
            const data = req.requestContext.data;
            if (data['type'] === '24/5') {
                (0, market_status_1.parseWeekendString)(data['weekend']);
            }
            if (data['type'] === 'regular' && data['weekend']) {
                throw new error_1.AdapterInputError({
                    statusCode: 400,
                    message: '[Param: weekend] must be empty when [Param: type] is regular',
                });
            }
            return undefined;
        };
        super(params);
    }
}
exports.MarketStatusEndpoint = MarketStatusEndpoint;
//# sourceMappingURL=market-status.js.map