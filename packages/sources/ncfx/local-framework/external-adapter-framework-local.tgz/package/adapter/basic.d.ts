import EventEmitter from 'events';
import { AdapterConfig, BaseAdapterSettings, SettingsDefinitionMap } from '../config';
import { AdapterRequest, AdapterResponse } from '../util';
import { AdapterError } from '../validation/error';
import { EmptyInputParameters } from '../validation/input-params';
import { AdapterEndpoint } from './endpoint';
import { AdapterDependencies, AdapterParams, AdapterRateLimitingConfig, EndpointGenerics } from './types';
/**
 * Main class to represent an External Adapter
 */
export declare class Adapter<CustomSettingsDefinition extends SettingsDefinitionMap = SettingsDefinitionMap> implements Omit<AdapterParams<CustomSettingsDefinition>, 'bootstrap'> {
    name: Uppercase<string>;
    defaultEndpoint?: string | undefined;
    endpoints: AdapterEndpoint<EndpointGenerics>[];
    envDefaultOverrides?: Partial<BaseAdapterSettings> | undefined;
    rateLimiting?: AdapterRateLimitingConfig | undefined;
    envVarsPrefix?: string;
    initialized: boolean;
    /** Object containing alias translations for all endpoints */
    endpointsMap: Record<string, AdapterEndpoint<EndpointGenerics>>;
    /** Initialized dependencies that the adapter will use */
    dependencies: AdapterDependencies;
    /** Configuration params for various adapter properties */
    config: AdapterConfig<CustomSettingsDefinition>;
    /** Used on api shutdown for testing purposes*/
    shutdownNotifier: EventEmitter;
    /** Promise that will resolve once the adapter cache has acquired a lock */
    lockAcquiredPromise?: Promise<boolean>;
    /** Bootstrap function that will run when initializing the adapter */
    private readonly bootstrap?;
    constructor(params: AdapterParams<CustomSettingsDefinition>);
    /**
     * Initializes all of the [[Transport]]s in the adapter, passing along any [[AdapterDependencies]] and [[AdapterConfig]].
     * Additionally, it builds a map out of all the endpoint names and aliases (checking for duplicates).
     */
    initialize(dependencies?: Partial<AdapterDependencies>): Promise<void>;
    /**
     * Takes an adapter and normalizes all endpoint names and aliases, as well as the default endpoint.
     * i.e. makes them lowercase for now
     */
    private normalizeEndpointNames;
    /**
     * This function will take an adapter structure and go through each endpoint, calculating
     * each one's allocation of the total rate limits that are set for the adapter as a whole.
     *
     */
    private calculateRateLimitAllocations;
    private logRateLimitAllocations;
    /**
     * Logs a warning for certain configs if set to particular values.
     * Used to warn stakeholders of potential risks.
     */
    private logConfigWarnings;
    /**
     * This function will process dependencies for an adapter, such as caches or rate limiters,
     * in order to inject them into transports and other relevant places later in the lifecycle.
     *
     * @param inputDependencies - a partial obj of initialized dependencies to override the created ones
     * @returns a set of AdapterDependencies all initialized
     */
    initializeDependencies(inputDependencies?: Partial<AdapterDependencies>): AdapterDependencies;
    /**
     * Attempts to find a value from the Cache and return that if found.
     *
     * @param req - the incoming request to this adapter
     * @returns the cached value if exists
     */
    findResponseInCache(req: AdapterRequest<EmptyInputParameters>): Promise<Readonly<AdapterResponse> | undefined>;
    /**
     * Applies per-request transforms to a response. Called on every path that returns a response
     * to a caller, including the gRPC push path.
     *
     * @param req - the incoming request this response is being returned for
     * @param response - the response about to be returned to the caller
     * @returns the transformed response
     */
    finalizeResponse(req: AdapterRequest<EmptyInputParameters>, response: Readonly<AdapterResponse>): Readonly<AdapterResponse>;
    validateOutput(req: AdapterRequest<EmptyInputParameters>, output: Readonly<AdapterResponse>): AdapterError | undefined;
    handleRequestWithValidation(req: AdapterRequest<EmptyInputParameters>, replySent: Promise<unknown>): Promise<Readonly<AdapterResponse>>;
    /**
     * Function to serve as middleware to pass along the AdapterRequest to the appropriate Transport (acc. to the endpoint in the req.)
     *
     * @param req - the incoming request to this adapter
     * @param replySent - a promise that resolves when the reply has already been sent
     * @returns a simple Promise when it's done
     */
    handleRequest(req: AdapterRequest<EmptyInputParameters>, replySent: Promise<unknown>): Promise<Readonly<AdapterResponse>>;
}
