import { Validator } from '../validation/utils';
export declare const BaseSettingsDefinition: {
    readonly API_TIMEOUT: {
        readonly description: "The number of milliseconds a request can be pending before returning a timeout error for data provider request";
        readonly type: "number";
        readonly default: 30000;
        readonly validate: Validator<string | number>;
    };
    readonly API_VERBOSE: {
        readonly description: "Toggle whether the response from the EA should contain just the results or also include the full response body from the queried API.";
        readonly type: "boolean";
        readonly default: false;
    };
    readonly BASE_URL: {
        readonly description: "Starting path for the EA handler endpoint";
        readonly type: "string";
        readonly default: "/";
        readonly sensitive: false;
    };
    readonly CACHE_LOCK_DURATION: {
        readonly description: "Time (in ms) used as a baseline for the acquisition and extension of cache locks";
        readonly type: "number";
        readonly default: 10000;
    };
    readonly CACHE_LOCK_RETRIES: {
        readonly description: "Number of retries to acquire a cache lock";
        readonly type: "number";
        readonly default: 10;
    };
    readonly CACHE_LOCK_DEFERRAL_MS: {
        readonly description: "The amount of time (in ms) to wait before attempting to lock the cache";
        readonly type: "number";
        readonly default: 60000;
    };
    readonly CACHE_MAX_AGE: {
        readonly description: "Maximum amount of time (in ms) that a response will stay cached";
        readonly type: "number";
        readonly default: 90000;
        readonly validate: Validator<string | number>;
    };
    readonly CACHE_MAX_ITEMS: {
        readonly type: "number";
        readonly description: "The maximum number of items that remain in the cache";
        readonly default: 10000;
        readonly validate: Validator<string | number>;
    };
    readonly CACHE_REDIS_CONNECTION_TIMEOUT: {
        readonly description: "Connection timeout for redis client";
        readonly type: "number";
        readonly default: 15000;
        readonly validate: Validator<string | number>;
    };
    readonly CACHE_REDIS_HOST: {
        readonly description: "Hostname for the Redis instance to be used";
        readonly type: "string";
        readonly default: "127.0.0.1";
        readonly sensitive: false;
    };
    readonly CACHE_REDIS_MAX_RECONNECT_COOLDOWN: {
        readonly description: "Max cooldown (in ms) before attempting redis reconnection";
        readonly type: "number";
        readonly default: 3000;
        readonly validate: Validator<string | number>;
    };
    readonly CACHE_REDIS_PASSWORD: {
        readonly description: "The password required for redis auth";
        readonly type: "string";
        readonly sensitive: true;
    };
    readonly CACHE_REDIS_PATH: {
        readonly description: "The UNIX socket string of the Redis server";
        readonly type: "string";
        readonly sensitive: false;
    };
    readonly CACHE_REDIS_PORT: {
        readonly description: "Port for the Redis instance to be used";
        readonly type: "number";
        readonly default: 6379;
        readonly validate: Validator<string | number>;
    };
    readonly CACHE_REDIS_TIMEOUT: {
        readonly description: "Timeout to fail a Redis server request if no response (ms)";
        readonly type: "number";
        readonly default: 500;
        readonly validate: Validator<string | number>;
    };
    readonly CACHE_REDIS_URL: {
        readonly description: "The URL of the Redis server. Format: [redis[s]:]//[[user][:password@]][host][:port][/db-number][?db=db-number[&password=bar[&option=value]]]";
        readonly type: "string";
        readonly validate: Validator<string>;
        readonly sensitive: true;
    };
    readonly CACHE_TYPE: {
        readonly description: "The type of cache to use throughout the EA";
        readonly type: "enum";
        readonly default: "local";
        readonly options: readonly ["local", "redis"];
    };
    readonly CACHE_PREFIX: {
        readonly description: "Specifies a prefix to use for cache keys";
        readonly type: "string";
        readonly default: "";
        readonly sensitive: false;
    };
    readonly STREAM_HANDLER_RETRY_MAX_MS: {
        readonly type: "number";
        readonly description: "The maximum time (ms) to wait before running the stream handler (takes precedent over STREAM_HANDLER_RETRY_MIN_MS";
        readonly default: number;
        readonly validate: Validator<string | number>;
    };
    readonly STREAM_HANDLER_RETRY_MIN_MS: {
        readonly type: "number";
        readonly description: "The minimum/base time (ms) to wait before trying to run the stream handler";
        readonly default: 100;
        readonly validate: Validator<string | number>;
    };
    readonly STREAM_HANDLER_RETRY_EXP_FACTOR: {
        readonly type: "number";
        readonly description: "The factor for exponential back-off to wait before running the stream handler (1 = no change from STREAM_HANDLER_RETRY_MIN_MS)";
        readonly default: 3;
        readonly validate: Validator<string | number>;
    };
    readonly SUBSCRIPTION_SET_MAX_ITEMS: {
        readonly type: "number";
        readonly description: "The maximum number of subscriptions set";
        readonly default: 10000;
        readonly validate: Validator<string | number>;
    };
    readonly CORRELATION_ID_ENABLED: {
        readonly description: "Flag to enable correlation IDs for sent requests in logging";
        readonly type: "boolean";
        readonly default: true;
    };
    readonly DEBUG: {
        readonly description: "Toggles debug mode";
        readonly type: "boolean";
        readonly default: false;
    };
    readonly EA_PORT: {
        readonly description: "Port through which the EA will listen for REST requests (if mode is set to \"reader\" or \"reader-writer\")";
        readonly type: "number";
        readonly default: 8080;
        readonly validate: Validator<string | number>;
    };
    readonly EXPERIMENTAL_METRICS_ENABLED: {
        readonly description: "Flag to specify whether or not to collect metrics. Used as fallback for METRICS_ENABLED";
        readonly type: "boolean";
        readonly default: true;
    };
    readonly LOG_LEVEL: {
        readonly description: "Minimum level required for logs to be output";
        readonly type: "string";
        readonly default: "info";
        readonly sensitive: false;
    };
    readonly CENSOR_SENSITIVE_LOGS: {
        readonly description: "Controls whether the logging of sensitive information is enabled or disabled";
        readonly type: "boolean";
        readonly default: false;
    };
    readonly MAX_PAYLOAD_SIZE_LIMIT: {
        readonly description: "Max payload size limit for the Fastify server";
        readonly type: "number";
        readonly default: 1048576;
        readonly validate: Validator<string | number>;
    };
    readonly METRICS_ENABLED: {
        readonly description: "Flag to specify whether or not to startup the metrics server";
        readonly type: "boolean";
        readonly default: true;
    };
    readonly METRICS_PORT: {
        readonly description: "Port metrics will be exposed to";
        readonly type: "number";
        readonly default: 9080;
        readonly validate: Validator<string | number>;
    };
    readonly METRICS_USE_BASE_URL: {
        readonly description: "Flag to specify whether or not to prepend the BASE_URL to the metrics endpoint";
        readonly type: "boolean";
    };
    readonly RATE_LIMIT_API_TIER: {
        readonly description: "Rate limiting tier to use from the available options for the adapter. If not present, the adapter will run using the first tier on the list.";
        readonly type: "string";
        readonly sensitive: false;
    };
    readonly RATE_LIMIT_CAPACITY: {
        readonly description: "Used as rate limit capacity per minute and ignores tier settings if defined";
        readonly type: "number";
        readonly validate: Validator<string | number>;
    };
    readonly RATE_LIMIT_CAPACITY_MINUTE: {
        readonly description: "Used as rate limit capacity per minute and ignores tier settings if defined. Supercedes RATE_LIMIT_CAPACITY if both vars are set";
        readonly type: "number";
        readonly validate: Validator<string | number>;
    };
    readonly RATE_LIMIT_CAPACITY_SECOND: {
        readonly description: "Used as rate limit capacity per second and ignores tier settings if defined";
        readonly type: "number";
        readonly validate: Validator<string | number>;
    };
    readonly RETRY: {
        readonly type: "number";
        readonly description: "Retry count for failed HTTP requests";
        readonly default: 1;
        readonly validate: Validator<string | number>;
    };
    readonly SSE_KEEPALIVE_SLEEP: {
        readonly description: "Maximum amount of time (in ms) between each SSE keepalive request";
        readonly type: "number";
        readonly default: 60000;
        readonly validate: Validator<string | number>;
    };
    readonly SSE_SUBSCRIPTION_TTL: {
        readonly description: "Maximum amount of time (in ms) an SSE subscription will be cached before being unsubscribed";
        readonly type: "number";
        readonly default: 300000;
        readonly validate: Validator<string | number>;
    };
    readonly WARMUP_SUBSCRIPTION_TTL: {
        readonly type: "number";
        readonly description: "TTL for batch warmer subscriptions";
        readonly default: 300000;
        readonly validate: Validator<string | number>;
    };
    readonly WS_SUBSCRIPTION_TTL: {
        readonly description: "The time in ms a request will live in the subscription set before becoming stale";
        readonly type: "number";
        readonly default: 120000;
        readonly validate: Validator<string | number>;
    };
    readonly WS_SUBSCRIPTION_UNRESPONSIVE_TTL: {
        readonly description: "The maximum acceptable time (in milliseconds) since the last message was received and stored in the cache on a WebSocket connection before it is considered unresponsive, causing the adapter to close and attempt to reopen it.";
        readonly type: "number";
        readonly default: 120000;
        readonly validate: Validator<string | number>;
    };
    readonly WS_CONNECTION_OPEN_TIMEOUT: {
        readonly description: "The maximum amount of time in milliseconds to wait for the websocket connection to open (including custom open handler)";
        readonly type: "number";
        readonly default: 10000;
        readonly validate: Validator<string | number>;
    };
    readonly WS_HEARTBEAT_INTERVAL_MS: {
        readonly description: "The number of ms between each hearbeat message that EA sends to server, only works if heartbeat handler is provided";
        readonly type: "number";
        readonly default: 10000;
        readonly validate: Validator<string | number>;
    };
    readonly CACHE_POLLING_MAX_RETRIES: {
        readonly description: "Max amount of times to attempt to find EA response in the cache after the Transport has been set up";
        readonly type: "number";
        readonly default: 10;
        readonly validate: Validator<string | number>;
    };
    readonly CACHE_POLLING_SLEEP_MS: {
        readonly description: "The number of ms to sleep between each retry to fetch the EA response in the cache";
        readonly type: "number";
        readonly default: 200;
        readonly validate: Validator<string | number>;
    };
    readonly DEFAULT_CACHE_KEY: {
        readonly description: "Default key to be used when one cannot be determined from request parameters";
        readonly type: "string";
        readonly default: "DEFAULT_CACHE_KEY";
        readonly sensitive: false;
    };
    readonly EA_HOST: {
        readonly description: "Host this EA will listen for REST requests on (if mode is set to \"reader\" or \"reader-writer\")";
        readonly type: "string";
        readonly default: "::";
        readonly validate: Validator<string>;
        readonly sensitive: false;
    };
    readonly EA_MODE: {
        readonly description: "Port this EA will listen for REST requests on (if mode is set to \"reader\" or \"reader-writer\")";
        readonly type: "enum";
        readonly default: "reader-writer";
        readonly options: readonly ["reader", "writer", "reader-writer"];
    };
    readonly MAX_COMMON_KEY_SIZE: {
        readonly description: "Maximum amount of characters that the common part of the cache key or feed ID can have";
        readonly type: "number";
        readonly default: 300;
        readonly validate: Validator<string | number>;
    };
    readonly FEED_ID_JSON: {
        readonly description: "Flag to specify whether make feed id always a JSON string or not";
        readonly type: "boolean";
        readonly default: false;
    };
    readonly GRPC_ENABLED: {
        readonly description: "Flag to specify whether or not to serve the gRPC streaming interface. Requires EA_MODE to be \"writer\" or \"reader-writer\", since observations are pushed from the process that writes the cache";
        readonly type: "boolean";
        readonly default: false;
    };
    readonly GRPC_HOST: {
        readonly description: "Host the gRPC streaming server will listen on (if GRPC_ENABLED is set)";
        readonly type: "string";
        readonly default: "::";
        readonly validate: Validator<string>;
        readonly sensitive: false;
    };
    readonly GRPC_PORT: {
        readonly description: "Port the gRPC streaming server will listen on (if GRPC_ENABLED is set). Set equal to EA_PORT to share one plaintext listener between REST and gRPC (requires EA_MODE \"reader-writer\", GRPC_HOST equal to EA_HOST, and TLS_ENABLED false); otherwise it must be a distinct port";
        readonly type: "number";
        readonly default: 8081;
        readonly validate: Validator<string | number>;
    };
    readonly GRPC_SUBSCRIPTION_REFRESH_TIMEOUT_MS: {
        readonly description: "Time (in ms) without a valid subscription snapshot after which a gRPC stream loses its subscriptions. This is a guard against a stale stream holding state, not the mechanism that governs how long the adapter keeps fetching a feed - that is the transport subscription TTL, refreshed by each snapshot. Must be comfortably longer than the interval at which clients resend their snapshots, or they will be cleared between refreshes";
        readonly type: "number";
        readonly default: 180000;
        readonly validate: Validator<string | number>;
    };
    readonly GRPC_MAX_SUBSCRIPTIONS_PER_STREAM: {
        readonly description: "Maximum number of subscriptions a single gRPC stream can hold";
        readonly type: "number";
        readonly default: 10000;
        readonly validate: Validator<string | number>;
    };
    readonly GRPC_SUBSCRIBER_QUEUE_SIZE: {
        readonly description: "Hard cap on observations queued for a single gRPC stream before new ones are dropped. At most one observation is queued per subscription, so this only binds when it is below the number of subscriptions the client holds";
        readonly type: "number";
        readonly default: 10000;
        readonly validate: Validator<string | number>;
    };
    readonly GRPC_MAX_CONCURRENT_STREAMS: {
        readonly description: "Maximum number of concurrent streams the gRPC server will accept per connection";
        readonly type: "number";
        readonly default: 100;
        readonly validate: Validator<string | number>;
    };
    readonly MTLS_ENABLED: {
        readonly description: "Flag to specify whether mutual TLS/SSL is enabled or not";
        readonly type: "boolean";
        readonly default: false;
    };
    readonly TLS_ENABLED: {
        readonly description: "Flag to specify whether TLS/SSL is enabled or not";
        readonly type: "boolean";
        readonly default: false;
    };
    readonly TLS_PRIVATE_KEY: {
        readonly description: "Base64 Private Key of TSL/SSL certificate";
        readonly type: "string";
        readonly validate: Validator<string>;
        readonly sensitive: true;
    };
    readonly TLS_PUBLIC_KEY: {
        readonly description: "Base64 Public Key of TSL/SSL certificate";
        readonly type: "string";
        readonly validate: Validator<string>;
        readonly sensitive: false;
    };
    readonly TLS_PASSPHRASE: {
        readonly description: "Password to be used to generate an encryption key";
        readonly type: "string";
        readonly default: "";
        readonly sensitive: true;
    };
    readonly TLS_CA: {
        readonly description: "CA certificate to use for authenticating client certificates";
        readonly type: "string";
        readonly sensitive: true;
    };
    readonly MAX_HTTP_REQUEST_QUEUE_LENGTH: {
        readonly description: "The maximum amount of queued requests for Http transports before new ones push oldest ones out of the queue";
        readonly type: "number";
        readonly default: 200;
        readonly validate: Validator<string | number>;
    };
    readonly BACKGROUND_EXECUTE_MS_SSE: {
        readonly description: "Time in milliseconds to sleep between SSE transports' background execute calls";
        readonly type: "number";
        readonly default: 1000;
        readonly validate: Validator<string | number>;
    };
    readonly BACKGROUND_EXECUTE_MS_WS: {
        readonly description: "Time in milliseconds to sleep between WS transports' background execute calls";
        readonly type: "number";
        readonly default: 1000;
        readonly validate: Validator<string | number>;
    };
    readonly BACKGROUND_EXECUTE_MS_HTTP: {
        readonly description: "Time in milliseconds to sleep between HTTP transports' background execute calls, when there are no requests to send";
        readonly type: "number";
        readonly default: 1000;
        readonly validate: Validator<string | number>;
    };
    readonly BACKGROUND_EXECUTE_TIMEOUT: {
        readonly description: "The maximum amount of time in milliseconds to wait for a background execute to finish";
        readonly type: "number";
        readonly default: 90000;
        readonly validate: Validator<string | number>;
    };
    readonly RATE_LIMITING_STRATEGY: {
        readonly description: "The rate limiting strategy to use for outbound requests";
        readonly type: "enum";
        readonly options: readonly ["burst", "fixed-interval"];
        readonly default: "fixed-interval";
    };
    readonly REQUESTER_SLEEP_BEFORE_REQUEUEING_MS: {
        readonly type: "number";
        readonly description: "Time to sleep after a failed HTTP request before re-queueing the request (in ms)";
        readonly default: 0;
        readonly validate: Validator<string | number>;
    };
    readonly DEBUG_ENDPOINTS: {
        readonly type: "boolean";
        readonly description: "Whether to enable debug enpoints (/debug/*) for this adapter. Enabling them might consume more resources.";
        readonly default: false;
    };
    readonly COMPOSITE_TRANSPORT: {
        readonly type: "boolean";
        readonly description: "Whether to use enableCompositeTransport parameter in AdapterEndpoint";
        readonly default: false;
    };
};
/**
 * Whether this instance should serve the gRPC streaming interface.
 *
 * Observations are pushed from the process that writes the response cache, so only the writing
 * modes can serve them; `GRPC_ENABLED` with `EA_MODE=reader` is rejected during validation rather
 * than silently degraded, because a reader that accepts streams and never pushes looks healthy while
 * starving its clients.
 *
 * @param adapterSettings - the adapter settings to check
 * @returns true if the gRPC server should be started
 */
export declare const grpcServingEnabled: (adapterSettings: BaseAdapterSettings) => boolean;
/**
 * Whether the gRPC server should share `EA_PORT` with the REST API through the plaintext port
 * multiplexer (`src/grpc/port-mux.ts`), instead of binding its own separate listener on `GRPC_PORT`.
 *
 * `GRPC_PORT === EA_PORT` opts in, but only when that port is not `0`: `0` means "let the OS assign
 * one", and two independent binds of `0` get two different, unrelated ephemeral ports rather than
 * sharing one, so treating that combination as an opt-in would be a false positive — notably for any
 * adapter (e.g. `EA_MODE=writer`, where `EA_PORT` is unused) that leaves both at the test suite's
 * conventional default of `0` with no intention of sharing anything.
 *
 * The cross-setting validation in `AdapterConfig.validate` further rejects a non-zero match unless
 * `EA_MODE` is `"reader-writer"` (so there is a real REST listener to share with), `GRPC_HOST` equals
 * `EA_HOST` (a shared listener can only bind one host), and `TLS_ENABLED` is false (the multiplexer
 * only inspects plaintext connections).
 *
 * @param adapterSettings - the adapter settings to check
 * @returns true if `expose()` should bind one shared listener instead of two
 */
export declare const grpcPortSharingEnabled: (adapterSettings: BaseAdapterSettings) => boolean;
export declare const buildAdapterSettings: <CustomSettings extends CustomSettingsDefinition<CustomSettings> = EmptySettingsDefinitionMap>({ overrides, customSettings, envVarsPrefix, }: {
    overrides?: Partial<BaseAdapterSettings> | undefined;
    customSettings?: SettingsDefinitionMap | undefined;
    envVarsPrefix?: string | undefined;
}) => AdapterSettings<CustomSettings>;
export declare const getEnvOrEnvGetter: (name: string, settingsDefinition: SettingDefinition, prefix?: string) => SettingValueType | undefined | Getter<SettingValueType | undefined>;
export declare const getEnv: (name: string, settingsDefinition: SettingDefinition, prefix?: string) => SettingValueType | null;
export declare const parseEnv: (value: string | undefined, name: string, settingsDefinition: SettingDefinition) => SettingValueType | null;
type VariableEnvVarEntry<T extends ValidSettingValue> = {
    settingKey: string;
    variable: string;
    settingName: string;
    envVarName: string;
    value: T;
};
export interface Getter<T extends SettingValueType | undefined> {
    get(variable: string): T;
    getEnvVarName(variable: string): string;
    entries(): VariableEnvVarEntry<Exclude<T, undefined>>[];
}
export declare class EnvGetter<T extends SettingDefinition & IsVariable = Extract<SettingDefinition, IsVariable>> {
    private name;
    private settingsDefinition;
    private prefix;
    private variableMap;
    constructor(name: string, settingsDefinition: T, prefix: string);
    getNamePattern(name: string, placeholder: string, prefix: string): RegExp;
    private getCanonicalVariable;
    get(variable: string): SettingType<T>;
    getEnvVarName(variable: string): string;
    entries(): VariableEnvVarEntry<SettingTypeWhenPresent<T>>[];
    validate(validationErrors: string[]): void;
}
type SettingValueType = string | number | boolean;
type SettingTypeWhenPresent<C extends SettingDefinition> = C['type'] extends 'string' ? string : C['type'] extends 'number' ? number : C['type'] extends 'boolean' ? boolean : C['type'] extends 'enum' ? C['options'] extends readonly string[] ? C['options'][number] : never : never;
type SettingType<C extends SettingDefinition> = C extends HasDefault | IsRequired ? SettingTypeWhenPresent<C> : SettingTypeWhenPresent<C> | undefined;
export type BaseSettingsDefinitionType = typeof BaseSettingsDefinition;
export type SettingDefinitionBase = {
    description: string;
    sensitive?: boolean;
    required?: boolean;
} & ({
    variablePlaceholder?: never;
} | {
    variablePlaceholder: string;
});
export type NonEnumSettingDefinition<TypeString, Type> = SettingDefinitionBase & {
    type: TypeString;
    default?: Type;
    validate?: Validator<Type>;
    options?: never;
};
export type EnumSettingDefinition = SettingDefinitionBase & {
    type: 'enum';
    default?: string;
    validate?: Validator<string>;
    options: readonly string[];
};
export type SettingDefinition = NonEnumSettingDefinition<'string', string> | NonEnumSettingDefinition<'number', number> | NonEnumSettingDefinition<'boolean', boolean> | EnumSettingDefinition;
type HasDefault = {
    default: SettingValueType;
};
type IsRequired = {
    required: true;
};
type IsOptional = {
    default?: never;
    required?: false;
    description: string;
};
type IsVariable = {
    variablePlaceholder: string;
};
type IsFixed = {
    variablePlaceholder?: never;
    description: string;
};
type VariableSettingKeys<T extends SettingsDefinitionMap> = {
    [K in keyof T]: T[K] extends IsVariable ? K : never;
}[keyof T];
type FixedSettingKeys<T extends SettingsDefinitionMap> = {
    [K in keyof T]: T[K] extends IsFixed ? K : never;
}[keyof T];
type NonOptionalSettingKeys<T extends SettingsDefinitionMap> = {
    [K in keyof T]: T[K] extends HasDefault | IsRequired ? K : never;
}[keyof T];
type OptionalSettingKeys<T extends SettingsDefinitionMap> = {
    [K in keyof T]: T[K] extends IsOptional ? K : never;
}[keyof T];
export type Settings<T extends SettingsDefinitionMap> = {
    -readonly [K in Extract<FixedSettingKeys<T>, OptionalSettingKeys<T>>]?: SettingTypeWhenPresent<T[K]> | undefined;
} & {
    -readonly [K in Extract<FixedSettingKeys<T>, NonOptionalSettingKeys<T>>]: SettingTypeWhenPresent<T[K]>;
} & {
    -readonly [K in VariableSettingKeys<T>]: Getter<SettingType<T[K]>>;
};
export type BaseAdapterSettings = Settings<BaseSettingsDefinitionType>;
export type EmptyCustomSettings = BaseAdapterSettings;
export type AdapterSettings<T extends CustomSettingsDefinition<T> = object> = Settings<T> & BaseAdapterSettings & SettingsObjectSpecifier;
export type CustomSettingsDefinition<T = SettingsDefinitionMap> = Record<keyof T, SettingDefinition>;
export type EmptySettingsDefinitionMap = Record<string, never>;
export type SettingsDefinitionMap = Record<string, SettingDefinition>;
export type ValidationErrorMessage = string | undefined;
export type SettingsDefinitionFromConfig<T> = T extends AdapterConfig<infer Definition> ? Definition : never;
export type SettingDefinitionDetails = {
    type: string;
    description: string;
    required: boolean;
    sensitive: boolean;
    default: unknown;
    customSetting: boolean;
    envDefaultOverride: unknown;
};
/**
 * This class will hold the processed config type, and the basic settings.
 * The idea is that you can no longer use a straight object, but have to build a config,
 * then in the generics we can simply pass the type of this, and it will hopefully allow for simpler generics
 */
export declare class AdapterConfig<T extends SettingsDefinitionMap = SettingsDefinitionMap> {
    /** Map of setting definitions to validate and use to get setting values */
    private settingsDefinition;
    options?: {
        /** Map of overrides to the default config values for an Adapter */
        envDefaultOverrides?: Partial<BaseAdapterSettings>;
        /** Optional prefix that all adapter variables will be expected to have */
        envVarsPrefix?: string;
    } | undefined;
    settings: AdapterSettings<T>;
    constructor(
    /** Map of setting definitions to validate and use to get setting values */
    settingsDefinition: T, options?: {
        /** Map of overrides to the default config values for an Adapter */
        envDefaultOverrides?: Partial<BaseAdapterSettings>;
        /** Optional prefix that all adapter variables will be expected to have */
        envVarsPrefix?: string;
    } | undefined);
    /**
     * Performs some basic validation of the definition structure, and pull data from environment variables
     */
    initialize(): void;
    /**
     * Performs validation of each setting, checking to see that they match their definition
     */
    validate(): void;
    /**
     * Creates a list of key/value pairs that need to be censored in the logs
     * using the sensitive flag in the adapter config
     * RPC_URL are potentially sensitive given it may contain API keys in path
     */
    buildCensorList(): void;
    getSettingDebugDetails(settingName: string): SettingDefinitionDetails;
}
type SettingsObjectSpecifier = {
    __reserved_settings: never;
};
export type ValidSettingValue = string | number | boolean;
export type GenericConfigStructure = BaseAdapterSettings & SettingsObjectSpecifier;
export {};
