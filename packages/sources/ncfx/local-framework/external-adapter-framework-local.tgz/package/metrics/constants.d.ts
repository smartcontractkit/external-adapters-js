export declare enum HttpRequestType {
    CACHE_HIT = "cacheHit",
    DATA_PROVIDER_HIT = "dataProviderHit",
    ADAPTER_ERROR = "adapterError",
    INPUT_ERROR = "inputError",
    RATE_LIMIT_ERROR = "rateLimitError",
    DP_ERROR = "dataProviderError",
    TIMEOUT_ERROR = "timeoutError",
    CONNECTION_ERROR = "connectionError",
    CUSTOM_ERROR = "customError",
    LWBA_ERROR = "lwbaError"
}
/**
 * Reasons why an observation was dropped instead of being sent to a gRPC stream.
 */
export declare enum GrpcDropReason {
    /** The stream's outbound queue was at its hard cap, i.e. the consumer is genuinely saturated. */
    QUEUE_FULL = "queueFull",
    /** A newer observation replaced an unsent one for the same subscription. Expected under load. */
    SUPERSEDED = "superseded"
}
/**
 * Reasons why a gRPC subscription snapshot was rejected, leaving the stream's subscriptions
 * untouched.
 */
export declare enum GrpcSnapshotErrorType {
    INVALID_SUBSCRIPTION = "invalidSubscription",
    TOO_MANY_SUBSCRIPTIONS = "tooManySubscriptions"
}
/**
 * Maxiumum number of characters that a feedId can contain.
 */
export declare const MAX_FEED_ID_LENGTH = 300;
export declare const requestDurationBuckets: number[];
