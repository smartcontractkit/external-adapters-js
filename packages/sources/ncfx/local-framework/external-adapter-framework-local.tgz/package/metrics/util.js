"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getMetricsMeta = void 0;
const cache_1 = require("../cache");
const getMetricsMeta = (args, data) => {
    const feedId = (0, cache_1.calculateFeedId)(args, data);
    return { feedId };
};
exports.getMetricsMeta = getMetricsMeta;
//# sourceMappingURL=util.js.map