import { EndpointGenerics } from '../adapter';
import { AdapterMetricsMeta, AdapterRequestData } from '../util';
import { InputParameters } from '../validation';
export declare const getMetricsMeta: <T extends EndpointGenerics>(args: {
    inputParameters: InputParameters<T["Parameters"]>;
    adapterSettings: T["Settings"];
}, data: AdapterRequestData) => AdapterMetricsMeta;
