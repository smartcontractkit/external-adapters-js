"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.requestDurationBuckets = exports.MAX_FEED_ID_LENGTH = exports.GrpcSnapshotErrorType = exports.GrpcDropReason = exports.HttpRequestType = void 0;
var HttpRequestType;
(function (HttpRequestType) {
    HttpRequestType["CACHE_HIT"] = "cacheHit";
    HttpRequestType["DATA_PROVIDER_HIT"] = "dataProviderHit";
    HttpRequestType["ADAPTER_ERROR"] = "adapterError";
    HttpRequestType["INPUT_ERROR"] = "inputError";
    HttpRequestType["RATE_LIMIT_ERROR"] = "rateLimitError";
    // BURST_LIMIT_ERROR = 'burstLimitError',
    // BACKOFF_ERROR = 'backoffError',
    HttpRequestType["DP_ERROR"] = "dataProviderError";
    HttpRequestType["TIMEOUT_ERROR"] = "timeoutError";
    HttpRequestType["CONNECTION_ERROR"] = "connectionError";
    // RES_EMPTY_ERROR = 'responseEmptyError',
    // RES_INVALID_ERROR = 'responseInvalidError',
    HttpRequestType["CUSTOM_ERROR"] = "customError";
    HttpRequestType["LWBA_ERROR"] = "lwbaError";
})(HttpRequestType || (exports.HttpRequestType = HttpRequestType = {}));
/**
 * Reasons why an observation was dropped instead of being sent to a gRPC stream.
 */
var GrpcDropReason;
(function (GrpcDropReason) {
    /** The stream's outbound queue was at its hard cap, i.e. the consumer is genuinely saturated. */
    GrpcDropReason["QUEUE_FULL"] = "queueFull";
    /** A newer observation replaced an unsent one for the same subscription. Expected under load. */
    GrpcDropReason["SUPERSEDED"] = "superseded";
})(GrpcDropReason || (exports.GrpcDropReason = GrpcDropReason = {}));
/**
 * Reasons why a gRPC subscription snapshot was rejected, leaving the stream's subscriptions
 * untouched.
 */
var GrpcSnapshotErrorType;
(function (GrpcSnapshotErrorType) {
    GrpcSnapshotErrorType["INVALID_SUBSCRIPTION"] = "invalidSubscription";
    GrpcSnapshotErrorType["TOO_MANY_SUBSCRIPTIONS"] = "tooManySubscriptions";
})(GrpcSnapshotErrorType || (exports.GrpcSnapshotErrorType = GrpcSnapshotErrorType = {}));
/**
 * Maxiumum number of characters that a feedId can contain.
 */
exports.MAX_FEED_ID_LENGTH = 300;
// We should tune these as we collect data, this is the default bucket distribution that prom comes with
exports.requestDurationBuckets = [0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10];
//# sourceMappingURL=constants.js.map