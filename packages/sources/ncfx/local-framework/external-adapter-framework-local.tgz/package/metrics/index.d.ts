import { FastifyReply, FastifyRequest, HookHandlerDoneFunction } from 'fastify';
import * as client from 'prom-client';
import { AdapterSettings } from '../config';
import { AdapterError } from '../validation/error';
export declare enum CMD_SENT_STATUS {
    TIMEOUT = "TIMEOUT",
    FAIL = "FAIL",
    SUCCESS = "SUCCESS"
}
export declare function setupMetricsServer(name: string, adapterSettings: AdapterSettings): import("fastify").FastifyInstance<import("http").Server<typeof import("http").IncomingMessage, typeof import("http").ServerResponse>, import("http").IncomingMessage, import("http").ServerResponse<import("http").IncomingMessage>, import("fastify").FastifyBaseLogger, import("fastify").FastifyTypeProviderDefault> & PromiseLike<import("fastify").FastifyInstance<import("http").Server<typeof import("http").IncomingMessage, typeof import("http").ServerResponse>, import("http").IncomingMessage, import("http").ServerResponse<import("http").IncomingMessage>, import("fastify").FastifyBaseLogger, import("fastify").FastifyTypeProviderDefault>> & {
    __linterBrands: "SafePromiseLike";
};
export declare const setupMetrics: (name: string) => void;
/**
 * Builds metrics middleware that records end to end EA response times
 * and count of requests
 *
 * @returns the cache middleware function
 */
export declare const buildMetricsMiddleware: (rawReq: FastifyRequest, res: FastifyReply, done: HookHandlerDoneFunction) => void;
export declare class Metrics<T extends Record<string, unknown>> {
    private metricsDefinition;
    private metrics?;
    constructor(metricsDefinition: () => T);
    initialize(): void;
    getMetricsDefinition(): T | undefined;
    get<K extends keyof T>(name: K): T[K];
    clear(): void;
}
export declare const buildHttpRequestMetricsLabel: (feedId: string, error?: AdapterError | Error, cacheHit?: boolean, responseStatusCode?: number) => Record<string, string | number | undefined>;
export declare const dataProviderMetricsLabel: (providerStatusCode?: number, method?: string) => {
    provider_status_code: number | undefined;
    method: string;
};
export declare const retrieveCost: <ProviderResponseBody>(data: ProviderResponseBody) => number;
export declare const recordRedisCommandMetric: (status: CMD_SENT_STATUS, functionName: string) => void;
export declare const metrics: Metrics<{
    httpRequestsTotal: client.Counter<"type" | "method" | "status_code" | "retry" | "feed_id" | "provider_status_code">;
    httpRequestDurationSeconds: client.Histogram<string>;
    httpRequestsPerBgExecute: client.Gauge<"adapter_endpoint">;
    dataProviderRequests: client.Counter<"method" | "provider_status_code">;
    dataProviderRequestDurationSeconds: client.Histogram<string>;
    requesterQueueSize: client.Gauge<string>;
    requesterQueueOverflow: client.Counter<string>;
    requestPayloadSize: client.Histogram<string>;
    bgExecuteSubscriptionSetCount: client.Gauge<"transport" | "adapter_endpoint" | "transport_type">;
    bgExecuteTotal: client.Counter<"transport" | "adapter_endpoint">;
    bgExecuteErrors: client.Counter<"transport" | "adapter_endpoint">;
    bgExecuteDurationSeconds: client.Gauge<"transport" | "adapter_endpoint">;
    cacheDataGetCount: client.Counter<"feed_id" | "participant_id" | "cache_type">;
    cacheDataGetValues: client.Gauge<"feed_id" | "participant_id" | "cache_type">;
    cacheDataMaxAge: client.Gauge<"feed_id" | "participant_id" | "cache_type">;
    cacheDataSetCount: client.Counter<"status_code" | "feed_id" | "participant_id" | "cache_type">;
    cacheDataStalenessSeconds: client.Gauge<"feed_id" | "participant_id" | "cache_type">;
    cacheOverflowCount: client.Counter<string>;
    totalDataStalenessSeconds: client.Gauge<"feed_id" | "participant_id" | "cache_type">;
    providerTimeDelta: client.Gauge<"feed_id">;
    redisConnectionsOpen: client.Counter<string>;
    redisRetriesCount: client.Counter<string>;
    redisCommandsSentCount: client.Counter<"status" | "function_name">;
    streamHandlerErrors: client.Counter<"transport" | "adapter_endpoint">;
    cacheWarmerCount: client.Gauge<"isBatched">;
    wsConnectionAttempt: client.Counter<string>;
    wsConnectionActive: client.Gauge<string>;
    wsConnectionErrors: client.Counter<"message">;
    wsConnectionClosures: client.Counter<"code" | "url">;
    wsSubscriptionActive: client.Gauge<"feed_id" | "subscription_key">;
    wsSubscriptionTotal: client.Counter<"feed_id" | "subscription_key">;
    wsMessageTotal: client.Counter<"direction" | "feed_id" | "subscription_key">;
    transportPollingFailureCount: client.Counter<"adapter_endpoint">;
    transportPollingDurationSeconds: client.Gauge<"succeeded" | "adapter_endpoint">;
    rateLimitCreditsSpentTotal: client.Counter<"feed_id" | "participant_id">;
    porBalanceAddressLength: client.Gauge<"feed_id">;
    wsConnectionFailoverCount: client.Gauge<"url" | "transport_name">;
    grpcStreamActive: client.Gauge<string>;
    grpcSubscriptionActive: client.Gauge<string>;
    grpcObservationSentTotal: client.Counter<string>;
    grpcObservationDroppedTotal: client.Counter<"reason">;
    grpcSnapshotErrors: client.Counter<"reason">;
}>;
