import { EndpointContext } from '../adapter';
import { ResponseCache } from '../cache/response';
import { AdapterRequest } from '../util/types';
import { TypeFromDefinition } from '../validation/input-params';
import type { Transport, TransportDependencies, TransportGenerics } from '.';
export declare class CompositeTransport<T extends TransportGenerics> implements Transport<T> {
    private readonly transports;
    name: string;
    responseCache: ResponseCache<T>;
    constructor(transports: Record<string, Transport<T>>);
    initialize(dependencies: TransportDependencies<T>, adapterSettings: T['Settings'], endpointName: string, transportName: string): Promise<void>;
    registerRequest(req: AdapterRequest<TypeFromDefinition<T['Parameters']>>, adapterSettings: T['Settings']): Promise<void>;
    backgroundExecute(context: EndpointContext<T>): Promise<void>;
}
