"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.recordWsMessageSubMetrics = exports.recordWsMessageSentMetrics = exports.messageSubsLabels = exports.connectionErrorLabels = void 0;
const cache_1 = require("../cache");
const metrics_1 = require("../metrics");
// Websocket Metrics
const connectionErrorLabels = (message) => ({
    // Key,
    message,
});
exports.connectionErrorLabels = connectionErrorLabels;
const messageSubsLabels = (context, params) => {
    const feedId = (0, cache_1.calculateFeedId)(context, params);
    return {
        feed_id: feedId,
        subscription_key: `${context.endpointName}-${feedId}`,
    };
};
exports.messageSubsLabels = messageSubsLabels;
const recordWsMessageSentMetrics = (context, subscribes, unsubscribes) => {
    for (const params of [...subscribes, ...unsubscribes]) {
        const baseLabels = (0, exports.messageSubsLabels)(context, params);
        // Record total number of ws messages sent
        metrics_1.metrics
            .get('wsMessageTotal')
            .labels({ ...baseLabels, direction: 'sent' })
            .inc();
    }
};
exports.recordWsMessageSentMetrics = recordWsMessageSentMetrics;
// Record WS message and subscription metrics
// Recalculate cacheKey and feedId for metrics
// since avoiding storing extra info in expiring sorted set
const recordWsMessageSubMetrics = (context, subscribes, unsubscribes) => {
    const recordMetrics = (params, type) => {
        const baseLabels = (0, exports.messageSubsLabels)(context, params);
        // Record total number of subscriptions made
        if (type === 'sub') {
            metrics_1.metrics.get('wsSubscriptionTotal').labels(baseLabels).inc();
            metrics_1.metrics.get('wsSubscriptionActive').labels(baseLabels).inc();
        }
        else {
            metrics_1.metrics.get('wsSubscriptionActive').labels(baseLabels).dec();
        }
    };
    subscribes.forEach((params) => {
        recordMetrics(params, 'sub');
    });
    unsubscribes.forEach((params) => {
        recordMetrics(params, 'unsub');
    });
};
exports.recordWsMessageSubMetrics = recordWsMessageSubMetrics;
//# sourceMappingURL=metrics.js.map