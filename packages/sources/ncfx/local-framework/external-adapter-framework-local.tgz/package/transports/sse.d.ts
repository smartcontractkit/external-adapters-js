import { AxiosRequestConfig } from 'axios';
import { EventSource, EventSourceInit } from 'eventsource';
import { EndpointContext } from '../adapter';
import { Requester } from '../util/requester';
import { ProviderResult } from '../util/types';
import { TypeFromDefinition } from '../validation/input-params';
import { TransportDependencies, TransportGenerics } from './';
import { StreamingTransport, SubscriptionDeltas } from './abstract/streaming';
export interface SSEConfig {
    url: string;
    eventSourceInitDict?: EventSourceInit;
}
/**
 * Helper struct type that will be used to pass types to the generic parameters of a Transport.
 * Extends the common TransportGenerics, adding Provider specific types for this SSE endpoint.
 */
type SSETransportGenerics = TransportGenerics & {
    /**
     * Type details for any provider specific interfaces.
     */
    Provider: {
        /**
         * Structure of the body of the request that will be sent to the data provider.
         */
        RequestBody: unknown;
    };
};
/**
 * Transport implementation that establishes a long lived connection to a server using the SSE protocol and subcribes to updates.
 *
 * @typeParam T - Helper struct type that will be used to pass types to the generic parameters (check [[SSETransportGenerics]])
 */
export declare class SseTransport<T extends SSETransportGenerics> extends StreamingTransport<T> {
    private config;
    EventSource: typeof EventSource;
    eventListeners: {
        type: string;
        parseResponse: (evt: MessageEvent) => ProviderResult<T>;
    }[];
    sseConnection?: EventSource;
    timeOfLastReq: number;
    requester: Requester;
    constructor(config: {
        prepareSSEConnectionConfig: (params: TypeFromDefinition<T['Parameters']>[], context: EndpointContext<T>) => SSEConfig;
        prepareKeepAliveRequest?: (context: EndpointContext<T>) => AxiosRequestConfig<T['Provider']['RequestBody']>;
        prepareSubscriptionRequest: (params: TypeFromDefinition<T['Parameters']>[], context: EndpointContext<T>) => AxiosRequestConfig<T['Provider']['RequestBody']>;
        prepareUnsubscriptionRequest: (params: TypeFromDefinition<T['Parameters']>[], context: EndpointContext<T>) => AxiosRequestConfig<T['Provider']['RequestBody']>;
        eventListeners: {
            type: string;
            parseResponse: (evt: MessageEvent) => ProviderResult<T>[];
        }[];
        keepaliveSleepMs?: number;
        pollingSleepMs?: number;
    });
    getSubscriptionTtlFromConfig(adapterSettings: T['Settings']): number;
    initialize(dependencies: TransportDependencies<T>, adapterSettings: T['Settings'], endpointName: string, transportName: string): Promise<void>;
    streamHandler(context: EndpointContext<T>, subscriptions: SubscriptionDeltas<TypeFromDefinition<T['Parameters']>>): Promise<void>;
}
export {};
