import { TransportGenerics } from '.';
import { EndpointContext } from '../adapter';
import { InputParameters } from '../validation';
import { TypeFromDefinition } from '../validation/input-params';
export declare const connectionErrorLabels: (message: string) => {
    message: string;
};
export type MessageDirection = 'sent' | 'received';
export declare const messageSubsLabels: <T extends TransportGenerics>(context: {
    inputParameters: InputParameters<T["Parameters"]>;
    endpointName: string;
    adapterSettings: T["Settings"];
}, params: TypeFromDefinition<T["Parameters"]>) => {
    feed_id: string;
    subscription_key: string;
};
export declare const recordWsMessageSentMetrics: <T extends TransportGenerics>(context: EndpointContext<T>, subscribes: TypeFromDefinition<T["Parameters"]>[], unsubscribes: TypeFromDefinition<T["Parameters"]>[]) => void;
export declare const recordWsMessageSubMetrics: <T extends TransportGenerics>(context: EndpointContext<T>, subscribes: TypeFromDefinition<T["Parameters"]>[], unsubscribes: TypeFromDefinition<T["Parameters"]>[]) => void;
