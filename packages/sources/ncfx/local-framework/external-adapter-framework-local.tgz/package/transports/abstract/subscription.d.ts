import { Transport, TransportDependencies, TransportGenerics } from '..';
import { EndpointContext } from '../../adapter';
import { ResponseCache } from '../../cache/response';
import { SubscriptionSet } from '../../util';
import { AdapterRequest } from '../../util/types';
import { TypeFromDefinition } from '../../validation/input-params';
/**
 * Abstract Transport that will take incoming requests and add them to a subscription set as part
 * of the registration. Then it will provide those entries to the (abstract) backgroundHandler method.
 *
 * @typeParam T - all types related to the [[Transport]]
 */
export declare abstract class SubscriptionTransport<T extends TransportGenerics> implements Transport<T> {
    responseCache: ResponseCache<T>;
    subscriptionSet: SubscriptionSet<TypeFromDefinition<T['Parameters']>>;
    subscriptionTtl: number;
    name: string;
    initialized: boolean;
    initialize(dependencies: TransportDependencies<T>, adapterSettings: T['Settings'], endpointName: string, name: string): Promise<void>;
    registerRequest(req: AdapterRequest<TypeFromDefinition<T['Parameters']>>, _: T['Settings']): Promise<void>;
    backgroundExecute(context: EndpointContext<T>): Promise<void>;
    /**
     * Handler specific to the subscription transport, that is provided all entries in the subscription set.
     *
     * @param context - background context for the execution of this handler
     * @param entries - all the entries in the subscription set
     */
    abstract backgroundHandler(context: EndpointContext<T>, entries: TypeFromDefinition<T['Parameters']>[]): Promise<void>;
    /**
     * Helper method to be defined in subclasses, for each of them to carry their own TTL definition in the EA config.
     *
     * @param adapterSettings - the config for this adapter
     */
    abstract getSubscriptionTtlFromConfig(adapterSettings: T['Settings']): number;
}
