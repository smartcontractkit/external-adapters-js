import { TransportGenerics } from '..';
import { EndpointContext } from '../../adapter';
import { TypeFromDefinition } from '../../validation/input-params';
import { SubscriptionTransport } from './subscription';
/**
 * Object to carry details about the current subscriptions for a StreamingTransport.
 */
export type SubscriptionDeltas<T> = {
    /** All the subscriptions that are valid at this point in time */
    desired: T[];
    /** The subscriptions that have not been processed yet (also included in the desired property) */
    new: T[];
    /** Subscriptions that have expired from the subscription set */
    stale: T[];
};
/**
 * Abstract Transport that will take incoming requests and add them to a subscription set as part
 * of the registration. It also defines an abstract stream handler method, that will be called by the
 * background execute and provided with calculated subscription deltas.
 *
 * @typeParam T - all types related to the [[Transport]]
 */
export declare abstract class StreamingTransport<const T extends TransportGenerics> extends SubscriptionTransport<T> {
    localSubscriptions: TypeFromDefinition<T['Parameters']>[];
    providerDataStreamEstablished: number;
    retryCount: number;
    retryTime: number;
    backgroundHandler(context: EndpointContext<T>, desiredSubs: TypeFromDefinition<T['Parameters']>[]): Promise<void>;
    /**
     * Abstract method that will be provided with context and subscription details, and should take care of
     * handling the connection and messages sent to whatever streaming source is used.
     *
     * @param context - the context related to this background execution
     * @param subscriptions - object containing details for the desired, new, and stale subscriptions
     */
    abstract streamHandler(context: EndpointContext<T>, subscriptions: SubscriptionDeltas<TypeFromDefinition<T['Parameters']>>): Promise<void>;
}
