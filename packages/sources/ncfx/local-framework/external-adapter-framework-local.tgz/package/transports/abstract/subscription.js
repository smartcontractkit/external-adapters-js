"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SubscriptionTransport = void 0;
const metrics_1 = require("../../metrics");
const util_1 = require("../../util");
const logger = (0, util_1.makeLogger)('SubscriptionTransport');
/**
 * Abstract Transport that will take incoming requests and add them to a subscription set as part
 * of the registration. Then it will provide those entries to the (abstract) backgroundHandler method.
 *
 * @typeParam T - all types related to the [[Transport]]
 */
class SubscriptionTransport {
    responseCache;
    subscriptionSet;
    subscriptionTtl;
    name;
    initialized = false;
    async initialize(dependencies, adapterSettings, endpointName, name) {
        if (this.initialized) {
            throw new Error(`Transport ${name} has already been initialized`);
        }
        this.initialized = true;
        this.responseCache = dependencies.responseCache;
        this.subscriptionSet = dependencies.subscriptionSetFactory.buildSet(endpointName, name);
        this.subscriptionTtl = this.getSubscriptionTtlFromConfig(adapterSettings); // Will be implemented by subclasses
        this.name = name;
    }
    async registerRequest(req, _) {
        (0, util_1.censorLogs)(() => logger.debug(`Adding entry to subscription set (ttl ${this.subscriptionTtl}): [${req.requestContext.cacheKey}] = ${req.requestContext.data}`));
        // This might need coalescing to avoid too frequent ttl updates
        await this.subscriptionSet.add(req.requestContext.data, this.subscriptionTtl, req.requestContext.cacheKey);
    }
    async backgroundExecute(context) {
        logger.debug('Starting background execute');
        const entries = await this.subscriptionSet.getAll();
        // Keep track of active subscriptions for background execute
        // Note: for those coming from reasonable OOP languages, don't fret; this is JS:
        // this.constructor.name will resolve to the instance name, not the class one (i.e., will use the implementing class' name)
        metrics_1.metrics
            .get('bgExecuteSubscriptionSetCount')
            .labels({
            adapter_endpoint: context.endpointName,
            transport_type: this.constructor.name,
            transport: this.name,
        })
            .set(entries.length);
        await this.backgroundHandler(context, entries);
    }
}
exports.SubscriptionTransport = SubscriptionTransport;
//# sourceMappingURL=subscription.js.map