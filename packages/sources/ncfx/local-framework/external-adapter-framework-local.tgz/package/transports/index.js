"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TransportRoutes = void 0;
const adapter_1 = require("../adapter");
__exportStar(require("./http"), exports);
__exportStar(require("./sse"), exports);
__exportStar(require("./websocket"), exports);
class TransportRoutes {
    map = {};
    register(name, transport) {
        // This is intentional, to keep names to one word only
        if (name !== adapter_1.DEFAULT_TRANSPORT_NAME && !/^[a-z]+$/.test(name)) {
            throw new Error(`Transport name "${name}" is invalid. Names in the AdapterEndpoint transports map can only include lowercase letters.`);
        }
        if (this.map[name]) {
            throw new Error(`Transport with name "${name}" is already registered in this map`);
        }
        this.map[name] = transport;
        return this;
    }
    get(name) {
        return this.map[name];
    }
    routeNames() {
        return Object.keys(this.map);
    }
    entries() {
        return Object.entries(this.map);
    }
}
exports.TransportRoutes = TransportRoutes;
//# sourceMappingURL=index.js.map