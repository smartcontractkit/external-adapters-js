"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CompositeTransport = void 0;
const compare_1 = require("../cache/response-cache/compare");
const util_1 = require("../util");
const logger = (0, util_1.makeLogger)('CompositeTransport');
// Send requests to multiple transports and merge responses into a single cache according to bigger providerIndicatedTimeUnixMs
class CompositeTransport {
    transports;
    name;
    responseCache;
    constructor(transports) {
        this.transports = transports;
    }
    async initialize(dependencies, adapterSettings, endpointName, transportName) {
        this.name = transportName;
        this.responseCache = dependencies.responseCache;
        const compareCache = new compare_1.CompareResponseCache(transportName, this.responseCache, (next, current) => 
        // Write if the incoming value has a newer provider timestamp
        // Also writes if the previous cache entry is stale/expired
        (next.timestamps?.providerIndicatedTimeUnixMs ?? 0) >
            (current?.timestamps?.providerIndicatedTimeUnixMs ?? 0));
        await Promise.all(Object.entries(this.transports).map(([name, transport]) => transport.initialize({ ...dependencies, responseCache: compareCache }, adapterSettings, endpointName, name)));
    }
    async registerRequest(req, adapterSettings) {
        const entries = Object.entries(this.transports);
        const results = await Promise.allSettled(entries.map(([, t]) => t.registerRequest?.(req, adapterSettings)));
        results.forEach((r, i) => {
            if (r.status === 'rejected') {
                logger.error(`Transport "${entries[i][0]}" registerRequest failed: ${r.reason}`);
            }
        });
    }
    async backgroundExecute(context) {
        const entries = Object.entries(this.transports);
        // Note that this will wait for the slowest transport to resolve before completing
        // this shared backgroundExecute loop and stalling the faster transport(s).
        // Consider setting lower timeouts on the individual transports if this becomes an issue.
        const results = await Promise.allSettled(entries.map(([, t]) => t.backgroundExecute?.(context)));
        results.forEach((r, i) => {
            if (r.status === 'rejected') {
                logger.error(`Transport "${entries[i][0]}" backgroundExecute failed: ${r.reason}`);
            }
        });
    }
}
exports.CompositeTransport = CompositeTransport;
//# sourceMappingURL=composite.js.map