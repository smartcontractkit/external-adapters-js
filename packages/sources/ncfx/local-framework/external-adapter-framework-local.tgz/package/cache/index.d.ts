import { EventEmitter } from 'events';
import { EndpointContext, EndpointGenerics } from '../adapter';
import { AdapterResponse } from '../util';
import { CacheTypes as CacheType } from './metrics';
export * from './factory';
export * from './local';
export * from './redis';
/**
 * An object describing an entry in the cache.
 * @typeParam T - the type of the entry's value
 */
export interface CacheEntry<T> {
    key: string;
    value: T;
}
/**
 * Generic interface for a local or remote Cache.
 * @typeParam T - the type of the cache entries' values
 */
export interface Cache<T = unknown> {
    type: CacheType;
    /**
     * Gets an item from the Cache.
     *
     * @param key - the key of the desired entry for which to fetch its value
     * @returns a Promise of the entry's value, or undefined if not found / expired.
     */
    get: (key: string) => Promise<Readonly<T> | undefined>;
    /**
     * Sets an item in the Cache.
     *
     * @param key - the key of the new entry
     * @param value - the value of the new entry
     * @param ttl - the time in milliseconds until the entry expires
     * @returns an empty Promise that resolves when the entry has been set
     */
    set: (key: string, value: Readonly<T>, ttl: number) => Promise<void>;
    /**
     * Sets a list of items in the Cache.
     *
     * @param entries - a list of cache entries
     * @param ttl - the time in milliseconds until the entries expire
     * @returns an empty Promise that resolves when all entries have been set
     */
    setMany: (entries: CacheEntry<Readonly<T>>[], ttl: number) => Promise<void>;
    /**
     * Deletes the specified item from the Cache.
     *
     * @param key - the key of the entry to be deleted
     * @returns an empty Promise that resolves when the entry has been deleted
     */
    delete: (key: string) => Promise<void>;
    /**
     * Updates the TTL value for an entry
     *
     * @param key - the key of the entry to be updated
     * @param ttl - a new time in milliseconds until the entry expires
     * @returns an empty Promise that resolves when the entry has been updated
     */
    setTTL: (key: string, ttl: number) => Promise<void>;
    /**
     * Sets a lock on the Cache.
     *
     * @param key - the key used to identify the lock, composed of the cache prefix (if set) and adapter name
     * @param cacheLockDuration - the time (in ms) used for the acquisition and extension of the lock
     * @param retryCount - the number of retries for acquiring the lock
     * @param shutdownNotifier - an EventEmitter that emits an event when the adapter is shutting down
     * @returns an empty Promise that resolves upon error or exiting the adapter
     */
    lock?: (key: string, cacheLockDuration: number, retryCount: number, shutdownNotifier: EventEmitter) => Promise<void>;
}
export declare const calculateCacheKey: <T extends EndpointGenerics>({ data, adapterName, endpointName, adapterSettings, transportName, }: {
    data: Record<string, unknown>;
    adapterName: string;
    endpointName: string;
    adapterSettings: T["Settings"];
    transportName: string;
}) => string;
export declare const calculateHttpRequestKey: <T extends EndpointGenerics>({ data, context, transportName, }: {
    context: EndpointContext<T>;
    data: Record<string, unknown> | Record<string, unknown>[];
    transportName: string;
}) => string;
export declare const calculateAdapterName: (adapterName: string, data: Record<string, unknown>) => string;
export declare const calculateFeedId: <T extends EndpointGenerics>({ adapterSettings, }: {
    adapterSettings: T["Settings"];
}, data: Record<string, unknown>) => string;
/**
 * Polls the provided Cache for an AdapterResponse set in the provided key. If the maximum
 * amount of retries is exceeded, it returns undefined instead.
 *
 * @param cache - a Cache instance
 * @param key - the key generated from an AdapterRequest that corresponds to the desired AdapterResponse
 * @param retry - current retry, only for internal use
 * @returns the AdapterResponse if found, else undefined
 */
export declare const pollResponseFromCache: (cache: Cache<AdapterResponse>, key: string, options: {
    maxRetries: number;
    sleep: number;
}, retry?: number) => Promise<AdapterResponse | undefined>;
