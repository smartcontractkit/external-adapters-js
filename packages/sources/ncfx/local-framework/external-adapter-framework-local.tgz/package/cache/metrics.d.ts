export interface CacheMetricsLabels {
    participant_id: string;
    feed_id: string;
    cache_type: string;
}
export declare const cacheGet: (label: CacheMetricsLabels, value: unknown, staleness: {
    cache: number;
    total: number | null;
}) => void;
export declare const cacheSet: (label: CacheMetricsLabels, maxAge: number, timeDelta: number | undefined) => void;
export declare const cacheMetricsLabel: (cacheKey: string, feedId: string, cacheType: string) => {
    participant_id: string;
    feed_id: string;
    cache_type: string;
};
export declare enum CacheTypes {
    Redis = "redis",
    Local = "local"
}
