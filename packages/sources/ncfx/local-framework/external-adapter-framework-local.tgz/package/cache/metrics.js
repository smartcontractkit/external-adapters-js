"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CacheTypes = exports.cacheMetricsLabel = exports.cacheSet = exports.cacheGet = void 0;
const metrics_1 = require("../metrics");
const cacheGet = (label, value, staleness) => {
    if (typeof value === 'number' || typeof value === 'string') {
        const parsedValue = Number(value);
        if (!Number.isNaN(parsedValue) && Number.isFinite(parsedValue)) {
            metrics_1.metrics.get('cacheDataGetValues').labels(label).set(parsedValue);
        }
    }
    metrics_1.metrics.get('cacheDataGetCount').labels(label).inc();
    metrics_1.metrics.get('cacheDataStalenessSeconds').labels(label).set(staleness.cache);
    if (staleness.total) {
        metrics_1.metrics.get('totalDataStalenessSeconds').labels(label).set(staleness.total);
    }
};
exports.cacheGet = cacheGet;
const cacheSet = (label, maxAge, timeDelta) => {
    metrics_1.metrics.get('cacheDataSetCount').labels(label).inc();
    metrics_1.metrics.get('cacheDataMaxAge').labels(label).set(maxAge);
    metrics_1.metrics.get('cacheDataStalenessSeconds').labels(label).set(0);
    if (timeDelta) {
        metrics_1.metrics.get('providerTimeDelta').labels({ feed_id: label.feed_id }).set(timeDelta);
    }
};
exports.cacheSet = cacheSet;
const cacheMetricsLabel = (cacheKey, feedId, cacheType) => ({
    participant_id: cacheKey,
    feed_id: feedId,
    cache_type: cacheType,
});
exports.cacheMetricsLabel = cacheMetricsLabel;
var CacheTypes;
(function (CacheTypes) {
    CacheTypes["Redis"] = "redis";
    CacheTypes["Local"] = "local";
})(CacheTypes || (exports.CacheTypes = CacheTypes = {}));
//# sourceMappingURL=metrics.js.map