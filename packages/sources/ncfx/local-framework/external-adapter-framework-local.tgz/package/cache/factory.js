"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CacheFactory = void 0;
const util_1 = require("../util");
const local_1 = require("./local");
const redis_1 = require("./redis");
const logger = (0, util_1.makeLogger)('CacheFactory');
class CacheFactory {
    static buildCache({ cacheType, maxSizeForLocalCache }, redisClient) {
        logger.info(`Using "${cacheType}" cache.`);
        switch (cacheType) {
            case 'local':
                return new local_1.LocalCache(maxSizeForLocalCache);
            case 'redis': {
                if (!redisClient) {
                    throw new Error('Redis client undefined. Cannot create Redis cache');
                }
                return new redis_1.RedisCache(redisClient, maxSizeForLocalCache);
            }
        }
    }
}
exports.CacheFactory = CacheFactory;
//# sourceMappingURL=factory.js.map