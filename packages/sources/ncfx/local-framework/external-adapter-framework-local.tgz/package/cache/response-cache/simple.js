"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.SimpleResponseCache = void 0;
const base_1 = require("./base");
const cacheMetrics = __importStar(require("../metrics"));
/**
 * Special type of cache to store responses for this adapter.
 */
class SimpleResponseCache extends base_1.ResponseCache {
    async writeEntries(entries) {
        const ttl = this.adapterSettings.CACHE_MAX_AGE;
        await this.cache.setMany(entries, ttl);
        // Fan the entries out to any gRPC streaming subscribers. Undefined unless this instance serves
        // gRPC, and publishing neither throws nor blocks.
        this.dependencies.observationBus?.publish(entries);
        const now = Date.now();
        for (const { key, value } of entries) {
            // Only record metrics if feed Id is present, otherwise assuming value is not adapter response to record
            const response = value;
            const feedId = response.meta?.metrics?.feedId;
            if (feedId) {
                const providerTime = response.timestamps?.providerIndicatedTimeUnixMs;
                const timeDelta = providerTime ? now - providerTime : undefined;
                // Record cache set count, max age, and staleness (set to 0 for cache set)
                const label = cacheMetrics.cacheMetricsLabel(key, feedId, this.cache.type);
                cacheMetrics.cacheSet(label, ttl, timeDelta);
            }
        }
        return;
    }
    async write(transportName, results) {
        const entries = results.map((r) => this.generateCacheEntry(transportName, transportName, r));
        await this.writeEntries(entries);
    }
}
exports.SimpleResponseCache = SimpleResponseCache;
//# sourceMappingURL=simple.js.map