import { ResponseCache } from './base';
import { AdapterResponse, ResponseGenerics, TimestampedProviderResult } from '../../util';
import { InputParametersDefinition } from '../../validation/input-params';
/**
 * Special type of cache to store responses for this adapter.
 */
export declare class SimpleResponseCache<T extends {
    Parameters: InputParametersDefinition;
    Response: ResponseGenerics;
}> extends ResponseCache<T> {
    writeEntries(entries: {
        key: string;
        value: AdapterResponse<T['Response']>;
    }[]): Promise<void>;
    write(transportName: string, results: TimestampedProviderResult<T>[]): Promise<void>;
}
