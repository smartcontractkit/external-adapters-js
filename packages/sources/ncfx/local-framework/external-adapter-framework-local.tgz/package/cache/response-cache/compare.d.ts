import { ResponseCache } from './base';
import { AdapterResponse, ResponseGenerics, TimestampedProviderResult } from '../../util';
import { InputParametersDefinition, TypeFromDefinition } from '../../validation/input-params';
/**
 * Compares with existing cache entries before deciding to write or not
 */
export declare class CompareResponseCache<T extends {
    Parameters: InputParametersDefinition;
    Response: ResponseGenerics;
}> extends ResponseCache<T> {
    readonly transportName: string;
    responseCache: ResponseCache<T>;
    shouldUpdate: (next: AdapterResponse<T['Response']>, current?: AdapterResponse<T['Response']>) => boolean;
    constructor(transportName: string, responseCache: ResponseCache<T>, shouldUpdate: (next: AdapterResponse<T['Response']>, current?: AdapterResponse<T['Response']>) => boolean);
    write(transportName: string, results: TimestampedProviderResult<T>[]): Promise<void>;
    writeEntries(entries: {
        key: string;
        value: AdapterResponse<T['Response']>;
    }[]): Promise<void>;
    writeTTL(_: string, params: TypeFromDefinition<T['Parameters']>[], ttl: number): Promise<void>;
    get(key: string): Promise<Readonly<AdapterResponse<T["Response"]>> | undefined>;
}
