"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CompareResponseCache = void 0;
const base_1 = require("./base");
/**
 * Compares with existing cache entries before deciding to write or not
 */
class CompareResponseCache extends base_1.ResponseCache {
    transportName;
    // The actual cache where responses are written to
    responseCache;
    // True if next should replace current in cache
    shouldUpdate;
    constructor(transportName, responseCache, shouldUpdate) {
        super({
            inputParameters: responseCache.inputParameters,
            adapterName: responseCache.adapterName,
            endpointName: responseCache.endpointName,
            adapterSettings: responseCache.adapterSettings,
            dependencies: responseCache.dependencies,
        });
        this.transportName = transportName;
        this.responseCache = responseCache;
        this.shouldUpdate = shouldUpdate;
    }
    async write(transportName, results) {
        await this.writeEntries(results.map((result) => this.generateCacheEntry(transportName, this.transportName, result)));
    }
    async writeEntries(entries) {
        const filteredEntries = (await Promise.all(entries.flatMap(async ({ key, value }) => {
            const current = await this.get(key);
            if (!this.shouldUpdate(value, current)) {
                return [];
            }
            return [{ key, value }];
        }))).flat();
        if (filteredEntries.length > 0) {
            await this.responseCache.writeEntries(filteredEntries);
        }
    }
    async writeTTL(_, params, ttl) {
        await this.responseCache.writeTTL(this.transportName, params, ttl);
    }
    async get(key) {
        return this.responseCache.get(key);
    }
}
exports.CompareResponseCache = CompareResponseCache;
//# sourceMappingURL=compare.js.map