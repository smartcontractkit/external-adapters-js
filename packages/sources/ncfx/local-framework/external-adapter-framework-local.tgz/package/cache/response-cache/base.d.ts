import { AdapterDependencies } from '../../adapter';
import { AdapterSettings } from '../../config';
import { AdapterResponse, ResponseGenerics, TimestampedProviderResult } from '../../util';
import { InputParameters, InputParametersDefinition, TypeFromDefinition } from '../../validation/input-params';
import { Cache } from '../';
export declare abstract class ResponseCache<T extends {
    Parameters: InputParametersDefinition;
    Response: ResponseGenerics;
}> {
    cache: Cache<AdapterResponse<T['Response']>>;
    inputParameters: InputParameters<T['Parameters']>;
    adapterName: string;
    endpointName: string;
    adapterSettings: AdapterSettings;
    dependencies: AdapterDependencies;
    constructor({ inputParameters, adapterName, endpointName, adapterSettings, dependencies, }: {
        dependencies: AdapterDependencies;
        adapterSettings: AdapterSettings;
        adapterName: string;
        endpointName: string;
        inputParameters: InputParameters<T['Parameters']>;
    });
    /**
     * Sets responses in the adapter cache (adding necessary metadata and defaults)
     *
     * @param transportName - transport name
     * @param results - the entries to write to the cache
     */
    abstract write(transportName: string, results: TimestampedProviderResult<T>[]): Promise<void>;
    /**
     * Sets responses with metadata in the adapter cache
     *
     * @param entries - the entries to write to the cache
     */
    abstract writeEntries(entries: {
        key: string;
        value: AdapterResponse<T['Response']>;
    }[]): Promise<void>;
    /**
     * Sets a new TTL value for already cached responses in the adapter cache
     *
     * @param transportName - transport name
     * @param params - set of parameters that uniquely relate to the response
     * @param ttl - a new time in milliseconds until the response expires
     */
    writeTTL(transportName: string, params: TypeFromDefinition<T['Parameters']>[], ttl: number): Promise<void>;
    get(key: string): Promise<Readonly<AdapterResponse<T["Response"]>> | undefined>;
    protected generateCacheEntry(transportNameForMeta: string, transportNameForCache: string, r: TimestampedProviderResult<T>): {
        readonly key: string;
        readonly value: AdapterResponse<T["Response"]>;
    };
    getCacheKey(transportName: string, params: TypeFromDefinition<T['Parameters']>): string;
}
