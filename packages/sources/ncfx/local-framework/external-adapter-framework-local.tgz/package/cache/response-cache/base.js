"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ResponseCache = void 0;
const util_1 = require("../../util");
const __1 = require("../");
const censor_list_1 = __importDefault(require("../../util/censor/censor-list"));
const utils_1 = require("../../validation/utils");
const logger = (0, util_1.makeLogger)('ResponseCache');
class ResponseCache {
    cache;
    inputParameters;
    adapterName;
    endpointName;
    adapterSettings;
    dependencies;
    constructor({ inputParameters, adapterName, endpointName, adapterSettings, dependencies, }) {
        this.dependencies = dependencies;
        this.cache = dependencies.cache;
        this.inputParameters = inputParameters;
        this.adapterName = adapterName;
        this.endpointName = endpointName;
        this.adapterSettings = adapterSettings;
    }
    /**
     * Sets a new TTL value for already cached responses in the adapter cache
     *
     * @param transportName - transport name
     * @param params - set of parameters that uniquely relate to the response
     * @param ttl - a new time in milliseconds until the response expires
     */
    async writeTTL(transportName, params, ttl) {
        for (const param of params) {
            const key = this.getCacheKey(transportName, param);
            this.cache.setTTL(key, ttl);
        }
    }
    async get(key) {
        return this.cache.get(key);
    }
    generateCacheEntry(transportNameForMeta, transportNameForCache, r) {
        const censorList = censor_list_1.default.getAll();
        const { data, result, errorMessage } = r.response;
        if (!errorMessage && data === undefined) {
            logger.warn('The "data" property of the response is undefined.');
        }
        else if (!errorMessage && result === undefined) {
            logger.warn('The "result" property of the response is undefined.');
        }
        let censoredResponse;
        if (!censorList.length) {
            censoredResponse = r.response;
        }
        else {
            try {
                censoredResponse = (0, util_1.censor)(r.response, censorList, true);
            }
            catch (error) {
                (0, util_1.censorLogs)(() => logger.error(`Error censoring response: ${error}`));
                censoredResponse = {
                    statusCode: 502,
                    errorMessage: 'Response could not be censored due to an error',
                    timestamps: r.response.timestamps,
                };
            }
        }
        const response = {
            ...censoredResponse,
            statusCode: censoredResponse.statusCode || 200,
        };
        if (this.adapterSettings.METRICS_ENABLED && this.adapterSettings.EXPERIMENTAL_METRICS_ENABLED) {
            response.meta = {
                adapterName: (0, __1.calculateAdapterName)(this.adapterName, r.params),
                transportName: transportNameForMeta,
                metrics: {
                    feedId: (0, __1.calculateFeedId)({
                        adapterSettings: this.adapterSettings,
                    }, r.params),
                },
            };
        }
        if (response.timestamps?.providerIndicatedTimeUnixMs !== undefined) {
            const timestampValidator = utils_1.validator.responseTimestamp();
            const error = timestampValidator.fn(response.timestamps?.providerIndicatedTimeUnixMs);
            if (error) {
                (0, util_1.censorLogs)(() => logger.warn(`Provider indicated time is invalid: ${error}`));
            }
        }
        return {
            key: this.getCacheKey(transportNameForCache, r.params),
            value: response,
        };
    }
    getCacheKey(transportName, params) {
        return (0, __1.calculateCacheKey)({
            transportName,
            data: params,
            adapterName: this.adapterName,
            endpointName: this.endpointName,
            adapterSettings: this.adapterSettings,
        });
    }
}
exports.ResponseCache = ResponseCache;
//# sourceMappingURL=base.js.map