import EventEmitter from 'events';
import Redis, { Result } from 'ioredis';
import { Cache, CacheEntry } from './index';
import { CacheTypes } from './metrics';
declare module 'ioredis' {
    interface RedisCommander<Context> {
        setExternalAdapterResponse(key: string, value: string, ttl: number): Result<string, Context>;
    }
}
/**
 * Redis implementation of a Cache. It uses a simple js Object, storing entries with both
 * a value and an expiration timestamp. Expired entries are deleted on reads (i.e. no background gc/upkeep).
 *
 * @typeParam T - the type for the entries' values
 */
export declare class RedisCache<T = unknown> implements Cache<T> {
    private client;
    type: CacheTypes;
    private localCache;
    constructor(client: Redis, localCacheCapacity: number);
    defineCommands(): void;
    get(key: string): Promise<Readonly<T> | undefined>;
    delete(key: string): Promise<void>;
    set(key: string, value: Readonly<T>, ttl: number): Promise<void>;
    setMany(entries: CacheEntry<Readonly<T>>[], ttl: number): Promise<void>;
    setTTL(key: string, ttl: number): Promise<void>;
    lock(key: string, cacheLockDuration: number, retryCount: number, shutdownNotifier: EventEmitter): Promise<void>;
}
