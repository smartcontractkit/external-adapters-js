import Redis from 'ioredis';
import { LocalCache } from './local';
import { RedisCache } from './redis';
export declare class CacheFactory {
    static buildCache({ cacheType, maxSizeForLocalCache }: {
        cacheType: string;
        maxSizeForLocalCache: number;
    }, redisClient?: Redis): LocalCache<unknown> | RedisCache<unknown> | undefined;
}
