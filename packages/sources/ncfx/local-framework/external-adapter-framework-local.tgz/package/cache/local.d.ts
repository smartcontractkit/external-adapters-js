import { DoubleLinkedList, LinkedListNode } from '../util';
import { Cache, CacheEntry } from './index';
import { CacheTypes } from './metrics';
/**
 * Type for a value stored in a LocalCache entry.
 *
 * @typeParam T - the type for the entry's value
 */
export interface LocalCacheEntry<T> {
    expirationTimestamp: number;
    value: T;
}
/**
 * Local implementation of a Cache. It uses a DoubleLinkedList class for storing cache nodes.
 * Each LinkedListNode is storing entries with both value and an expiration timestamp.
 * Expired entries are deleted on reads (i.e. no background gc/upkeep).
 * @typeParam T - the type for the entries' values
 */
export declare class LocalCache<T = unknown> implements Cache<T> {
    type: CacheTypes;
    capacity: number;
    cache: Map<string, LinkedListNode<LocalCacheEntry<T>>>;
    list: DoubleLinkedList;
    constructor(capacity: number);
    get(key: string): Promise<Readonly<T> | undefined>;
    delete(key: string): Promise<void>;
    set(key: string, value: Readonly<T>, ttl: number): Promise<void>;
    setMany(entries: CacheEntry<Readonly<T>>[], ttl: number): Promise<void>;
    setTTL(key: string, ttl: number): Promise<void>;
    private evictIfNeeded;
    private moveToTail;
}
