export type Turn = {
    release: () => void;
};
export declare class EvictedError extends Error {
    constructor(message: string);
}
declare class TurnNode {
    private queue;
    isDone: boolean;
    _next: TurnNode | undefined;
    starting: Promise<Turn | undefined>;
    resolveStarting: (turn: Turn | undefined) => void;
    constructor(queue: TurnQueue);
    start(): void;
    drop(): void;
    get next(): TurnNode | undefined;
    set next(value: TurnNode | undefined);
    private end;
    private maybeStartNext;
}
export declare class TurnQueue {
    private maxLength;
    length: number;
    active: TurnNode;
    last: TurnNode;
    constructor(maxLength: number);
    runInTurn(task: () => Promise<void>): Promise<void>;
    private takeTurn;
    startNext(): void;
}
export {};
