export * from './logger';
export * from './subscription-set/subscription-set';
export * from './types';
/**
 * Sleeps for the provided number of milliseconds
 * @param ms - The number of milliseconds to sleep for
 * @returns a Promise that resolves once the specified time passes
 */
export declare const sleep: (ms: number) => Promise<void>;
export type PromiseOrValue<T> = Promise<T> | T;
export declare class LinkedListNode<T = unknown> {
    data: T;
    next: LinkedListNode | null;
    prev: LinkedListNode | null;
    key: string;
    constructor(key: string, data: T);
}
export declare class DoubleLinkedList {
    head: LinkedListNode | null;
    tail: LinkedListNode | null;
    size: number;
    constructor();
    insertAtTail(node: LinkedListNode): LinkedListNode<unknown>;
    remove(node: LinkedListNode | null): LinkedListNode | undefined;
    removeHead(): LinkedListNode | undefined;
}
/**
 * Waits for the provided promise to finish up to a specified amount of time, at which point
 * an error is thrown if the promise hasn't finished yet. Note that this cannot abort the execution
 * of the provided promise, as the underlying node structure cannot cancel the thread.
 *
 * @param promise - the promise to wait for
 * @param timeout - the maximum amount of time to wait for the promise to finish
 * @returns the result of the promise
 */
export declare const timeoutPromise: <T>(label: string, promise: Promise<T>, timeout: number) => Promise<T>;
type DeferredResolve<T> = (value: T | PromiseLike<T>) => void;
type DeferredReject = (reason?: unknown) => void;
/**
 * This function will create a promise, and synchronously return both the promise itself and
 * the resolve and reject callbacks so that they can be used and passed around individually.
 *
 * @returns all the deconstructed elements of a promise, to handle in synchronous-ish logic
 */
export declare const deferredPromise: <T>() => [Promise<T>, DeferredResolve<T>, DeferredReject];
/**
 * Checks if the provided array includes any duplicates
 *
 * @param array - any array to check
 * @returns whether the array has duplicate items
 */
export declare const hasRepeatedValues: (array: string[]) => boolean;
/**
 * Splits an array into smaller arrays of a specified size.
 *
 * @param array - any array to be chunked
 * @param size - the maximum size of each chunk
 * @returns an array of arrays, each of which contains up to `size` elements
 */
export declare const splitArrayIntoChunks: <T>(array: T[], size: number) => T[][];
/**
 * Groups an array of objects by a specified key
 * @param  array - The array of objects to group
 * @param  key - The name of the key to group by
 * @returns An object where the keys are the unique values of the specified key
 * and the values are array of items with that key
 */
export declare const groupArrayByKey: <T extends Record<string, string>, K extends keyof T>(array: T[], key: K) => Record<T[K], T[]>;
/**
 * Returns adapter name in lower case and with hyphens replaced by underscores.
 * Types are declared such that the output type is defined iff the input type
 * is defined.
 * @param  name - The name to canonicalize
 * @returns The canonical name
 */
export declare function getCanonicalAdapterName(name: string): string;
export declare function getCanonicalAdapterName(name: undefined): undefined;
type StringKeys<T> = {
    [key: string]: T;
};
/**
 * Returns the record with adapter names as keys after canonicalizing the keys.
 * @param  obj - The record with adapter names as keys
 * @returns The record with canonicalized adapter names as keys
 */
export declare const canonicalizeAdapterNameKeys: <T>(obj: StringKeys<T> | undefined) => StringKeys<T> | undefined;
