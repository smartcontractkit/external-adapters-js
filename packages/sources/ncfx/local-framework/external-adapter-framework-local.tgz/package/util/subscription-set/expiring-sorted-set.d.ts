import { SubscriptionSet } from './subscription-set';
import { DoubleLinkedList, LinkedListNode, PromiseOrValue } from '..';
/**
 * An object describing an entry in the expiring sorted set.
 * @typeParam T - the type of the entry's value
 */
interface ExpiringSortedSetEntry<T> {
    value: T;
    expirationTimestamp: number;
}
/**
 * This class implements a set of unique items, each of which has an expiration timestamp.
 * On reads, items that have expired will be deleted from the set and not returned.
 *
 * @typeParam T - the type of the set entries' values
 */
export declare class ExpiringSortedSet<T> implements SubscriptionSet<T> {
    capacity: number;
    map: Map<string, LinkedListNode<ExpiringSortedSetEntry<T>>>;
    list: DoubleLinkedList;
    constructor(capacity: number);
    add(value: T, ttl: number, key: string): void;
    getAll(): PromiseOrValue<T[]>;
    get(key: string): T | undefined;
    delete(key: string): void;
    private moveToTail;
    private evictIfNeeded;
}
export {};
