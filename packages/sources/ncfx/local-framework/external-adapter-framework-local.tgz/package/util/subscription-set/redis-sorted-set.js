"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RedisSubscriptionSet = void 0;
const metrics_1 = require("../../metrics");
class RedisSubscriptionSet {
    redisClient;
    // Key for Redis sorted set containing all subscriptions
    subscriptionSetKey;
    constructor(redisClient, subscriptionSetKey) {
        this.redisClient = redisClient;
        this.subscriptionSetKey = subscriptionSetKey;
    }
    async add(value, ttl) {
        const storedValue = JSON.stringify(value);
        await this.redisClient.zadd(this.subscriptionSetKey, Date.now() + ttl, storedValue);
        (0, metrics_1.recordRedisCommandMetric)(metrics_1.CMD_SENT_STATUS.SUCCESS, 'zadd');
        return;
    }
    async getAll() {
        // Remove expired keys from sorted set
        await this.redisClient.zremrangebyscore(this.subscriptionSetKey, '-inf', Date.now());
        (0, metrics_1.recordRedisCommandMetric)(metrics_1.CMD_SENT_STATUS.SUCCESS, 'zremrangebyscore');
        const parsedRequests = [];
        const validEntries = await this.redisClient.zrange(this.subscriptionSetKey, 0, -1);
        (0, metrics_1.recordRedisCommandMetric)(metrics_1.CMD_SENT_STATUS.SUCCESS, 'zrange');
        validEntries.forEach((entry) => {
            // Separate request and cache key prior to populating results array
            parsedRequests.push(JSON.parse(entry));
        });
        return parsedRequests;
    }
    get() {
        return undefined;
    }
}
exports.RedisSubscriptionSet = RedisSubscriptionSet;
//# sourceMappingURL=redis-sorted-set.js.map