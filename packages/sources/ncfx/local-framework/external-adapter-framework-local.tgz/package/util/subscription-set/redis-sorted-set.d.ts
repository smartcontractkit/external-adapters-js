import Redis from 'ioredis';
import { SubscriptionSet } from './subscription-set';
export declare class RedisSubscriptionSet<T> implements SubscriptionSet<T> {
    private redisClient;
    private subscriptionSetKey;
    constructor(redisClient: Redis, subscriptionSetKey: string);
    add(value: T, ttl: number): Promise<undefined>;
    getAll(): Promise<T[]>;
    get(): T | undefined;
}
