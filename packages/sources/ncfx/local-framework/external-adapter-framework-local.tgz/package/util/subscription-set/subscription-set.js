"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SubscriptionSetFactory = void 0;
const expiring_sorted_set_1 = require("./expiring-sorted-set");
const redis_sorted_set_1 = require("./redis-sorted-set");
class SubscriptionSetFactory {
    cacheType;
    redisClient;
    adapterName;
    capacity;
    cachePrefix;
    constructor(adapterSettings, adapterName, redisClient) {
        this.cacheType = adapterSettings.CACHE_TYPE;
        this.redisClient = redisClient;
        this.adapterName = adapterName;
        this.capacity = adapterSettings.SUBSCRIPTION_SET_MAX_ITEMS;
        this.cachePrefix = adapterSettings.CACHE_PREFIX;
    }
    buildSet(endpointName, transportName) {
        switch (this.cacheType) {
            case 'local':
                return new expiring_sorted_set_1.ExpiringSortedSet(this.capacity);
            case 'redis': {
                if (!this.redisClient) {
                    throw new Error('Redis client undefined. Cannot create Redis subscription set');
                }
                // Identifier key used for the subscription set in redis
                const cachePrefix = this.cachePrefix ? `${this.cachePrefix}-` : '';
                const subscriptionSetKey = `${cachePrefix}${this.adapterName}-${endpointName}-${transportName}-subscriptionSet`;
                return new redis_sorted_set_1.RedisSubscriptionSet(this.redisClient, subscriptionSetKey);
            }
        }
    }
}
exports.SubscriptionSetFactory = SubscriptionSetFactory;
//# sourceMappingURL=subscription-set.js.map