type Callback<T> = () => Promise<T>;
type Resolve<T> = (arg: T | Promise<T>) => void;
export declare class GroupRunner {
    private groupSize;
    private currentGroup;
    private previousStartRunning;
    constructor(groupSize: number);
    run<T>(callback: Callback<T>): Promise<T>;
    startRunning<T>(callback: Callback<T>, resolve: Resolve<T>): Promise<void>;
    wrapFunction<Args extends unknown[], Return>(func: (...args: Args) => Promise<Return>): (...args: Args) => Promise<Return>;
}
export {};
