"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildSettingsList = void 0;
const config_1 = require("../config");
const index_1 = require("./index");
const censor_list_1 = __importDefault(require("./censor/censor-list"));
/**
 * Builds a list of adapter settings with sensitive values censored
 * Used by both debug settings page and status endpoint
 */
const buildSettingsList = (adapter) => {
    // Censor EA settings
    const settings = adapter.config.settings;
    const censoredValues = censor_list_1.default.getAll();
    const censoredSettings = [];
    const settingsEntries = Object.entries(settings).flatMap(([settingName, settingValue]) => {
        const getter = settingValue;
        if (getter instanceof config_1.EnvGetter) {
            return getter.entries().map(({ envVarName, value }) => ({ settingName, envVarName, value }));
        }
        return [{ settingName, envVarName: settingName, value: settingValue }];
    });
    for (const { settingName, envVarName, value } of settingsEntries) {
        const definitionDetails = adapter.config.getSettingDebugDetails(settingName);
        censoredSettings.push({
            name: envVarName,
            ...definitionDetails,
            value: (0, index_1.censor)(value, censoredValues),
        });
    }
    return censoredSettings.sort((a, b) => a.name.localeCompare(b.name));
};
exports.buildSettingsList = buildSettingsList;
//# sourceMappingURL=settings.js.map