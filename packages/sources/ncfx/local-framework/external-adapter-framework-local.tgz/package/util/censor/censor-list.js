"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class CensorList {
    static censorList = [];
    static getAll() {
        return this.censorList;
    }
    static set(censorList) {
        this.censorList = censorList;
    }
}
exports.default = CensorList;
//# sourceMappingURL=censor-list.js.map