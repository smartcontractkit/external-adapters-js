export default class CensorList {
    static censorList: CensorKeyValue[];
    static getAll(): CensorKeyValue[];
    static set(censorList: CensorKeyValue[]): void;
}
export interface CensorKeyValue {
    key: string;
    value: RegExp;
}
