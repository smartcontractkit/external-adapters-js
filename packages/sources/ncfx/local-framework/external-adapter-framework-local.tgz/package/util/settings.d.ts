import { Adapter } from '../adapter';
import { SettingsDefinitionMap, SettingDefinitionDetails } from '../config';
export type DebugPageSetting = SettingDefinitionDetails & {
    name: string;
    value: unknown;
};
/**
 * Builds a list of adapter settings with sensitive values censored
 * Used by both debug settings page and status endpoint
 */
export declare const buildSettingsList: <T extends SettingsDefinitionMap>(adapter: Adapter<T>) => DebugPageSetting[];
