import { AxiosRequestConfig, AxiosResponse } from 'axios';
import { AdapterSettings } from '../config';
import { RateLimiter } from '../rate-limiting';
interface RequesterResult<T> {
    response: AxiosResponse<T>;
    timestamps: {
        providerDataRequestedUnixMs: number;
        providerDataReceivedUnixMs: number;
    };
}
/**
 * Centralized management of outbound http requests.
 * Enforces rate limiting on a single instance (complying with the N Readers - 1 Writer arch for EA scaling)
 * by adding requests into a queue, processing them sequentially and sleeping when it reaches its limit.
 * The queue will throw an error if the Requester attempts to add more items than the max configured.
 * It additionally serves to coalesce requests by utilizing a more complex queue structure:
 *   - ignores duplicate items via a provided key
 *   - doesn't use the request itself because it's common for those to have things like timestamps/nonces
 * This implementation does not:
 *   - Prioritize any request over another
 *   - Contemplate architectures with multiple writer EA instances
 */
export declare class Requester {
    private rateLimiter;
    private queue;
    private pendingRequestMap;
    private maxRetries;
    private timeout;
    private sleepBeforeRequeueingMs;
    constructor(rateLimiter: RateLimiter, adapterSettings: AdapterSettings);
    /**
     * Queues the provided request, and returns a promise that will resolve whenever it's executed.
     *
     * @param key - a key to uniquely identify this request, and coalesce new ones that match
     * @param req - a request to send to a data provider
     * @param cost - Data Provider API credit cost of the request
     * @returns a promise that will resolve whenever the request is popped from the queue, sent, and a response is received
     */
    request<T>(key: string, req: AxiosRequestConfig, cost?: number): Promise<RequesterResult<T>>;
    private executeRequestWithRetries;
    private waitBeforeExecutingRequest;
    private executeRequest;
}
export {};
