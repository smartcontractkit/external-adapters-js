import { FastifyReply, FastifyRequest, HookHandlerDoneFunction } from 'fastify';
import { AsyncLocalStorage } from 'node:async_hooks';
import pino from 'pino';
import { CensorKeyValue } from './censor/censor-list';
export declare const asyncLocalStorage: AsyncLocalStorage<unknown>;
export type Store = {
    correlationId: string;
};
export declare const COLORS: string[];
export declare const colorFactory: (colors: string[]) => () => string;
/**
 * Object that will provide logger instances upon requests, based on the basic pino logger.
 */
export interface LoggerFactory {
    child(params: {
        layer: string;
        color?: string;
    }): Omit<pino.BaseLogger, 'level' | 'silent'>;
}
/**
 * Global class that will hold the logger factory.
 * This is easier than refactoring the entire framework to use a dependency injection framework,
 * and probably safer since all the popular ones use decorators that are still in the experimental stage.
 */
export declare class LoggerFactoryProvider {
    private static factory;
    static set(factory?: LoggerFactory): void;
    static get(): LoggerFactory;
}
/**
 * Instance of a logger, that will defer the construction of its methods until the first time any of them are called.
 * This is done so we can freely create these instances before the adapter is initialized, and allow
 * the global logger factory to be injected if the user so desires.
 */
declare class PlaceholderLogger {
    private levels;
    constructor(layer: string);
    fatal: pino.LogFn;
    error: pino.LogFn;
    warn: pino.LogFn;
    info: pino.LogFn;
    debug: pino.LogFn;
    trace: pino.LogFn;
}
/**
 * Instead of using a global logger instance, we want to force using a child logger
 * with a specific layer set in it, so that we can filter logs by where they're output from.
 *
 * Details on what each log level represents:
 * "trace": Forensic debugging of issues on a local machine.
 * "debug": Detailed logging level to get more context from users on their environments.
 * "info": High-level informational messages, to describe at a glance the high level state of the system.
 * "warn": A mild error occurred that might require non-urgent action.
 * "error": An unexpected error occurred during the regular operation of a well-maintained EA.
 * "fatal": The EA encountered an unrecoverable problem and had to exit.
 *
 * Full reference this is based on can be found at
 * https://github.com/smartcontractkit/documentation/blob/main/docs/Node%20Operators/configuration-variables.md#log_level
 *
 * @param layer - the layer name to include in the logs (e.g. "SomeMiddleware", "RedisCache", etc.)
 * @returns a layer specific logger
 */
export declare const makeLogger: (layer: string) => PlaceholderLogger;
export declare const loggingContextMiddleware: (rawReq: FastifyRequest, res: FastifyReply, done: HookHandlerDoneFunction) => void;
export declare function censor(obj: any, censorList: CensorKeyValue[], throwOnError?: boolean): any;
export declare const censorLogs: (logFunc: () => void) => void;
export {};
