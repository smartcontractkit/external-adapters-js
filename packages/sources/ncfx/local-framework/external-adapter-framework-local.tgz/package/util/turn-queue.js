"use strict";
// TurnQueue is used by Requester to make sure requests execute in turn and to
// limit the number of pending requests.
//
// Before a request is made the requester waits for the rate limiter inside a
// call to run() on the TurnQueue. This callback is only run when the previous
// request finished waiting for its rate limit.
//
// If the maximum number of pending turns is exceeded, the oldest pending turn
// is dropped and its callback is never run. Instead the call to run() throws
// an EvictedError.
Object.defineProperty(exports, "__esModule", { value: true });
exports.TurnQueue = exports.EvictedError = void 0;
class EvictedError extends Error {
    constructor(message) {
        super(message);
        this.name = 'EvictedError';
    }
}
exports.EvictedError = EvictedError;
class TurnNode {
    queue;
    isDone = false;
    _next = undefined;
    starting;
    resolveStarting;
    constructor(queue) {
        this.queue = queue;
        this.starting = new Promise((resolve) => {
            this.resolveStarting = resolve;
        });
    }
    start() {
        this.resolveStarting({
            release: () => this.end(),
        });
    }
    drop() {
        this.resolveStarting(undefined);
    }
    get next() {
        return this._next;
    }
    set next(value) {
        this._next = value;
        this.maybeStartNext();
    }
    end() {
        if (this.isDone) {
            throw new Error('Turn already ended');
        }
        this.isDone = true;
        this.maybeStartNext();
    }
    maybeStartNext() {
        if (this.isDone && this.next) {
            this.queue.startNext();
        }
    }
}
class TurnQueue {
    maxLength;
    length = 0;
    active;
    last;
    constructor(maxLength) {
        this.maxLength = maxLength;
        const ready = new TurnNode(this);
        ready.isDone = true;
        this.active = ready;
        this.last = ready;
    }
    async runInTurn(task) {
        const turn = await this.takeTurn();
        if (!turn) {
            throw new EvictedError('Too many pending turns');
        }
        try {
            await task();
        }
        finally {
            turn.release();
        }
    }
    async takeTurn() {
        const turn = new TurnNode(this);
        this.last.next = turn;
        this.last = turn;
        this.length++;
        if (this.length > this.maxLength) {
            this.length--;
            const first = this.active.next;
            if (first === this.last) {
                this.last = this.active;
            }
            first.drop();
            this.active.next = first.next;
        }
        return turn.starting;
    }
    startNext() {
        this.length--;
        this.active = this.active.next;
        this.active.start();
    }
}
exports.TurnQueue = TurnQueue;
//# sourceMappingURL=turn-queue.js.map