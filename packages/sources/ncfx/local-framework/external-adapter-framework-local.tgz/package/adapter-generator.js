#!/usr/bin/env node
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var path_1 = require("path");
var child_process_1 = require("child_process");
var pathArg = process.argv[2] || '';
var generatorPath = (0, path_1.resolve)(__dirname, './generator-adapter/generators/app/index.js');
var generatorCommand = "yo ".concat(generatorPath, " ").concat(pathArg);
(0, child_process_1.execSync)(generatorCommand, { stdio: 'inherit' });
