import { AdapterResponse, ResponseGenerics } from '../util';
/**
 * A consumer of observations for one or more cache keys, i.e. a single gRPC stream.
 *
 * The bus deliberately knows nothing else about a subscriber: each one carries its own payload
 * hashes and request contexts, so it is the subscriber that decides how to finalize and frame the
 * response it was handed.
 */
export interface ObservationSubscriber {
    /**
     * Hands `response` to this subscriber. Must not throw and must not block; implementations are
     * expected to buffer and return immediately.
     *
     * @param cacheKey - the cache key the response was written under
     * @param response - the response that was just written to the cache
     */
    deliver(cacheKey: string, response: Readonly<AdapterResponse>): void;
}
/**
 * Fans cache writes out to gRPC streaming subscribers.
 *
 * Registered as a singleton on `AdapterDependencies` (only when the gRPC server is served) so that
 * `SimpleResponseCache` can reach it without importing anything from `src/grpc`.
 *
 * Subscriptions are keyed by the framework cache key rather than by the payload hash the Go shim
 * used: one cache key can serve N subscribers, and even N subscriptions within a single stream (an
 * inverse pair resolves to the same cache key as its direct pair). Each subscriber owns the mapping
 * from cache key back to its own payload hashes.
 */
export declare class ObservationBus {
    private byCacheKey;
    private registrations;
    /**
     * Registers `subscriber` to receive observations written under `cacheKey`. Idempotent.
     *
     * @param cacheKey - framework cache key to listen on
     * @param subscriber - the subscriber to register
     */
    subscribe(cacheKey: string, subscriber: ObservationSubscriber): void;
    /**
     * Removes `subscriber` from `cacheKey`, dropping the key entirely once nobody is listening on it
     * so that a long-lived process does not accumulate empty sets.
     *
     * @param cacheKey - framework cache key to stop listening on
     * @param subscriber - the subscriber to remove
     */
    unsubscribe(cacheKey: string, subscriber: ObservationSubscriber): void;
    /**
     * Delivers cache entries to the subscribers of their keys.
     *
     * This runs on every response cache write, so the no-subscribers case (the common one, and the
     * only one for adapters that never enable gRPC) is a single `Map#size` check. A throwing
     * subscriber is logged and skipped: this must never fail the cache write it is hooked onto.
     *
     * @param entries - the entries that were just written to the cache
     */
    publish<T extends ResponseGenerics>(entries: readonly {
        key: string;
        value: AdapterResponse<T>;
    }[]): void;
    /** Total number of (cache key, subscriber) registrations across the bus. */
    get subscriberCount(): number;
    /** Number of distinct cache keys with at least one subscriber. */
    get cacheKeyCount(): number;
}
