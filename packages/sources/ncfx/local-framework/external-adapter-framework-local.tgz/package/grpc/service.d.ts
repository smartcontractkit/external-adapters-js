import type { ServerDuplexStream } from '@grpc/grpc-js';
import type { Adapter } from '../adapter';
import { AdapterResponse } from '../util';
import { ObservationBus } from './bus';
import { SubscribeResponse } from './subscriber';
/** `google.protobuf.Value`, as decoded by proto-loader with `oneofs` enabled. */
export interface ProtoValue {
    kind?: 'nullValue' | 'numberValue' | 'stringValue' | 'boolValue' | 'structValue' | 'listValue';
    nullValue?: string | number;
    numberValue?: number;
    stringValue?: string;
    boolValue?: boolean;
    structValue?: ProtoStruct;
    listValue?: {
        values?: ProtoValue[];
    };
}
/** `google.protobuf.Struct`. */
export interface ProtoStruct {
    fields?: Record<string, ProtoValue>;
}
/** `streams.v1.Subscription`. */
export interface Subscription {
    data?: ProtoStruct;
}
/** `streams.v1.SubscribeRequest`: an authoritative replacement of the stream's subscription set. */
export interface SubscribeRequest {
    subscriptions?: Subscription[];
}
/** The grpc-js stream for `streams.v1.StreamService/Subscribe`. */
export type SubscribeCall = ServerDuplexStream<SubscribeRequest, SubscribeResponse>;
/**
 * Converts a `google.protobuf.Struct` to the plain object Go's `structpb.Struct.AsMap()` produces,
 * which is what both the payload hash and request validation operate on.
 *
 * @param struct - the decoded struct message
 * @returns the equivalent plain object
 */
export declare const protoStructToJs: (struct: ProtoStruct | undefined) => Record<string, unknown>;
/**
 * PoC COMPATIBILITY SHIM — TODO: remove post-PoC. See plan §2.2 / §6.4.
 *
 * The Go shim could not send an `AdapterResponse`: it reconstructed a lossy `types.Observation` from
 * a Redis `EVAL` payload, and the existing `streams-adapter-client` reads that shape. So on the way
 * out we remap the real `AdapterResponse` into it, which means carrying `success` as redundant state
 * that can disagree with `error`.
 *
 * The exit plan is to send the `AdapterResponse` verbatim once the client reads `errorMessage`
 * directly; at that point this function is the only thing to delete. Nothing else in `src/grpc`
 * knows about the Go envelope.
 *
 * @param response - the finalized response for one subscription
 * @param payloadHash - that subscription's payload hash
 * @returns the outbound `SubscribeResponse`
 */
export declare const toSubscribeResponse: (response: Readonly<AdapterResponse>, payloadHash: Buffer) => SubscribeResponse;
/**
 * Implementation of `streams.v1.StreamService`, replacing the Go `transmitter.StreamTransmitter`.
 *
 * Each message on a stream is an authoritative replacement of that client's subscription set. The
 * whole snapshot is validated before any subscription state changes, so a client that sends one bad
 * entry keeps serving the rest of its feeds instead of losing them all.
 */
export declare class StreamService {
    private readonly adapter;
    private readonly bus;
    private readonly streams;
    constructor(adapter: Adapter, bus: ObservationBus);
    /** Number of currently open `Subscribe` streams. */
    get streamCount(): number;
    /**
     * Handler for `streams.v1.StreamService/Subscribe`. Declared as a property so it can be handed to
     * `Server#addService` directly.
     */
    subscribe: (call: SubscribeCall) => void;
    /**
     * Closes every open stream. Called on adapter shutdown.
     *
     * @param reason - why the streams are being closed, for logs
     */
    closeAll(reason: string): void;
    /**
     * Applies one snapshot to a stream's subscription set.
     *
     * @param subscriber - the stream the snapshot arrived on
     * @param request - the snapshot
     */
    private handleSnapshot;
    /**
     * Derives everything a subscription needs from one `Subscription` message. Throws if the entry is
     * unusable, which invalidates the whole snapshot.
     *
     * @param subscription - the decoded subscription message
     * @param index - its position in the snapshot, for the error message
     * @returns the resolved subscription
     */
    private resolveSubscription;
    /**
     * Registers a request with its transport, which is what keeps the underlying provider
     * subscription (and its subscription-set TTL) alive.
     *
     * @param subscription - the subscription to register
     */
    private registerRequest;
    /**
     * Pushes whatever is already in the cache to newly added subscriptions, so a client subscribing to
     * an asset another stream is already receiving does not wait a full provider tick. This is what
     * the Go cache did through `applyExistingObservation`.
     *
     * @param subscriber - the stream that gained subscriptions
     * @param added - the subscriptions that were just added
     */
    private pushWarmCacheEntries;
}
