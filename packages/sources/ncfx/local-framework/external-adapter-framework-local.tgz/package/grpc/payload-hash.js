"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.observationPayloadHash = exports.goCanonicalJSONStringify = void 0;
/**
 * WIRE COMPATIBILITY, not a throwaway PoC shim — see below.
 *
 * `payload_hash` is the correlation key a real gRPC client uses to match an incoming observation
 * back to the subscription it registered. Two known clients depend on this hash being correct:
 *
 * - The throwaway Go `streams-adapter-client` in external-adapters-js PR #5215, which computed it
 *   as `sha256(adapterName || encoding/json.Marshal(requestData))` (Go stdlib) in
 *   `packages/streams-adapter/helpers/helpers.go` (`ObservationPayloadHash`). This is what this
 *   file originally reproduced, byte-for-byte, against Go's stdlib `encoding/json`.
 *
 * - The real production client: chainlink/chainlink#23233 ("[Data Streams] gRPC transport for
 *   EA"), an in-progress bridge connection manager. Its `bridgeObservationCacheKey`
 *   (`core/services/pipeline/bridgeconn/bridge_conn_manager.go`) computes the identical
 *   `sha256(bridgeName || json.Marshal(data))`, but marshals with `github.com/goccy/go-json`, not
 *   stdlib. `handleObservation` in `eaconn.go` silently discards any observation whose
 *   `payload_hash` doesn't match — no error, the data just never arrives — so this file now targets
 *   goccy/go-json's output, not stdlib's. The two differ in exactly two ways (documented at each
 *   site below): goccy does not use the short escape forms for U+0008/U+000C, and it does not strip
 *   the leading zero from a two-digit negative exponent. Verified against a real Go 1.26.2
 *   toolchain, goccy/go-json v0.10.5 (the version chainlink/chainlink pins).
 *
 * Long-term, hashing is still worth retiring in favor of a self-describing `cache_key` field on
 * `SubscribeResponse` — but that requires a coordinated change on both real clients, not just the
 * throwaway one, so there is no near-term deletion plan for this file.
 */
const crypto_1 = __importDefault(require("crypto"));
/**
 * Compares two strings by their UTF-8 bytes.
 *
 * Go's `encoding/json` sorts map keys with `<` on Go strings, which is a byte-wise comparison of
 * their UTF-8 encoding. JavaScript's default `Array#sort` compares UTF-16 code units instead, and
 * the two orderings disagree whenever a key contains a non-BMP character: `'\u{1F680}'` (UTF-8
 * `f0 9f 9a 80`, UTF-16 `d83d de80`) sorts *after* U+FFFD in Go but *before* it in JS.
 */
const compareUtf8 = (a, b) => Buffer.compare(Buffer.from(a, 'utf8'), Buffer.from(b, 'utf8'));
/**
 * The control characters given a two-character escape rather than a `\u00xx` one.
 *
 * Go's stdlib `encoding/json` also gives U+0008 and U+000C ("backspace" and "form feed") a
 * two-character escape, but `github.com/goccy/go-json` — what the real consumer (see module doc)
 * hashes with — does not; both fall through to the six-character `\u00xx` form instead. Verified
 * against goccy/go-json v0.10.5 (the version chainlink/chainlink pins) with a real Go 1.26.2
 * toolchain.
 */
const SHORT_ESCAPES = {
    0x09: '\\t',
    0x0a: '\\n',
    0x0d: '\\r',
};
/**
 * Encodes a string as a JSON string literal using Go's `encoding/json` escaping rules with
 * `escapeHTML` on (the default, and what `json.Marshal` uses). See `appendString` in
 * `encoding/json/encode.go`.
 *
 * Differences from `JSON.stringify` that make a hand-rolled encoder necessary:
 * - Go escapes `<`, `>` and `&` into their six-character U+003C / U+003E / U+0026 forms; JS emits
 *   them raw.
 * - Go always escapes U+2028 / U+2029 (they are line terminators in JS source); JS emits them raw.
 * - Go replaces each byte that is not valid UTF-8 with a six-character U+FFFD escape. The JS
 *   analogue of undecodable input is an unpaired surrogate, which `JSON.stringify` emits as
 *   `\udXXX`; we emit U+FFFD to follow Go. This is the one case that is not byte-exact — Go counts
 *   bytes while we count code units — but it is unreachable in practice, since proto3 requires
 *   `string` fields to be valid UTF-8 and a `google.protobuf.Struct` therefore never decodes to an
 *   unpaired surrogate.
 *
 * Everything else matches: `"` and `\` are backslash-escaped, U+0008/U+000C/U+000A/U+000D/U+0009
 * get the short `\b` `\f` `\n` `\r` `\t` forms, remaining control characters become `\u00xx` with
 * lowercase hex, U+007F is *not* escaped, and non-ASCII characters are emitted literally (Go writes
 * raw UTF-8, JS writes raw UTF-16 which encodes to the same bytes).
 */
const encodeString = (value) => {
    let out = '"';
    let start = 0;
    for (let i = 0; i < value.length; i++) {
        const code = value.charCodeAt(i);
        let escaped;
        if (code < 0x20) {
            escaped = SHORT_ESCAPES[code] ?? `\\u00${code.toString(16).padStart(2, '0')}`;
        }
        else if (code === 0x22) {
            escaped = '\\"';
        }
        else if (code === 0x5c) {
            escaped = '\\\\';
        }
        else if (code === 0x3c) {
            escaped = '\\u003c';
        }
        else if (code === 0x3e) {
            escaped = '\\u003e';
        }
        else if (code === 0x26) {
            escaped = '\\u0026';
        }
        else if (code === 0x2028) {
            escaped = '\\u2028';
        }
        else if (code === 0x2029) {
            escaped = '\\u2029';
        }
        else if (code >= 0xd800 && code <= 0xdfff) {
            const isPair = code < 0xdc00 && i + 1 < value.length && (value.charCodeAt(i + 1) & 0xfc00) === 0xdc00;
            if (isPair) {
                i++; // Well-formed pair, emit both units literally
            }
            else {
                escaped = '\\ufffd';
            }
        }
        if (escaped !== undefined) {
            out += value.slice(start, i) + escaped;
            start = i + 1;
        }
    }
    return `${out}${value.slice(start)}"`;
};
/**
 * Encodes a number the way `github.com/goccy/go-json` encodes a `float64`.
 *
 * Every value decoded from a `google.protobuf.Struct` is a `float64` on the Go side, so this is the
 * only numeric case we need. Both goccy/go-json and Go's stdlib use `%e` when
 * `abs(f) < 1e-6 || abs(f) >= 1e21` and `%f` otherwise, with shortest-round-trip digits.
 * `Number.prototype.toString` switches at the same two thresholds and produces the same
 * shortest-round-trip digits, so plain `String(value)` is the right starting point. This was
 * checked against Go over 200k random float64 bit patterns plus a mantissa/exponent sweep across
 * the whole range, with zero digit mismatches.
 *
 * One exponent-spelling difference remains, and is fixed up below: stdlib's `encoding/json`
 * strips the leading zero from a two-digit negative exponent (`1e-07` → `1e-7`, which is also what
 * `Number.prototype.toString` produces), but goccy/go-json does not — it emits `1e-07`. This only
 * arises for negative exponents, since the `abs(f) >= 1e21` threshold means a positive exponent is
 * never smaller than 21 (already two digits, nothing to strip either way).
 *
 * Other known divergences, both handled here:
 * - `JSON.stringify(-0)` is `'0'`, but Go emits `-0`.
 * - `json.Marshal` *errors* on NaN and ±Inf, on both marshalers; `JSON.stringify` silently emits
 *   `null`. Emitting `null` would produce a hash neither Go client could reproduce, so we throw.
 *
 * Residual risk, not eliminated: the shortest-round-trip digit string is unique except for an exact
 * tie between two equally-close candidates, where ECMAScript mandates the larger significand while
 * Go's Ryū implementation applies its own tie-break. If such a double ever reached a streams payload
 * the two encodings could differ in the last digit. The fuzz sweep found no such value, and in
 * practice `Subscription.data` holds strings and small integers, so this is theoretical.
 */
const encodeNumber = (value) => {
    if (!Number.isFinite(value)) {
        throw new Error(`Cannot compute a payload hash for the non-finite number ${value}: json.Marshal rejects NaN and Infinity on both the goccy/go-json and stdlib encoders`);
    }
    if (Object.is(value, -0)) {
        return '-0';
    }
    // Goccy/go-json keeps the native two-digit exponent width for a small-magnitude negative
    // exponent; only a single digit needs padding back in, since anything already two digits or more
    // (exponent <= -10) has no leading zero to strip in the first place.
    return String(value).replace(/e-(\d)$/, 'e-0$1');
};
const encodeValue = (value) => {
    if (value === null) {
        return 'null';
    }
    switch (typeof value) {
        case 'boolean':
            return value ? 'true' : 'false';
        case 'number':
            return encodeNumber(value);
        case 'string':
            return encodeString(value);
        case 'object':
            break;
        default:
            throw new Error(`Cannot compute a Go-compatible payload hash for a value of type ${typeof value}: only the types produced by decoding a google.protobuf.Struct (null, boolean, number, string, array, object) are supported`);
    }
    if (Array.isArray(value)) {
        return `[${value.map((item) => encodeValue(item)).join(',')}]`;
    }
    const record = value;
    const entries = Object.keys(record)
        .sort(compareUtf8)
        .map((key) => `${encodeString(key)}:${encodeValue(record[key])}`);
    return `{${entries.join(',')}}`;
};
/**
 * Serializes a value exactly as Go's `json.Marshal` serializes the equivalent
 * `map[string]interface{}`, so the bytes can be fed to a hash the Go client also computes.
 *
 * Object keys are sorted by their UTF-8 bytes at every depth (Go sorts map keys; JS would otherwise
 * preserve insertion order); array order is preserved. Note that unlike the framework's
 * `calculateParamsKey` this does **not** lowercase keys or values — the Go shim hashed the raw
 * pre-validation payload, so any case folding here would change the hash.
 *
 * @param value - a value drawn from the `google.protobuf.Struct` domain: `null`, boolean, number,
 *   string, array, or plain object. Anything else (`undefined`, bigint, symbol, function, NaN,
 *   Infinity) has no `encoding/json` equivalent and throws.
 * @returns the JSON encoding, matching Go byte-for-byte
 *
 * @example
 * ```
 * goCanonicalJSONStringify({ quote: 'USD', base: 'ETH' })
 * // equals `{"base":"ETH","quote":"USD"}`
 * ```
 */
const goCanonicalJSONStringify = (value) => encodeValue(value);
exports.goCanonicalJSONStringify = goCanonicalJSONStringify;
/**
 * Computes the `payload_hash` both known consumers (see module doc) expect for a subscription,
 * i.e. `sha256(adapterName || json.Marshal(requestData))`.
 *
 * @param adapterName - must be `adapter.name.toLowerCase()` with underscores turned back into
 *   hyphens (see the gRPC service's caller). The Go shim derived this from `PACKAGE_NAME`
 *   (`@chainlink/tiingo-adapter` → `tiingo`); chainlink/chainlink#23233 derives it from the bridge
 *   name (`bridge-blocksize-capital` → `blocksize-capital`, hyphenated). Either way the framework's
 *   `adapter.name` is uppercase and underscored (`TIINGO`, `BLOCKSIZE_CAPITAL`), so the caller has
 *   to transform it; this function hashes what it is given verbatim.
 * @param requestData - the raw, pre-validation `Subscription.data` payload
 * @returns the 32-byte digest
 */
const observationPayloadHash = (adapterName, requestData) => crypto_1.default
    .createHash('sha256')
    .update(Buffer.from(adapterName, 'utf8'))
    .update(Buffer.from((0, exports.goCanonicalJSONStringify)(requestData), 'utf8'))
    .digest();
exports.observationPayloadHash = observationPayloadHash;
//# sourceMappingURL=payload-hash.js.map