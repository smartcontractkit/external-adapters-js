import net from 'net';
/**
 * The fixed 24-byte HTTP/2 client connection preface (RFC 7540 §3.5). Every h2c ("prior knowledge",
 * i.e. no TLS/ALPN and no HTTP/1.1 Upgrade dance) connection starts with these exact bytes, which is
 * how `@grpc/grpc-js` always dials plaintext gRPC. It is also the only signal available to tell a
 * gRPC connection from an HTTP/1.1 one without decrypting or parsing further, and what Go's `cmux`
 * matches on for the same purpose.
 */
export declare const H2C_PREFACE: Buffer<ArrayBuffer>;
export interface PortMultiplexerTarget {
    host: string;
    port: number;
}
export interface PortMultiplexerOptions {
    /** Host the multiplexer's real, external listener binds to. */
    host: string;
    /** Port the multiplexer's real, external listener binds to. */
    port: number;
    /** Where an h2c (gRPC) connection is forwarded, e.g. a loopback-only port `GrpcStreamServer` bound. */
    grpcTarget: PortMultiplexerTarget;
    /** Where everything else is forwarded, e.g. a loopback-only port fastify bound. */
    httpTarget: PortMultiplexerTarget;
    /**
     * How long to wait for enough bytes to classify a connection before assuming HTTP/1.1. A real h2c
     * client sends its whole preface as part of the connection preamble, so this only matters for a
     * slow or idle HTTP/1.1 client.
     */
    peekTimeoutMs?: number;
}
/**
 * Starts the port multiplexer's real, external listener.
 *
 * @param options - the real address to bind, and the two internal targets to forward to
 * @returns the bound `net.Server`, already listening
 */
export declare const listenPortMultiplexer: (options: PortMultiplexerOptions) => Promise<net.Server>;
