"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ObservationBus = void 0;
const util_1 = require("../util");
const logger = (0, util_1.makeLogger)('ObservationBus');
/**
 * Fans cache writes out to gRPC streaming subscribers.
 *
 * Registered as a singleton on `AdapterDependencies` (only when the gRPC server is served) so that
 * `SimpleResponseCache` can reach it without importing anything from `src/grpc`.
 *
 * Subscriptions are keyed by the framework cache key rather than by the payload hash the Go shim
 * used: one cache key can serve N subscribers, and even N subscriptions within a single stream (an
 * inverse pair resolves to the same cache key as its direct pair). Each subscriber owns the mapping
 * from cache key back to its own payload hashes.
 */
class ObservationBus {
    byCacheKey = new Map();
    registrations = 0;
    /**
     * Registers `subscriber` to receive observations written under `cacheKey`. Idempotent.
     *
     * @param cacheKey - framework cache key to listen on
     * @param subscriber - the subscriber to register
     */
    subscribe(cacheKey, subscriber) {
        let subscribers = this.byCacheKey.get(cacheKey);
        if (!subscribers) {
            subscribers = new Set();
            this.byCacheKey.set(cacheKey, subscribers);
        }
        if (!subscribers.has(subscriber)) {
            subscribers.add(subscriber);
            this.registrations++;
        }
    }
    /**
     * Removes `subscriber` from `cacheKey`, dropping the key entirely once nobody is listening on it
     * so that a long-lived process does not accumulate empty sets.
     *
     * @param cacheKey - framework cache key to stop listening on
     * @param subscriber - the subscriber to remove
     */
    unsubscribe(cacheKey, subscriber) {
        const subscribers = this.byCacheKey.get(cacheKey);
        if (!subscribers?.delete(subscriber)) {
            return;
        }
        this.registrations--;
        if (subscribers.size === 0) {
            this.byCacheKey.delete(cacheKey);
        }
    }
    /**
     * Delivers cache entries to the subscribers of their keys.
     *
     * This runs on every response cache write, so the no-subscribers case (the common one, and the
     * only one for adapters that never enable gRPC) is a single `Map#size` check. A throwing
     * subscriber is logged and skipped: this must never fail the cache write it is hooked onto.
     *
     * @param entries - the entries that were just written to the cache
     */
    publish(entries) {
        if (this.byCacheKey.size === 0) {
            return;
        }
        for (const { key, value } of entries) {
            const subscribers = this.byCacheKey.get(key);
            if (!subscribers) {
                continue;
            }
            for (const subscriber of subscribers) {
                try {
                    subscriber.deliver(key, value);
                }
                catch (err) {
                    (0, util_1.censorLogs)(() => logger.error(`Error delivering an observation for "${key}": ${err}`));
                }
            }
        }
    }
    /** Total number of (cache key, subscriber) registrations across the bus. */
    get subscriberCount() {
        return this.registrations;
    }
    /** Number of distinct cache keys with at least one subscriber. */
    get cacheKeyCount() {
        return this.byCacheKey.size;
    }
}
exports.ObservationBus = ObservationBus;
//# sourceMappingURL=bus.js.map