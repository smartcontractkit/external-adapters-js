"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.listenPortMultiplexer = exports.H2C_PREFACE = void 0;
const net_1 = __importDefault(require("net"));
const util_1 = require("../util");
const logger = (0, util_1.makeLogger)('GrpcPortMux');
/**
 * The fixed 24-byte HTTP/2 client connection preface (RFC 7540 §3.5). Every h2c ("prior knowledge",
 * i.e. no TLS/ALPN and no HTTP/1.1 Upgrade dance) connection starts with these exact bytes, which is
 * how `@grpc/grpc-js` always dials plaintext gRPC. It is also the only signal available to tell a
 * gRPC connection from an HTTP/1.1 one without decrypting or parsing further, and what Go's `cmux`
 * matches on for the same purpose.
 */
exports.H2C_PREFACE = Buffer.from('PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n', 'ascii');
const DEFAULT_PEEK_TIMEOUT_MS = 3000;
/**
 * Pipes one accepted connection to whichever target it was classified as, once classification is
 * decided. Everything buffered while peeking is replayed to the target first, so no bytes are lost.
 */
const forwardConnection = (socket, buffered, target) => {
    const upstream = net_1.default.connect({ host: target.host, port: target.port });
    socket.setNoDelay(true);
    upstream.setNoDelay(true);
    // Either side closing or erroring tears down the other; net.Server.close()/Socket.destroy() are
    // idempotent, so there is no need to guard against both firing.
    const destroyBoth = () => {
        socket.destroy();
        upstream.destroy();
    };
    upstream.once('error', (err) => {
        logger.warn(`Error connecting to ${target.host}:${target.port}: ${err}`);
        destroyBoth();
    });
    socket.once('error', destroyBoth);
    upstream.once('close', () => socket.destroy());
    socket.once('close', () => upstream.destroy());
    upstream.once('connect', () => {
        if (buffered.length) {
            upstream.write(buffered);
        }
        socket.pipe(upstream);
        upstream.pipe(socket);
    });
};
/**
 * Demultiplexes plaintext gRPC (h2c) and HTTP/1.1 traffic on a single accepted connection, the way
 * the retired Go streams adapter used `cmux` to share `HTTP_PORT`. `@grpc/grpc-js` and fastify each
 * still own and bind a real server of their own, to an internal, loopback-only port; this only peeks
 * the first bytes of a new connection to decide which of the two to pipe it to, then gets out of the
 * way — the two servers never know the multiplexer is there.
 *
 * TLS is not handled here: both back ends would be wrapped in the same certificate, so an encrypted
 * connection is opaque at this layer regardless of which one it is bound for. Shared-port mode is
 * therefore plaintext only (enforced by `grpcPortSharingEnabled`'s validation).
 */
const handleConnection = (socket, options) => {
    let buffered = Buffer.alloc(0);
    let settled = false;
    // Stops peeking without forwarding anywhere, because the socket is already gone (or going) and
    // there is nothing left to pipe. Forwarding here would still open a real upstream connection, and
    // since the 'close' listener that would normally clean it up already fired once and never fires
    // again, that connection would leak for as long as the upstream server lets it sit idle.
    const abort = () => {
        if (settled) {
            return;
        }
        settled = true;
        clearTimeout(timer);
        socket.removeListener('data', onData);
        socket.removeListener('error', onEarlyError);
        socket.removeListener('close', onEarlyClose);
    };
    const settle = (target) => {
        if (settled) {
            return;
        }
        abort();
        forwardConnection(socket, buffered, target);
    };
    const onData = (chunk) => {
        buffered = Buffer.concat([buffered, chunk]);
        if (buffered.length >= exports.H2C_PREFACE.length) {
            const isGrpc = buffered.subarray(0, exports.H2C_PREFACE.length).equals(exports.H2C_PREFACE);
            settle(isGrpc ? options.grpcTarget : options.httpTarget);
            return;
        }
        // Not enough bytes yet to be sure, but already diverges from the preface — no point waiting
        if (!buffered.equals(exports.H2C_PREFACE.subarray(0, buffered.length))) {
            settle(options.httpTarget);
        }
    };
    const onEarlyError = () => abort();
    const onEarlyClose = () => abort();
    // A connection that goes this long without sending enough bytes to decide is most likely a slow
    // or idle HTTP/1.1 client; grpc-js always sends its whole preface as part of opening the stream.
    // Unlike onEarlyError/onEarlyClose, the socket is presumably still alive here, so it is still
    // worth forwarding.
    const timer = setTimeout(() => settle(options.httpTarget), options.peekTimeoutMs ?? DEFAULT_PEEK_TIMEOUT_MS);
    timer.unref();
    socket.on('data', onData);
    socket.once('error', onEarlyError);
    socket.once('close', onEarlyClose);
};
/**
 * Starts the port multiplexer's real, external listener.
 *
 * @param options - the real address to bind, and the two internal targets to forward to
 * @returns the bound `net.Server`, already listening
 */
const listenPortMultiplexer = (options) => {
    const server = net_1.default.createServer((socket) => handleConnection(socket, options));
    return new Promise((resolve, reject) => {
        const onError = (err) => reject(err);
        server.once('error', onError);
        server.listen(options.port, options.host, () => {
            server.removeListener('error', onError);
            resolve(server);
        });
    });
};
exports.listenPortMultiplexer = listenPortMultiplexer;
//# sourceMappingURL=port-mux.js.map