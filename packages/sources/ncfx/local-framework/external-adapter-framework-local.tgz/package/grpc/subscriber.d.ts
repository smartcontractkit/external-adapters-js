import { AdapterRequest, AdapterResponse } from '../util';
import { EmptyInputParameters } from '../validation/input-params';
import { ObservationBus, ObservationSubscriber } from './bus';
/**
 * `streams.v1.SubscribeResponse`. Field names are the proto ones verbatim, since the proto is
 * loaded with `keepCase`.
 */
export interface SubscribeResponse {
    timestamp: string;
    observation_json: Buffer;
    payload_hash: Buffer;
}
/**
 * One entry of a stream's subscription set: a single `Subscription` message the client sent, with
 * everything derived from it.
 */
export interface StreamSubscription {
    /**
     * Hex encoding of `payloadHash`, used as the subscription's identity exactly like the Go shim,
     * which keyed its set on the hash. Two entries in one snapshot that hash the same are one
     * subscription; two that hash differently are two subscriptions even if they resolve to the same
     * cache key.
     */
    id: string;
    /** The `payload_hash` echoed back on every observation sent for this subscription. */
    payloadHash: Buffer;
    /** Framework cache key the observations for this subscription are published under. */
    cacheKey: string;
    /**
     * Request context built from this subscription's raw data at subscribe time. Held so that fanout
     * can run `finalizeResponse` for *this* subscription: a pair and its inverse share a cache key
     * but need different results.
     */
    req: AdapterRequest<EmptyInputParameters>;
}
/** The slice of `Adapter` the fanout path needs, kept narrow to avoid an import cycle. */
export interface ResponseFinalizer {
    finalizeResponse(req: AdapterRequest<EmptyInputParameters>, response: Readonly<AdapterResponse>): Readonly<AdapterResponse>;
}
/** The slice of a grpc-js `ServerDuplexStream` the outbound queue drives. */
export interface OutboundStream {
    write(message: SubscribeResponse): boolean;
    once(event: 'drain', listener: () => void): unknown;
    removeListener(event: 'drain', listener: () => void): unknown;
}
export interface SubscriberParams {
    /** The gRPC stream this subscriber writes to */
    call: OutboundStream;
    /** Bus to register this stream's cache keys with */
    bus: ObservationBus;
    /** Used to apply per-request transforms (e.g. inverse pairs) before sending */
    finalizer: ResponseFinalizer;
    /** Frames a finalized response as an outbound message */
    buildMessage: (response: Readonly<AdapterResponse>, payloadHash: Buffer) => SubscribeResponse;
    /** Maximum number of queued outbound messages before new ones are dropped */
    queueSize: number;
    /** Time without a valid snapshot after which this stream's subscriptions are cleared */
    refreshTimeoutMs: number;
}
/**
 * Per-stream state for one open `Subscribe` call: the subscription set, the bounded outbound queue,
 * and the subscription refresh timer.
 */
export declare class Subscriber implements ObservationSubscriber {
    private readonly call;
    private readonly bus;
    private readonly finalizer;
    private readonly buildMessage;
    private readonly queueSize;
    private readonly refreshTimeoutMs;
    /** This stream's subscription set, keyed by [[StreamSubscription.id]]. */
    private readonly subscriptions;
    /** Index from cache key to the ids of the subscriptions waiting on it, for O(1) fanout. */
    private readonly idsByCacheKey;
    /**
     * Pending messages, keyed by [[StreamSubscription.id]] — at most one per subscription.
     *
     * Keying by subscription rather than appending is what keeps a healthy client from losing data.
     * Observations are produced in synchronous bursts (a batch cache write, or the warm-cache push
     * after a snapshot), while the stream only accepts ~16 objects per event-loop turn, so an
     * append-only queue overflows on the burst itself no matter how fast the client reads. Coalescing
     * instead bounds the queue by the number of subscriptions the client asked for, and a slow
     * consumer loses only intermediate ticks for a feed, never a feed entirely.
     *
     * A `Map` keeps first-insertion order when an existing key is overwritten, so a feed that keeps
     * ticking cannot starve the feeds queued behind it.
     */
    private readonly queue;
    /** Subscription ids that have been sent at least one observation, so warm pushes can stand down. */
    private readonly delivered;
    private paused;
    private closed;
    private dropped;
    private superseded;
    private sent;
    private refreshTimer;
    private readonly onDrain;
    constructor(params: SubscriberParams);
    /** Arms the refresh timer. Called once, when the stream opens. */
    start(): void;
    get isClosed(): boolean;
    /** Number of subscriptions currently held by this stream. */
    get subscriptionCount(): number;
    /** Messages currently waiting for the stream to accept them. */
    get queueLength(): number;
    /** Messages dropped because the outbound queue was full. */
    get droppedCount(): number;
    /** Queued messages replaced by a newer observation for the same subscription. */
    get supersededCount(): number;
    /** Messages handed to the stream. */
    get sentCount(): number;
    /** Snapshot of the current subscription ids, safe to iterate while mutating the set. */
    subscriptionIds(): string[];
    /**
     * Adds `subscription` to this stream's set, registering the cache key on the bus the first time
     * it is needed.
     *
     * @param subscription - the subscription to add
     * @returns true if it was not already subscribed
     */
    add(subscription: StreamSubscription): boolean;
    /**
     * Removes one subscription, unregistering its cache key from the bus once no subscription on this
     * stream wants it anymore.
     *
     * @param id - the [[StreamSubscription.id]] to remove
     */
    remove(id: string): void;
    /** Drops the whole subscription set and unregisters from the bus, leaving the stream open. */
    clearSubscriptions(): void;
    /**
     * Sends a response to every subscription of this stream that is waiting on `cacheKey` (more than
     * one when the client subscribed to both a pair and its inverse).
     *
     * @param cacheKey - the cache key the response was written under
     * @param response - the response that was just written to the cache
     */
    deliver(cacheKey: string, response: Readonly<AdapterResponse>): void;
    /**
     * Sends a response to a single subscription of this stream. Used both by fanout and by the
     * warm-cache push that runs right after a new subscription is added.
     *
     * @param id - the [[StreamSubscription.id]] to send to
     * @param response - the response to finalize and send
     */
    /**
     * Sends a cached response to a subscription that has just been added, unless a live observation
     * has already reached it.
     *
     * The subscription is registered on the bus before the cache is read, so that a write landing in
     * between is not missed. That ordering means the awaited read can return a value older than one
     * already delivered, which would put a stale price last on the wire — so a subscription that has
     * already received anything skips the warm push entirely.
     *
     * @param id - the [[StreamSubscription.id]] to send to
     * @param response - the cached response to finalize and send
     */
    deliverWarmToSubscription(id: string, response: Readonly<AdapterResponse>): void;
    deliverToSubscription(id: string, response: Readonly<AdapterResponse>): void;
    /**
     * (Re)arms the refresh timer. When it fires, this stream's subscriptions are cleared but the
     * stream is left open and the timer re-armed, matching the Go transmitter: a client that goes
     * quiet and comes back just re-subscribes with its next snapshot.
     */
    resetRefreshTimer(): void;
    /**
     * Tears down all state for this stream. Idempotent, and safe to call from any of the stream's
     * terminal events.
     *
     * @param reason - why the stream is being closed, for logs
     */
    close(reason: string): void;
    /**
     * Queues a message for one subscription, replacing any observation still pending for it.
     *
     * The bound is load-bearing: grpc-js buffers writes without limit, so a client that stops reading
     * would otherwise grow the process heap by one observation per provider tick until it dies.
     * `queueSize` is the backstop; in practice the per-subscription keying bounds the queue by the
     * client's own subscription count, which [[GRPC_MAX_SUBSCRIPTIONS_PER_STREAM]] already caps.
     *
     * @param id - the [[StreamSubscription.id]] this message belongs to
     * @param message - the message to queue
     */
    private enqueue;
    /** Writes as much of the queue as the stream will take, then waits for 'drain'. */
    private flush;
}
