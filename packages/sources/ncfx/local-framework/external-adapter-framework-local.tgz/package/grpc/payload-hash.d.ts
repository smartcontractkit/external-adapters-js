/**
 * Serializes a value exactly as Go's `json.Marshal` serializes the equivalent
 * `map[string]interface{}`, so the bytes can be fed to a hash the Go client also computes.
 *
 * Object keys are sorted by their UTF-8 bytes at every depth (Go sorts map keys; JS would otherwise
 * preserve insertion order); array order is preserved. Note that unlike the framework's
 * `calculateParamsKey` this does **not** lowercase keys or values — the Go shim hashed the raw
 * pre-validation payload, so any case folding here would change the hash.
 *
 * @param value - a value drawn from the `google.protobuf.Struct` domain: `null`, boolean, number,
 *   string, array, or plain object. Anything else (`undefined`, bigint, symbol, function, NaN,
 *   Infinity) has no `encoding/json` equivalent and throws.
 * @returns the JSON encoding, matching Go byte-for-byte
 *
 * @example
 * ```
 * goCanonicalJSONStringify({ quote: 'USD', base: 'ETH' })
 * // equals `{"base":"ETH","quote":"USD"}`
 * ```
 */
export declare const goCanonicalJSONStringify: (value: unknown) => string;
/**
 * Computes the `payload_hash` both known consumers (see module doc) expect for a subscription,
 * i.e. `sha256(adapterName || json.Marshal(requestData))`.
 *
 * @param adapterName - must be `adapter.name.toLowerCase()` with underscores turned back into
 *   hyphens (see the gRPC service's caller). The Go shim derived this from `PACKAGE_NAME`
 *   (`@chainlink/tiingo-adapter` → `tiingo`); chainlink/chainlink#23233 derives it from the bridge
 *   name (`bridge-blocksize-capital` → `blocksize-capital`, hyphenated). Either way the framework's
 *   `adapter.name` is uppercase and underscored (`TIINGO`, `BLOCKSIZE_CAPITAL`), so the caller has
 *   to transform it; this function hashes what it is given verbatim.
 * @param requestData - the raw, pre-validation `Subscription.data` payload
 * @returns the 32-byte digest
 */
export declare const observationPayloadHash: (adapterName: string, requestData: Record<string, unknown>) => Buffer;
