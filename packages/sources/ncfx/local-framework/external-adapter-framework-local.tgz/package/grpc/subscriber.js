"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Subscriber = void 0;
const metrics_1 = require("../metrics");
const constants_1 = require("../metrics/constants");
const util_1 = require("../util");
const logger = (0, util_1.makeLogger)('GrpcSubscriber');
/**
 * Per-stream state for one open `Subscribe` call: the subscription set, the bounded outbound queue,
 * and the subscription refresh timer.
 */
class Subscriber {
    call;
    bus;
    finalizer;
    buildMessage;
    queueSize;
    refreshTimeoutMs;
    /** This stream's subscription set, keyed by [[StreamSubscription.id]]. */
    subscriptions = new Map();
    /** Index from cache key to the ids of the subscriptions waiting on it, for O(1) fanout. */
    idsByCacheKey = new Map();
    /**
     * Pending messages, keyed by [[StreamSubscription.id]] — at most one per subscription.
     *
     * Keying by subscription rather than appending is what keeps a healthy client from losing data.
     * Observations are produced in synchronous bursts (a batch cache write, or the warm-cache push
     * after a snapshot), while the stream only accepts ~16 objects per event-loop turn, so an
     * append-only queue overflows on the burst itself no matter how fast the client reads. Coalescing
     * instead bounds the queue by the number of subscriptions the client asked for, and a slow
     * consumer loses only intermediate ticks for a feed, never a feed entirely.
     *
     * A `Map` keeps first-insertion order when an existing key is overwritten, so a feed that keeps
     * ticking cannot starve the feeds queued behind it.
     */
    queue = new Map();
    /** Subscription ids that have been sent at least one observation, so warm pushes can stand down. */
    delivered = new Set();
    paused = false;
    closed = false;
    dropped = 0;
    superseded = 0;
    sent = 0;
    refreshTimer;
    onDrain = () => {
        this.paused = false;
        this.flush();
    };
    constructor(params) {
        this.call = params.call;
        this.bus = params.bus;
        this.finalizer = params.finalizer;
        this.buildMessage = params.buildMessage;
        this.queueSize = params.queueSize;
        this.refreshTimeoutMs = params.refreshTimeoutMs;
    }
    /** Arms the refresh timer. Called once, when the stream opens. */
    start() {
        this.resetRefreshTimer();
    }
    get isClosed() {
        return this.closed;
    }
    /** Number of subscriptions currently held by this stream. */
    get subscriptionCount() {
        return this.subscriptions.size;
    }
    /** Messages currently waiting for the stream to accept them. */
    get queueLength() {
        return this.queue.size;
    }
    /** Messages dropped because the outbound queue was full. */
    get droppedCount() {
        return this.dropped;
    }
    /** Queued messages replaced by a newer observation for the same subscription. */
    get supersededCount() {
        return this.superseded;
    }
    /** Messages handed to the stream. */
    get sentCount() {
        return this.sent;
    }
    /** Snapshot of the current subscription ids, safe to iterate while mutating the set. */
    subscriptionIds() {
        return [...this.subscriptions.keys()];
    }
    /**
     * Adds `subscription` to this stream's set, registering the cache key on the bus the first time
     * it is needed.
     *
     * @param subscription - the subscription to add
     * @returns true if it was not already subscribed
     */
    add(subscription) {
        if (this.closed || this.subscriptions.has(subscription.id)) {
            return false;
        }
        this.subscriptions.set(subscription.id, subscription);
        metrics_1.metrics.get('grpcSubscriptionActive').inc();
        let ids = this.idsByCacheKey.get(subscription.cacheKey);
        if (!ids) {
            ids = new Set();
            this.idsByCacheKey.set(subscription.cacheKey, ids);
            this.bus.subscribe(subscription.cacheKey, this);
        }
        ids.add(subscription.id);
        return true;
    }
    /**
     * Removes one subscription, unregistering its cache key from the bus once no subscription on this
     * stream wants it anymore.
     *
     * @param id - the [[StreamSubscription.id]] to remove
     */
    remove(id) {
        const subscription = this.subscriptions.get(id);
        if (!subscription) {
            return;
        }
        this.subscriptions.delete(id);
        // Nothing else refers to this id, so its pending message and delivery mark go with it
        this.queue.delete(id);
        this.delivered.delete(id);
        metrics_1.metrics.get('grpcSubscriptionActive').dec();
        const ids = this.idsByCacheKey.get(subscription.cacheKey);
        if (!ids) {
            return;
        }
        ids.delete(id);
        if (ids.size === 0) {
            this.idsByCacheKey.delete(subscription.cacheKey);
            this.bus.unsubscribe(subscription.cacheKey, this);
        }
    }
    /** Drops the whole subscription set and unregisters from the bus, leaving the stream open. */
    clearSubscriptions() {
        for (const cacheKey of this.idsByCacheKey.keys()) {
            this.bus.unsubscribe(cacheKey, this);
        }
        this.idsByCacheKey.clear();
        metrics_1.metrics.get('grpcSubscriptionActive').dec(this.subscriptions.size);
        this.subscriptions.clear();
        // Pending messages and delivery marks are keyed by subscription id, so they expire with the set
        this.queue.clear();
        this.delivered.clear();
    }
    /**
     * Sends a response to every subscription of this stream that is waiting on `cacheKey` (more than
     * one when the client subscribed to both a pair and its inverse).
     *
     * @param cacheKey - the cache key the response was written under
     * @param response - the response that was just written to the cache
     */
    deliver(cacheKey, response) {
        const ids = this.idsByCacheKey.get(cacheKey);
        if (!ids) {
            return;
        }
        for (const id of ids) {
            this.deliverToSubscription(id, response);
        }
    }
    /**
     * Sends a response to a single subscription of this stream. Used both by fanout and by the
     * warm-cache push that runs right after a new subscription is added.
     *
     * @param id - the [[StreamSubscription.id]] to send to
     * @param response - the response to finalize and send
     */
    /**
     * Sends a cached response to a subscription that has just been added, unless a live observation
     * has already reached it.
     *
     * The subscription is registered on the bus before the cache is read, so that a write landing in
     * between is not missed. That ordering means the awaited read can return a value older than one
     * already delivered, which would put a stale price last on the wire — so a subscription that has
     * already received anything skips the warm push entirely.
     *
     * @param id - the [[StreamSubscription.id]] to send to
     * @param response - the cached response to finalize and send
     */
    deliverWarmToSubscription(id, response) {
        if (this.delivered.has(id)) {
            return;
        }
        this.deliverToSubscription(id, response);
    }
    deliverToSubscription(id, response) {
        const subscription = this.subscriptions.get(id);
        if (this.closed || !subscription) {
            return;
        }
        this.delivered.add(id);
        let message;
        try {
            message = this.buildMessage(this.finalizer.finalizeResponse(subscription.req, response), subscription.payloadHash);
        }
        catch (err) {
            (0, util_1.censorLogs)(() => logger.error(`Could not build an observation for "${subscription.cacheKey}": ${err}`));
            return;
        }
        this.enqueue(id, message);
    }
    /**
     * (Re)arms the refresh timer. When it fires, this stream's subscriptions are cleared but the
     * stream is left open and the timer re-armed, matching the Go transmitter: a client that goes
     * quiet and comes back just re-subscribes with its next snapshot.
     */
    resetRefreshTimer() {
        clearTimeout(this.refreshTimer);
        if (this.closed) {
            return;
        }
        this.refreshTimer = setTimeout(() => {
            logger.info(`Client subscriptions expired after ${this.refreshTimeoutMs}ms without a valid snapshot`);
            this.clearSubscriptions();
            this.resetRefreshTimer();
        }, this.refreshTimeoutMs);
        // Nothing should be kept alive by this timer alone; the open stream is what holds the process
        this.refreshTimer.unref();
    }
    /**
     * Tears down all state for this stream. Idempotent, and safe to call from any of the stream's
     * terminal events.
     *
     * @param reason - why the stream is being closed, for logs
     */
    close(reason) {
        if (this.closed) {
            return;
        }
        this.closed = true;
        clearTimeout(this.refreshTimer);
        this.refreshTimer = undefined;
        this.call.removeListener('drain', this.onDrain);
        this.clearSubscriptions();
        this.queue.clear();
        logger.debug(`Closed gRPC subscriber (${reason}), dropped ${this.dropped} message(s)`);
    }
    /**
     * Queues a message for one subscription, replacing any observation still pending for it.
     *
     * The bound is load-bearing: grpc-js buffers writes without limit, so a client that stops reading
     * would otherwise grow the process heap by one observation per provider tick until it dies.
     * `queueSize` is the backstop; in practice the per-subscription keying bounds the queue by the
     * client's own subscription count, which [[GRPC_MAX_SUBSCRIPTIONS_PER_STREAM]] already caps.
     *
     * @param id - the [[StreamSubscription.id]] this message belongs to
     * @param message - the message to queue
     */
    enqueue(id, message) {
        if (this.closed) {
            return;
        }
        if (this.queue.has(id)) {
            // A newer observation for a feed always supersedes an unsent older one — the opposite of the
            // Go transmitter, which dropped the newest on a full channel and so served stale prices
            this.queue.set(id, message);
            this.superseded++;
            metrics_1.metrics.get('grpcObservationDroppedTotal').labels({ reason: constants_1.GrpcDropReason.SUPERSEDED }).inc();
            return;
        }
        if (this.queue.size >= this.queueSize) {
            this.dropped++;
            metrics_1.metrics.get('grpcObservationDroppedTotal').labels({ reason: constants_1.GrpcDropReason.QUEUE_FULL }).inc();
            return;
        }
        this.queue.set(id, message);
        this.flush();
    }
    /** Writes as much of the queue as the stream will take, then waits for 'drain'. */
    flush() {
        while (!this.closed && !this.paused) {
            const next = this.queue.entries().next();
            if (next.done) {
                return;
            }
            const [id, message] = next.value;
            this.queue.delete(id);
            let accepted;
            try {
                accepted = this.call.write(message);
            }
            catch (err) {
                (0, util_1.censorLogs)(() => logger.warn(`Error writing to a gRPC stream: ${err}`));
                this.close('write error');
                return;
            }
            this.sent++;
            metrics_1.metrics.get('grpcObservationSentTotal').inc();
            if (!accepted) {
                this.paused = true;
                this.call.once('drain', this.onDrain);
                return;
            }
        }
    }
}
exports.Subscriber = Subscriber;
//# sourceMappingURL=subscriber.js.map