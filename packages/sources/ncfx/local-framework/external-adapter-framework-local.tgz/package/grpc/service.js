"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StreamService = exports.toSubscribeResponse = exports.protoStructToJs = void 0;
const metrics_1 = require("../metrics");
const constants_1 = require("../metrics/constants");
const util_1 = require("../util");
const validation_1 = require("../validation");
const payload_hash_1 = require("./payload-hash");
const subscriber_1 = require("./subscriber");
const logger = (0, util_1.makeLogger)('GrpcStreamService');
const protoValueToJs = (value) => {
    switch (value.kind) {
        case 'numberValue':
            return value.numberValue ?? 0;
        case 'stringValue':
            return value.stringValue ?? '';
        case 'boolValue':
            return value.boolValue ?? false;
        case 'structValue':
            return (0, exports.protoStructToJs)(value.structValue);
        case 'listValue':
            return (value.listValue?.values ?? []).map(protoValueToJs);
        default:
            // Either 'nullValue' or an unset oneof
            return null;
    }
};
/**
 * Converts a `google.protobuf.Struct` to the plain object Go's `structpb.Struct.AsMap()` produces,
 * which is what both the payload hash and request validation operate on.
 *
 * @param struct - the decoded struct message
 * @returns the equivalent plain object
 */
const protoStructToJs = (struct) => {
    const data = {};
    for (const [key, value] of Object.entries(struct?.fields ?? {})) {
        data[key] = protoValueToJs(value);
    }
    return data;
};
exports.protoStructToJs = protoStructToJs;
/**
 * PoC COMPATIBILITY SHIM — TODO: remove post-PoC. See plan §2.2 / §6.4.
 *
 * The Go shim could not send an `AdapterResponse`: it reconstructed a lossy `types.Observation` from
 * a Redis `EVAL` payload, and the existing `streams-adapter-client` reads that shape. So on the way
 * out we remap the real `AdapterResponse` into it, which means carrying `success` as redundant state
 * that can disagree with `error`.
 *
 * The exit plan is to send the `AdapterResponse` verbatim once the client reads `errorMessage`
 * directly; at that point this function is the only thing to delete. Nothing else in `src/grpc`
 * knows about the Go envelope.
 *
 * @param response - the finalized response for one subscription
 * @param payloadHash - that subscription's payload hash
 * @returns the outbound `SubscribeResponse`
 */
const toSubscribeResponse = (response, payloadHash) => {
    const observation = {
        // Go's Observation holds these as json.RawMessage, so they are always present, null when unset
        data: response.data ?? null,
        result: response.result ?? null,
        timestamps: response.timestamps,
        meta: response.meta ?? null,
        success: !response.errorMessage,
        statusCode: response.statusCode,
    };
    if (response.errorMessage) {
        observation.error = response.errorMessage;
    }
    return {
        // Go sends RFC3339Nano; ms precision parses fine with time.Parse(time.RFC3339Nano, ...).
        // This is the time the observation was received from the provider, not the time it went out on
        // the wire: the Go transmitter stamped it at cache-write time, and a warm-cache push labelled
        // "now" would read as fresh to any client using it for staleness.
        timestamp: new Date(response.timestamps?.providerDataReceivedUnixMs ?? Date.now()).toISOString(),
        observation_json: Buffer.from(JSON.stringify(observation), 'utf8'),
        payload_hash: payloadHash,
    };
};
exports.toSubscribeResponse = toSubscribeResponse;
/**
 * Implementation of `streams.v1.StreamService`, replacing the Go `transmitter.StreamTransmitter`.
 *
 * Each message on a stream is an authoritative replacement of that client's subscription set. The
 * whole snapshot is validated before any subscription state changes, so a client that sends one bad
 * entry keeps serving the rest of its feeds instead of losing them all.
 */
class StreamService {
    adapter;
    bus;
    streams = new Map();
    constructor(adapter, bus) {
        this.adapter = adapter;
        this.bus = bus;
    }
    /** Number of currently open `Subscribe` streams. */
    get streamCount() {
        return this.streams.size;
    }
    /**
     * Handler for `streams.v1.StreamService/Subscribe`. Declared as a property so it can be handed to
     * `Server#addService` directly.
     */
    subscribe = (call) => {
        const settings = this.adapter.config.settings;
        const subscriber = new subscriber_1.Subscriber({
            call,
            bus: this.bus,
            finalizer: this.adapter,
            buildMessage: exports.toSubscribeResponse,
            queueSize: settings.GRPC_SUBSCRIBER_QUEUE_SIZE,
            refreshTimeoutMs: settings.GRPC_SUBSCRIPTION_REFRESH_TIMEOUT_MS,
        });
        this.streams.set(subscriber, call);
        metrics_1.metrics.get('grpcStreamActive').inc();
        logger.debug(`Opened a gRPC stream from ${call.getPeer()}`);
        const finish = (reason) => {
            // Several of the stream's terminal events fire for one closure, so only the first one counts
            if (this.streams.delete(subscriber)) {
                metrics_1.metrics.get('grpcStreamActive').dec();
            }
            subscriber.close(reason);
        };
        call.on('data', (request) => {
            // One snapshot at a time per stream. Pausing the inbound side while this one is applied lets
            // TCP backpressure reach the client instead of letting it stack unbounded in-flight snapshots,
            // each retaining a full set of built request contexts. The Go transmitter got this for free
            // from a 1-buffered channel feeding a single select loop.
            call.pause();
            // Nothing awaits a snapshot, so make sure a failure cannot become an unhandled rejection
            this.handleSnapshot(subscriber, request)
                .catch((err) => {
                (0, util_1.censorLogs)(() => logger.error(`Error handling a subscription snapshot: ${err}`));
            })
                .finally(() => {
                if (!subscriber.isClosed) {
                    call.resume();
                }
            });
        });
        call.on('end', () => {
            finish('client half-closed the stream');
            call.end();
        });
        call.on('error', (err) => {
            (0, util_1.censorLogs)(() => logger.warn(`Error on a gRPC stream: ${err}`));
            finish('stream error');
        });
        call.on('cancelled', () => finish('stream cancelled'));
        call.on('close', () => finish('stream closed'));
        subscriber.start();
    };
    /**
     * Closes every open stream. Called on adapter shutdown.
     *
     * @param reason - why the streams are being closed, for logs
     */
    closeAll(reason) {
        for (const [subscriber, call] of this.streams) {
            metrics_1.metrics.get('grpcStreamActive').dec();
            subscriber.close(reason);
            try {
                call.end();
            }
            catch (err) {
                (0, util_1.censorLogs)(() => logger.warn(`Error ending a gRPC stream: ${err}`));
            }
        }
        this.streams.clear();
    }
    /**
     * Applies one snapshot to a stream's subscription set.
     *
     * @param subscriber - the stream the snapshot arrived on
     * @param request - the snapshot
     */
    async handleSnapshot(subscriber, request) {
        if (subscriber.isClosed) {
            return;
        }
        const settings = this.adapter.config.settings;
        const subscriptions = request.subscriptions ?? [];
        const maxSubscriptions = settings.GRPC_MAX_SUBSCRIPTIONS_PER_STREAM;
        if (subscriptions.length > maxSubscriptions) {
            logger.warn(`Ignoring a subscription snapshot with ${subscriptions.length} entries; GRPC_MAX_SUBSCRIPTIONS_PER_STREAM is ${maxSubscriptions}`);
            metrics_1.metrics
                .get('grpcSnapshotErrors')
                .labels({ reason: constants_1.GrpcSnapshotErrorType.TOO_MANY_SUBSCRIPTIONS })
                .inc();
            // Refresh anyway. A client that is persistently over the cap is misconfigured, not absent, and
            // letting its existing subscriptions expire would silently starve it while the stream still
            // looks healthy — the failure mode plan §6.1 rejects for EA_MODE=reader.
            subscriber.resetRefreshTimer();
            return;
        }
        // Validate the entire snapshot before touching any subscription state, so an invalid entry
        // leaves the stream exactly as it was (and, since we return early, does not refresh it either)
        let resolved;
        try {
            resolved = subscriptions.map((subscription, index) => this.resolveSubscription(subscription, index));
        }
        catch (err) {
            (0, util_1.censorLogs)(() => logger.warn(`Invalid subscription snapshot, keeping the previous subscriptions: ${err}`));
            metrics_1.metrics
                .get('grpcSnapshotErrors')
                .labels({ reason: constants_1.GrpcSnapshotErrorType.INVALID_SUBSCRIPTION })
                .inc();
            return;
        }
        // The snapshot is the set: dedupe by payload hash, exactly as the Go transmitter did
        const next = new Map();
        for (const subscription of resolved) {
            if (!next.has(subscription.id)) {
                next.set(subscription.id, subscription);
            }
        }
        for (const id of subscriber.subscriptionIds()) {
            if (!next.has(id)) {
                subscriber.remove(id);
            }
        }
        const added = [];
        for (const subscription of next.values()) {
            if (subscriber.add(subscription)) {
                added.push(subscription);
            }
        }
        subscriber.resetRefreshTimer();
        logger.debug(`Applied a snapshot of ${next.size} subscription(s) (${added.length} new) to a gRPC stream`);
        await Promise.all([
            // Every entry, not just the new ones: this is the native equivalent of the shim's
            // POST-to-the-JS-adapter, and re-running it on each snapshot is what refreshes the
            // subscription set TTL
            ...[...next.values()].map((subscription) => this.registerRequest(subscription)),
            this.pushWarmCacheEntries(subscriber, added),
        ]);
    }
    /**
     * Derives everything a subscription needs from one `Subscription` message. Throws if the entry is
     * unusable, which invalidates the whole snapshot.
     *
     * @param subscription - the decoded subscription message
     * @param index - its position in the snapshot, for the error message
     * @returns the resolved subscription
     */
    resolveSubscription(subscription, index) {
        if (!subscription?.data) {
            throw new Error(`subscription ${index} is missing data`);
        }
        const data = (0, exports.protoStructToJs)(subscription.data);
        // Hashed before validation: the Go shim hashed the raw request data, and buildRequestContext
        // normalizes what it is given (PoC compat, plan §2.1).
        // The shim derived its adapter name from PACKAGE_NAME ('@chainlink/blocksize-capital-adapter' ->
        // 'blocksize-capital'), whereas the framework's is uppercase and underscored
        // ('BLOCKSIZE_CAPITAL'), so underscores have to come back as hyphens for the hashes to match.
        const payloadHash = (0, payload_hash_1.observationPayloadHash)(this.adapter.name.toLowerCase().replace(/_/g, '-'), data);
        // The same validation the REST handler runs, so aliases, overrides, request transforms, custom
        // validation and cache key generation can never drift between the two entrypoints
        const req = (0, validation_1.buildRequestContext)(this.adapter, { data });
        return {
            id: payloadHash.toString('hex'),
            payloadHash,
            cacheKey: req.requestContext.cacheKey,
            req,
        };
    }
    /**
     * Registers a request with its transport, which is what keeps the underlying provider
     * subscription (and its subscription-set TTL) alive.
     *
     * @param subscription - the subscription to register
     */
    async registerRequest(subscription) {
        const { req } = subscription;
        const endpoint = this.adapter.endpointsMap[req.requestContext.endpointName];
        const transport = endpoint?.transportRoutes.get(req.requestContext.transportName);
        if (!transport?.registerRequest) {
            return;
        }
        try {
            await transport.registerRequest(req, this.adapter.config.settings);
        }
        catch (err) {
            (0, util_1.censorLogs)(() => logger.error(`Error registering "${subscription.cacheKey}" with its transport: ${err}`));
        }
    }
    /**
     * Pushes whatever is already in the cache to newly added subscriptions, so a client subscribing to
     * an asset another stream is already receiving does not wait a full provider tick. This is what
     * the Go cache did through `applyExistingObservation`.
     *
     * @param subscriber - the stream that gained subscriptions
     * @param added - the subscriptions that were just added
     */
    async pushWarmCacheEntries(subscriber, added) {
        if (!added.length) {
            return;
        }
        // Several new subscriptions can share a cache key (a pair and its inverse), so read once per key
        const idsByCacheKey = new Map();
        for (const { cacheKey, id } of added) {
            const ids = idsByCacheKey.get(cacheKey);
            if (ids) {
                ids.push(id);
            }
            else {
                idsByCacheKey.set(cacheKey, [id]);
            }
        }
        const cache = this.adapter.dependencies.cache;
        await Promise.all([...idsByCacheKey].map(async ([cacheKey, ids]) => {
            try {
                const response = await cache.get(cacheKey);
                if (!response) {
                    return;
                }
                for (const id of ids) {
                    subscriber.deliverWarmToSubscription(id, response);
                }
            }
            catch (err) {
                (0, util_1.censorLogs)(() => logger.error(`Error reading "${cacheKey}" from the cache: ${err}`));
            }
        }));
    }
}
exports.StreamService = StreamService;
//# sourceMappingURL=service.js.map