import { ServerCredentials, ServiceDefinition } from '@grpc/grpc-js';
import type { Adapter } from '../adapter';
import { ObservationBus } from './bus';
import { StreamService } from './service';
export * from './bus';
export * from './payload-hash';
export * from './port-mux';
export * from './service';
export * from './subscriber';
/** Fully qualified name of the service in `streams.proto`. */
export declare const STREAM_SERVICE_NAME = "streams.v1.StreamService";
/**
 * Loads the `StreamService` definition from `streams.proto`. Cached, since a process only ever
 * serves one.
 *
 * @returns the grpc-js service definition
 */
export declare const loadStreamServiceDefinition: () => ServiceDefinition;
/**
 * Serves `streams.v1.StreamService`.
 *
 * By default this binds its own listener, separate from `EA_PORT`, because `@grpc/grpc-js` builds
 * and owns its own `http2` server and cannot be handed an already-accepted socket, and fastify serves
 * HTTP/1.1 — so there is nothing to demultiplex into directly. When `GRPC_PORT` is configured equal
 * to `EA_PORT` (see `grpcPortSharingEnabled`), `expose()` instead binds this server to an internal,
 * loopback-only port (via the `listen` override) and puts `port-mux`'s plaintext demultiplexer in
 * front of both it and fastify, the same way the retired Go streams adapter used `cmux` to share
 * `HTTP_PORT`.
 */
export declare class GrpcStreamServer {
    readonly service: StreamService;
    private readonly server;
    private readonly host;
    private readonly configuredPort;
    private readonly cleanups;
    private boundPort;
    constructor(adapter: Adapter, bus: ObservationBus);
    /** The port the server is listening on, or undefined before it is bound. */
    get port(): number | undefined;
    /**
     * Binds the server to `GRPC_HOST`:`GRPC_PORT`, or to `override` when given one.
     *
     * @param credentials - server credentials, built from the adapter's TLS settings
     * @param override - host/port to bind instead of the configured ones, used to bind to an internal,
     *   loopback-only port when `expose()` is sharing `EA_PORT` via the port multiplexer
     * @returns the bound port, which differs from the configured/override port when that is 0
     */
    listen(credentials: ServerCredentials, override?: {
        host: string;
        port: number;
    }): Promise<number>;
    /**
     * Registers a callback to run at the start of {@link shutdown}, before the listener is closed.
     * Used to detach process-level listeners that would otherwise keep this server — and through it
     * the whole adapter — reachable for the lifetime of the process.
     *
     * @param cleanup - callback to run when shutting down
     */
    onShutdown(cleanup: () => void): void;
    /**
     * Closes every open stream, then shuts the listener down.
     *
     * @param gracefulTimeoutMs - how long to wait for a graceful drain before forcing it
     */
    shutdown(gracefulTimeoutMs?: number): Promise<void>;
}
