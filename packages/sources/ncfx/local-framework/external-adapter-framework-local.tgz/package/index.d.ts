import { ServerCredentials } from '@grpc/grpc-js';
import { FastifyInstance } from 'fastify';
import { Adapter, AdapterDependencies } from './adapter';
import { AdapterSettings, SettingsDefinitionMap } from './config';
import { GrpcStreamServer } from './grpc';
export { FastifyInstance as ServerInstance };
export interface httpsOptions {
    https: {
        key: string;
        cert: string;
        ca: string;
        passphrase?: string;
        requestCert: boolean;
    };
}
export declare const getTLSOptions: (adapterSettings: AdapterSettings) => {
    https?: undefined;
} | {
    https: {
        key: string;
        cert: string;
        ca: string;
        passphrase: string;
        requestCert: boolean;
    };
};
/**
 * Builds the gRPC server credentials out of the same TLS settings the REST API uses, so there is
 * only one set of certificates to configure.
 *
 * @param adapterSettings - the adapter settings holding the TLS configuration
 * @returns insecure credentials, or SSL ones when TLS_ENABLED / MTLS_ENABLED is set
 */
export declare const getGrpcCredentials: (adapterSettings: AdapterSettings) => ServerCredentials;
/**
 * Main function for the framework.
 * Initializes config and dependencies, uses those to initialize Transports, and starts listening for requests.
 *
 * @param adapter - an object describing an External Adapter
 * @param dependencies - an optional object with adapter dependencies to inject
 * @returns a Promise that resolves to the http.Server listening for connections
 */
export declare const start: <T extends SettingsDefinitionMap>(adapter: Adapter<T>, dependencies?: Partial<AdapterDependencies>) => Promise<{
    api: FastifyInstance | undefined;
    metricsApi: FastifyInstance | undefined;
    grpcServer: GrpcStreamServer | undefined;
}>;
export declare const expose: <T extends SettingsDefinitionMap>(adapter: Adapter<T>, dependencies?: Partial<AdapterDependencies>) => Promise<FastifyInstance | undefined>;
