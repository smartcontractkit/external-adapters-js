import { FastifyReply, FastifyRequest } from 'fastify';
import { Adapter } from '../adapter';
import { AdapterMiddlewareBuilder, AdapterRequest, AdapterRequestBody } from '../util/types';
import { EmptyInputParameters } from './input-params';
export { InputParameters } from './input-params';
/**
 * Validates a raw adapter request body and builds the request context the rest of the
 * framework relies on: resolved endpoint, normalized data, transport name, metrics meta
 * and cache key.
 *
 * This is shared by every entrypoint into the adapter (the REST middleware below, and the
 * gRPC streaming service), so aliases, overrides, request transforms, custom validation and
 * cache key generation can never drift between them.
 *
 * @param adapter - the adapter this request is directed to
 * @param body - the raw, pre-validation request body
 * @param target - the request to populate, when the caller has a real one (the REST middleware
 *   passes the incoming fastify request). Omitted by callers with no underlying request, such as
 *   the gRPC streaming service, which get a minimal carrier instead.
 * @returns the populated request, i.e. `target` when one was given
 */
export declare const buildRequestContext: (adapter: Adapter, body: AdapterRequestBody, target?: AdapterRequest<EmptyInputParameters>) => AdapterRequest<EmptyInputParameters>;
export declare const validatorMiddleware: AdapterMiddlewareBuilder;
export declare const errorCatchingMiddleware: (err: Error, req: FastifyRequest, res: FastifyReply) => void;
