"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AdapterLWBAError = exports.AdapterCustomError = exports.AdapterConnectionError = exports.AdapterDataProviderError = exports.AdapterTimeoutError = exports.AdapterRateLimitError = exports.AdapterInputError = exports.AdapterError = void 0;
const constants_1 = require("../metrics/constants");
class AdapterError extends Error {
    status;
    statusCode;
    cause;
    url;
    errorResponse;
    feedID;
    providerStatusCode;
    metricsLabel;
    name;
    message;
    constructor({ status = 'errored', statusCode = 500, name = 'AdapterError', message = 'There was an unexpected error in the adapter.', cause, url, feedID, errorResponse, providerStatusCode, metricsLabel = constants_1.HttpRequestType.ADAPTER_ERROR, }) {
        super(message);
        this.status = status;
        this.statusCode = statusCode;
        this.name = name;
        this.message = message;
        this.cause = cause;
        if (url) {
            this.url = url;
        }
        if (feedID) {
            this.feedID = feedID;
        }
        this.errorResponse = errorResponse;
        this.providerStatusCode = providerStatusCode;
        this.metricsLabel = metricsLabel;
    }
    toJSONResponse() {
        const showDebugInfo = process.env['DEBUG'] === 'true';
        const errorBasic = {
            name: this.name,
            message: this.message,
            url: this.url,
            errorResponse: this.errorResponse,
            feedID: this.feedID,
        };
        const errorFull = { ...errorBasic, stack: this.stack, cause: this.cause };
        return {
            status: this.status,
            statusCode: this.statusCode,
            providerStatusCode: this.providerStatusCode,
            error: showDebugInfo ? errorFull : errorBasic,
        };
    }
}
exports.AdapterError = AdapterError;
class AdapterInputError extends AdapterError {
    constructor(input) {
        super({ ...input, metricsLabel: constants_1.HttpRequestType.INPUT_ERROR });
    }
}
exports.AdapterInputError = AdapterInputError;
class AdapterRateLimitError extends AdapterError {
    msUntilNextExecution;
    constructor(input) {
        super({ ...input, metricsLabel: constants_1.HttpRequestType.RATE_LIMIT_ERROR });
        this.msUntilNextExecution = input.msUntilNextExecution ?? 0;
    }
}
exports.AdapterRateLimitError = AdapterRateLimitError;
class AdapterTimeoutError extends AdapterError {
    constructor(input) {
        super({ ...input, metricsLabel: constants_1.HttpRequestType.TIMEOUT_ERROR });
    }
}
exports.AdapterTimeoutError = AdapterTimeoutError;
class AdapterDataProviderError extends AdapterError {
    timestamps;
    constructor(input, timestamps) {
        super({ ...input, metricsLabel: constants_1.HttpRequestType.DP_ERROR });
        this.timestamps = timestamps;
    }
}
exports.AdapterDataProviderError = AdapterDataProviderError;
class AdapterConnectionError extends AdapterError {
    timestamps;
    constructor(input, timestamps) {
        super({ ...input, metricsLabel: constants_1.HttpRequestType.CONNECTION_ERROR });
        this.timestamps = timestamps;
    }
}
exports.AdapterConnectionError = AdapterConnectionError;
class AdapterCustomError extends AdapterError {
    constructor(input) {
        super({ ...input, metricsLabel: constants_1.HttpRequestType.CUSTOM_ERROR });
    }
}
exports.AdapterCustomError = AdapterCustomError;
class AdapterLWBAError extends AdapterError {
    constructor(input) {
        super({
            ...input,
            name: 'AdapterLWBAError',
            metricsLabel: constants_1.HttpRequestType.LWBA_ERROR,
        });
    }
}
exports.AdapterLWBAError = AdapterLWBAError;
//# sourceMappingURL=error.js.map