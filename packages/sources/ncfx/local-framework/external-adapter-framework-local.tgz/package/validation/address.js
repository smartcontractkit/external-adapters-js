"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isValidSolanaAddress = exports.isValidBitcoinAddress = exports.isValidEthereumWithdrawalCredentials = exports.isValidEthereumAddress = void 0;
const ethers_1 = require("ethers");
const kit_1 = require("@solana/kit");
const isValidEthereumAddress = (address) => (0, ethers_1.isAddress)(address);
exports.isValidEthereumAddress = isValidEthereumAddress;
const isValidEthereumWithdrawalCredentials = (address) => {
    if (!address || address.length === 0) {
        return false;
    }
    // 0x | 2 chars prefix | 22 chars padding | 40 chars address
    return ((address?.startsWith('0x01') || address?.startsWith('0x02')) &&
        address.length === 66 &&
        (0, ethers_1.isAddress)(`0x${address.slice(26)}`));
};
exports.isValidEthereumWithdrawalCredentials = isValidEthereumWithdrawalCredentials;
const isValidBitcoinAddress = (address) => {
    if (!address || address.length === 0) {
        return false;
    }
    const addressPrefix = address[0];
    switch (addressPrefix) {
        // Legacy (P2PKH) and Nested SegWit (P2SH) Bitcoin addresses start with 1 and are case-sensitive
        case '1':
        case '3':
            return isBase58(address);
        case 'b':
        case 'B':
            return address.slice(0, 3) === 'bc1' && isBech32(address.slice(3));
        default:
            return false;
    }
};
exports.isValidBitcoinAddress = isValidBitcoinAddress;
const isValidSolanaAddress = (address) => {
    if (!address || address.length === 0) {
        return false;
    }
    try {
        (0, kit_1.address)(address);
        return true;
    }
    catch {
        return false;
    }
};
exports.isValidSolanaAddress = isValidSolanaAddress;
const isBase58 = (value) => /^[A-HJ-NP-Za-km-z1-9]*$/.test(value);
const isBech32 = (value) => /^[qpzry9x8gf2tvdw0s3jn54khce6mua7l]+$/i.test(value);
//# sourceMappingURL=address.js.map