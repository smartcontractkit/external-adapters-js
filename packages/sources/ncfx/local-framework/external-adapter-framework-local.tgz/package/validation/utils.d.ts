import { ValidationErrorMessage } from '../config';
export type ValidatorMeta = {
    min?: number;
    max?: number;
    details?: string;
};
export type Validator<V> = {
    meta: ValidatorMeta;
    fn: (value?: V) => ValidationErrorMessage;
};
export type ValidatorWithParams<P, V> = (param: P, customError?: string) => Validator<V>;
export declare const validator: {
    integer: (params?: {
        min?: number;
        max?: number;
    }) => Validator<string | number>;
    positiveInteger: () => Validator<string | number>;
    port: () => Validator<string | number>;
    url: () => Validator<string>;
    host: () => Validator<string>;
    responseTimestamp: () => Validator<string | number>;
    base64: () => Validator<string>;
    compose: (f: Validator<string | number>[]) => Validator<number | string>;
};
