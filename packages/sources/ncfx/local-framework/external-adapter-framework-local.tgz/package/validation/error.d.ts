import { HttpRequestType } from '../metrics/constants';
import { ResponseTimestamps } from '../util';
type ErrorBasic = {
    name: string;
    message: string;
};
type ErrorFull = ErrorBasic & {
    stack: string;
    cause: string;
};
export type AdapterErrorResponse = {
    status: string;
    statusCode: number;
    providerStatusCode?: number;
    error: ErrorBasic | ErrorFull;
};
export declare class AdapterError extends Error {
    status: string;
    statusCode: number;
    cause: unknown;
    url?: string;
    errorResponse: unknown;
    feedID?: string;
    providerStatusCode?: number;
    metricsLabel?: HttpRequestType;
    name: string;
    message: string;
    constructor({ status, statusCode, name, message, cause, url, feedID, errorResponse, providerStatusCode, metricsLabel, }: Partial<AdapterError>);
    toJSONResponse(): AdapterErrorResponse;
}
export declare class AdapterInputError extends AdapterError {
    constructor(input: Partial<AdapterError>);
}
export declare class AdapterRateLimitError extends AdapterError {
    msUntilNextExecution: number;
    constructor(input: Partial<AdapterError> & {
        msUntilNextExecution?: number;
    });
}
export declare class AdapterTimeoutError extends AdapterError {
    constructor(input: Partial<AdapterError>);
}
export declare class AdapterDataProviderError extends AdapterError {
    timestamps: ResponseTimestamps;
    constructor(input: Partial<AdapterError>, timestamps: ResponseTimestamps);
}
export declare class AdapterConnectionError extends AdapterError {
    timestamps: ResponseTimestamps;
    constructor(input: Partial<AdapterError>, timestamps: ResponseTimestamps);
}
export declare class AdapterCustomError extends AdapterError {
    constructor(input: Partial<AdapterError>);
}
export declare class AdapterLWBAError extends AdapterError {
    constructor(input: Partial<AdapterError>);
}
export {};
