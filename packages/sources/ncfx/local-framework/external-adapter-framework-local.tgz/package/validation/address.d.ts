export declare const isValidEthereumAddress: (address?: string | null) => address is string;
export declare const isValidEthereumWithdrawalCredentials: (address?: string | null) => boolean;
export declare const isValidBitcoinAddress: (address?: string | null) => boolean;
export declare const isValidSolanaAddress: (address?: string | null) => boolean;
