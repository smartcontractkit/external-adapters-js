export declare const parseWeekendString: (weekend?: string) => {
    start: string;
    end: string;
    tz: string;
};
export declare const isWeekendNow: (weekend?: string) => boolean;
